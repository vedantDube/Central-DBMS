---
title: ProductFeedConnection - GraphQL Admin
description: An auto-generated type for paginating through multiple ProductFeeds.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/connections/ProductFeedConnection
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/connections/ProductFeedConnection.md
api_name: admin
api_type: graphql
type: connection
metadata:
  domain: admin
---

# Product​Feed​Connection

connection

An auto-generated type for paginating through multiple ProductFeeds.

## Queries with this connection

* [product​Feeds](https://shopify.dev/docs/api/admin-graphql/2026-04/queries/productFeeds)

  query

  The product feeds for the shop.

  * after

    [String](https://shopify.dev/docs/api/admin-graphql/2026-04/scalars/String)

    ### Arguments

    The elements that come after the specified [cursor](https://shopify.dev/api/usage/pagination-graphql).

  * before

    [String](https://shopify.dev/docs/api/admin-graphql/2026-04/scalars/String)

    The elements that come before the specified [cursor](https://shopify.dev/api/usage/pagination-graphql).

  * first

    [Int](https://shopify.dev/docs/api/admin-graphql/2026-04/scalars/Int)

    The first `n` elements from the [paginated list](https://shopify.dev/api/usage/pagination-graphql).

  * last

    [Int](https://shopify.dev/docs/api/admin-graphql/2026-04/scalars/Int)

    The last `n` elements from the [paginated list](https://shopify.dev/api/usage/pagination-graphql).

  * reverse

    [Boolean](https://shopify.dev/docs/api/admin-graphql/2026-04/scalars/Boolean)

    Default:false

    Reverse the order of the underlying list.

  ***

***

## Possible returns

* edges

  [\[Product​Feed​Edge!\]!](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/ProductFeedEdge)

  non-null

  The connection between the node and its parent. Each edge contains a minimum of the edge's cursor and the node.

* nodes

  [\[Product​Feed!\]!](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/ProductFeed)

  non-null

  A list of nodes that are contained in ProductFeedEdge. You can fetch data about an individual node, or you can follow the edges to fetch data about a collection of related nodes. At each node, you specify the fields that you want to retrieve.

* page​Info

  [Page​Info!](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/PageInfo)

  non-null

  An object that’s used to retrieve [cursor information](https://shopify.dev/api/usage/pagination-graphql) about the current page.

***

## Map

### Queries with this connection

* [product​Feeds](https://shopify.dev/docs/api/admin-graphql/2026-04/queries/productFeeds)

### Possible returns

* [Product​Feed​Connection.edges](https://shopify.dev/docs/api/admin-graphql/2026-04/connections/ProductFeedConnection#returns-edges)
* [Product​Feed​Connection.nodes](https://shopify.dev/docs/api/admin-graphql/2026-04/connections/ProductFeedConnection#returns-nodes)
* [Product​Feed​Connection.pageInfo](https://shopify.dev/docs/api/admin-graphql/2026-04/connections/ProductFeedConnection#returns-pageInfo)

---
title: CashTrackingAdjustmentConnection - GraphQL Admin
description: >-
  An auto-generated type for paginating through multiple
  CashTrackingAdjustments.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/connections/CashTrackingAdjustmentConnection
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/connections/CashTrackingAdjustmentConnection.md
api_name: admin
api_type: graphql
type: connection
metadata:
  domain: admin
---

# Cash​Tracking​Adjustment​Connection

connection

An auto-generated type for paginating through multiple CashTrackingAdjustments.

## Fields with this connection

* [Cash​Tracking​Session.adjustments](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CashTrackingSession#field-CashTrackingSession.fields.adjustments)

  OBJECT

  Tracks the balance in a cash drawer for a point of sale device over the course of a shift.

***

## Possible returns

* edges

  [\[Cash​Tracking​Adjustment​Edge!\]!](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CashTrackingAdjustmentEdge)

  non-null

  The connection between the node and its parent. Each edge contains a minimum of the edge's cursor and the node.

* nodes

  [\[Cash​Tracking​Adjustment!\]!](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CashTrackingAdjustment)

  non-null

  A list of nodes that are contained in CashTrackingAdjustmentEdge. You can fetch data about an individual node, or you can follow the edges to fetch data about a collection of related nodes. At each node, you specify the fields that you want to retrieve.

* page​Info

  [Page​Info!](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/PageInfo)

  non-null

  An object that’s used to retrieve [cursor information](https://shopify.dev/api/usage/pagination-graphql) about the current page.

***

## Map

### Fields with this connection

* [Cash​Tracking​Session.adjustments](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CashTrackingSession#field-CashTrackingSession.fields.adjustments)

### Possible returns

* [Cash​Tracking​Adjustment​Connection.edges](https://shopify.dev/docs/api/admin-graphql/2026-04/connections/CashTrackingAdjustmentConnection#returns-edges)
* [Cash​Tracking​Adjustment​Connection.nodes](https://shopify.dev/docs/api/admin-graphql/2026-04/connections/CashTrackingAdjustmentConnection#returns-nodes)
* [Cash​Tracking​Adjustment​Connection.pageInfo](https://shopify.dev/docs/api/admin-graphql/2026-04/connections/CashTrackingAdjustmentConnection#returns-pageInfo)

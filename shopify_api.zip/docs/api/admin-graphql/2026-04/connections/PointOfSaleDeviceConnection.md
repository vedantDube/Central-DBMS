---
title: PointOfSaleDeviceConnection - GraphQL Admin
description: An auto-generated type for paginating through multiple PointOfSaleDevices.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/connections/PointOfSaleDeviceConnection
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/connections/PointOfSaleDeviceConnection.md
api_name: admin
api_type: graphql
type: connection
metadata:
  domain: admin
---

# Point​Of​Sale​Device​Connection

connection

An auto-generated type for paginating through multiple PointOfSaleDevices.

## Fields with this connection

* [Cash​Drawer.pointOfSaleDevices](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CashDrawer#field-CashDrawer.fields.pointOfSaleDevices)

  OBJECT

  A cash drawer for cash management.

***

## Possible returns

* edges

  [\[Point​Of​Sale​Device​Edge!\]!](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/PointOfSaleDeviceEdge)

  non-null

  The connection between the node and its parent. Each edge contains a minimum of the edge's cursor and the node.

* nodes

  [\[Point​Of​Sale​Device!\]!](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/PointOfSaleDevice)

  non-null

  A list of nodes that are contained in PointOfSaleDeviceEdge. You can fetch data about an individual node, or you can follow the edges to fetch data about a collection of related nodes. At each node, you specify the fields that you want to retrieve.

* page​Info

  [Page​Info!](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/PageInfo)

  non-null

  An object that’s used to retrieve [cursor information](https://shopify.dev/api/usage/pagination-graphql) about the current page.

***

## Map

### Fields with this connection

* [Cash​Drawer.pointOfSaleDevices](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CashDrawer#field-CashDrawer.fields.pointOfSaleDevices)

### Possible returns

* [Point​Of​Sale​Device​Connection.edges](https://shopify.dev/docs/api/admin-graphql/2026-04/connections/PointOfSaleDeviceConnection#returns-edges)
* [Point​Of​Sale​Device​Connection.nodes](https://shopify.dev/docs/api/admin-graphql/2026-04/connections/PointOfSaleDeviceConnection#returns-nodes)
* [Point​Of​Sale​Device​Connection.pageInfo](https://shopify.dev/docs/api/admin-graphql/2026-04/connections/PointOfSaleDeviceConnection#returns-pageInfo)

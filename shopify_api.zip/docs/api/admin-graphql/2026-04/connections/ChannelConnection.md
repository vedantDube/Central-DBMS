---
title: ChannelConnection - GraphQL Admin
description: An auto-generated type for paginating through multiple Channels.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/connections/ChannelConnection
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/connections/ChannelConnection.md
api_name: admin
api_type: graphql
type: connection
metadata:
  domain: admin
---

# Channel​Connection

connection

An auto-generated type for paginating through multiple Channels.

## Fields with this connection

* [App.channels](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/App#field-App.fields.channels)

  OBJECT

  A Shopify application that extends store functionality. Apps integrate with Shopify through APIs to add features, automate workflows, or connect external services.

  Provides metadata about the app including its developer information and listing details in the Shopify App Store. Use the [`installation`](https://shopify.dev/docs/api/admin-graphql/latest/objects/App#field-App.fields.installation) field to determine if the app is currently installed on the shop and access installation-specific details like granted [`AccessScope`](https://shopify.dev/docs/api/admin-graphql/latest/objects/AccessScope) objects. Check [`failedRequirements`](https://shopify.dev/docs/api/admin-graphql/latest/objects/App#field-App.fields.failedRequirements) before installation to identify any prerequisites that must be met.

* [App​Catalog.channels](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/AppCatalog#field-AppCatalog.fields.channels)

  OBJECT

  A catalog that defines the publication associated with an app.

* [Publication.channels](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/Publication#field-Publication.fields.channels)

  OBJECT

  A group of [products](https://shopify.dev/docs/api/admin-graphql/latest/objects/Product) and [collections](https://shopify.dev/docs/api/admin-graphql/latest/objects/Collection) that are published to an app.

  Each publication manages which products and collections display on its associated [`Channel`](https://shopify.dev/docs/api/admin-graphql/latest/objects/Channel). Merchants can automatically publish products when they're created if [`autoPublish`](https://shopify.dev/docs/api/admin-graphql/latest/objects/Publication#field-Publication.fields.autoPublish) is enabled, or manually control publication through publication records.

  Publications support scheduled publishing through future publish dates for online store channels, allowing merchants to coordinate product launches and promotional campaigns. The [`catalog`](https://shopify.dev/docs/api/admin-graphql/latest/objects/Publication#field-Publication.fields.catalog) field links to pricing and availability rules specific to that publication's context.

### Deprecated fields with this connection

* [Collection.unpublishedChannels](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/Collection#field-Collection.fields.unpublishedChannels)

  OBJECT

  Deprecated

* [Product.unpublishedChannels](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/Product#field-Product.fields.unpublishedChannels)

  OBJECT

  Deprecated

* [Publishable.unpublishedChannels](https://shopify.dev/docs/api/admin-graphql/2026-04/interfaces/Publishable#fields-unpublishedChannels)

  INTERFACE

  Deprecated

* [Shop.channels](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/Shop#field-Shop.fields.channels)

  OBJECT

  Deprecated

***

## Queries with this connection

* [channels](https://shopify.dev/docs/api/admin-graphql/2026-04/queries/channels)

  query

  The list of [`Channel`](https://shopify.dev/docs/api/admin-graphql/latest/objects/Channel) objects on the shop. When the calling application supports multi-channel, only channels established by the calling application are returned. Each channel represents an authenticated connection to an external selling platform such as a marketplace, social media platform, online store, or point-of-sale system.

  * after

    [String](https://shopify.dev/docs/api/admin-graphql/2026-04/scalars/String)

    ### Arguments

    The elements that come after the specified [cursor](https://shopify.dev/api/usage/pagination-graphql).

  * before

    [String](https://shopify.dev/docs/api/admin-graphql/2026-04/scalars/String)

    The elements that come before the specified [cursor](https://shopify.dev/api/usage/pagination-graphql).

  * first

    [Int](https://shopify.dev/docs/api/admin-graphql/2026-04/scalars/Int)

    The first `n` elements from the [paginated list](https://shopify.dev/api/usage/pagination-graphql).

  * last

    [Int](https://shopify.dev/docs/api/admin-graphql/2026-04/scalars/Int)

    The last `n` elements from the [paginated list](https://shopify.dev/api/usage/pagination-graphql).

  * reverse

    [Boolean](https://shopify.dev/docs/api/admin-graphql/2026-04/scalars/Boolean)

    Default:false

    Reverse the order of the underlying list.

  ***

***

## Possible returns

* edges

  [\[Channel​Edge!\]!](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/ChannelEdge)

  non-null

  The connection between the node and its parent. Each edge contains a minimum of the edge's cursor and the node.

* nodes

  [\[Channel!\]!](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/Channel)

  non-null

  A list of nodes that are contained in ChannelEdge. You can fetch data about an individual node, or you can follow the edges to fetch data about a collection of related nodes. At each node, you specify the fields that you want to retrieve.

* page​Info

  [Page​Info!](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/PageInfo)

  non-null

  An object that’s used to retrieve [cursor information](https://shopify.dev/api/usage/pagination-graphql) about the current page.

***

## Map

### Fields with this connection

* [App.channels](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/App#field-App.fields.channels)
* [App​Catalog.channels](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/AppCatalog#field-AppCatalog.fields.channels)
* [Publication.channels](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/Publication#field-Publication.fields.channels)

### Queries with this connection

* [channels](https://shopify.dev/docs/api/admin-graphql/2026-04/queries/channels)

### Possible returns

* [Channel​Connection.edges](https://shopify.dev/docs/api/admin-graphql/2026-04/connections/ChannelConnection#returns-edges)
* [Channel​Connection.nodes](https://shopify.dev/docs/api/admin-graphql/2026-04/connections/ChannelConnection#returns-nodes)
* [Channel​Connection.pageInfo](https://shopify.dev/docs/api/admin-graphql/2026-04/connections/ChannelConnection#returns-pageInfo)

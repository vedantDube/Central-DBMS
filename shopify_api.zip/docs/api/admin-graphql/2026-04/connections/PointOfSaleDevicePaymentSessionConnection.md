---
title: PointOfSaleDevicePaymentSessionConnection - GraphQL Admin
description: >-
  An auto-generated type for paginating through multiple
  PointOfSaleDevicePaymentSessions.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/connections/PointOfSaleDevicePaymentSessionConnection
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/connections/PointOfSaleDevicePaymentSessionConnection.md
api_name: admin
api_type: graphql
type: connection
metadata:
  domain: admin
---

# Point​Of​Sale​Device​Payment​Session​Connection

connection

An auto-generated type for paginating through multiple PointOfSaleDevicePaymentSessions.

## Queries with this connection

* [point​Of​Sale​Device​Payment​Sessions](https://shopify.dev/docs/api/admin-graphql/2026-04/queries/pointOfSaleDevicePaymentSessions)

  query

  A list of point of sale device payment sessions in the shop.

  * after

    [String](https://shopify.dev/docs/api/admin-graphql/2026-04/scalars/String)

    ### Arguments

    The elements that come after the specified [cursor](https://shopify.dev/api/usage/pagination-graphql).

  * before

    [String](https://shopify.dev/docs/api/admin-graphql/2026-04/scalars/String)

    The elements that come before the specified [cursor](https://shopify.dev/api/usage/pagination-graphql).

  * first

    [Int](https://shopify.dev/docs/api/admin-graphql/2026-04/scalars/Int)

    The first `n` elements from the [paginated list](https://shopify.dev/api/usage/pagination-graphql).

  * last

    [Int](https://shopify.dev/docs/api/admin-graphql/2026-04/scalars/Int)

    The last `n` elements from the [paginated list](https://shopify.dev/api/usage/pagination-graphql).

  * query

    [String](https://shopify.dev/docs/api/admin-graphql/2026-04/scalars/String)

    A filter made up of terms, connectives, modifiers, and comparators. You can apply one or more filters to a query. Learn more about [Shopify API search syntax](https://shopify.dev/api/usage/search-syntax).

    * closing\_date

      date

    * closing\_time

      time

    * * id

        id

      * is\_open

        boolean

      - Filter by `id` range.

      - Example:
        * `id:1234`
        * `id:>=1234`
        * `id:<=1234`

    * location\_id

      id

    * opening\_date

      date

    * opening\_time

      time

    * point\_of\_sale\_device\_id

      id

  * reverse

    [Boolean](https://shopify.dev/docs/api/admin-graphql/2026-04/scalars/Boolean)

    Default:false

    Reverse the order of the underlying list.

  * sort​Key

    [Point​Of​Sale​Device​Payment​Session​Sort​Keys](https://shopify.dev/docs/api/admin-graphql/2026-04/enums/PointOfSaleDevicePaymentSessionSortKeys)

    Default:ID

    Sort the underlying list by the given key.

  ***

***

## Possible returns

* edges

  [\[Point​Of​Sale​Device​Payment​Session​Edge!\]!](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/PointOfSaleDevicePaymentSessionEdge)

  non-null

  The connection between the node and its parent. Each edge contains a minimum of the edge's cursor and the node.

* nodes

  [\[Point​Of​Sale​Device​Payment​Session!\]!](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/PointOfSaleDevicePaymentSession)

  non-null

  A list of nodes that are contained in PointOfSaleDevicePaymentSessionEdge. You can fetch data about an individual node, or you can follow the edges to fetch data about a collection of related nodes. At each node, you specify the fields that you want to retrieve.

* page​Info

  [Page​Info!](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/PageInfo)

  non-null

  An object that’s used to retrieve [cursor information](https://shopify.dev/api/usage/pagination-graphql) about the current page.

***

## Map

### Queries with this connection

* [point​Of​Sale​Device​Payment​Sessions](https://shopify.dev/docs/api/admin-graphql/2026-04/queries/pointOfSaleDevicePaymentSessions)

### Possible returns

* [Point​Of​Sale​Device​Payment​Session​Connection.edges](https://shopify.dev/docs/api/admin-graphql/2026-04/connections/PointOfSaleDevicePaymentSessionConnection#returns-edges)
* [Point​Of​Sale​Device​Payment​Session​Connection.nodes](https://shopify.dev/docs/api/admin-graphql/2026-04/connections/PointOfSaleDevicePaymentSessionConnection#returns-nodes)
* [Point​Of​Sale​Device​Payment​Session​Connection.pageInfo](https://shopify.dev/docs/api/admin-graphql/2026-04/connections/PointOfSaleDevicePaymentSessionConnection#returns-pageInfo)

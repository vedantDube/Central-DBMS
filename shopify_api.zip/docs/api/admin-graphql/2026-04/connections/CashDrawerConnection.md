---
title: CashDrawerConnection - GraphQL Admin
description: An auto-generated type for paginating through multiple CashDrawers.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/connections/CashDrawerConnection
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/connections/CashDrawerConnection.md
api_name: admin
api_type: graphql
type: connection
metadata:
  domain: admin
---

# Cash​Drawer​Connection

connection

An auto-generated type for paginating through multiple CashDrawers.

## Queries with this connection

* [cash​Drawers](https://shopify.dev/docs/api/admin-graphql/2026-04/queries/cashDrawers)

  query

  A list of cash drawers in the shop.

  * after

    [String](https://shopify.dev/docs/api/admin-graphql/2026-04/scalars/String)

    ### Arguments

    The elements that come after the specified [cursor](https://shopify.dev/api/usage/pagination-graphql).

  * before

    [String](https://shopify.dev/docs/api/admin-graphql/2026-04/scalars/String)

    The elements that come before the specified [cursor](https://shopify.dev/api/usage/pagination-graphql).

  * first

    [Int](https://shopify.dev/docs/api/admin-graphql/2026-04/scalars/Int)

    The first `n` elements from the [paginated list](https://shopify.dev/api/usage/pagination-graphql).

  * last

    [Int](https://shopify.dev/docs/api/admin-graphql/2026-04/scalars/Int)

    The last `n` elements from the [paginated list](https://shopify.dev/api/usage/pagination-graphql).

  * query

    [String](https://shopify.dev/docs/api/admin-graphql/2026-04/scalars/String)

    A filter made up of terms, connectives, modifiers, and comparators. You can apply one or more filters to a query. Learn more about [Shopify API search syntax](https://shopify.dev/api/usage/search-syntax).

    * * id

        id

      * location\_id

        id

      - Filter by `id` range.

      - Example:
        * `id:1234`
        * `id:>=1234`
        * `id:<=1234`

  ***

***

## Possible returns

* edges

  [\[Cash​Drawer​Edge!\]!](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CashDrawerEdge)

  non-null

  The connection between the node and its parent. Each edge contains a minimum of the edge's cursor and the node.

* nodes

  [\[Cash​Drawer!\]!](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CashDrawer)

  non-null

  A list of nodes that are contained in CashDrawerEdge. You can fetch data about an individual node, or you can follow the edges to fetch data about a collection of related nodes. At each node, you specify the fields that you want to retrieve.

* page​Info

  [Page​Info!](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/PageInfo)

  non-null

  An object that’s used to retrieve [cursor information](https://shopify.dev/api/usage/pagination-graphql) about the current page.

***

## Map

### Queries with this connection

* [cash​Drawers](https://shopify.dev/docs/api/admin-graphql/2026-04/queries/cashDrawers)

### Possible returns

* [Cash​Drawer​Connection.edges](https://shopify.dev/docs/api/admin-graphql/2026-04/connections/CashDrawerConnection#returns-edges)
* [Cash​Drawer​Connection.nodes](https://shopify.dev/docs/api/admin-graphql/2026-04/connections/CashDrawerConnection#returns-nodes)
* [Cash​Drawer​Connection.pageInfo](https://shopify.dev/docs/api/admin-graphql/2026-04/connections/CashDrawerConnection#returns-pageInfo)

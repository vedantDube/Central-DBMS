---
title: MailingAddressConnection - GraphQL Admin
description: An auto-generated type for paginating through multiple MailingAddresses.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/connections/MailingAddressConnection
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/connections/MailingAddressConnection.md
api_name: admin
api_type: graphql
type: connection
metadata:
  domain: admin
---

# Mailing​Address​Connection

connection

An auto-generated type for paginating through multiple MailingAddresses.

## Fields with this connection

* [Customer.addressesV2](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/Customer#field-Customer.fields.addressesV2)

  OBJECT

  Information about a customer of the shop, such as the customer's contact details, purchase history, and marketing preferences.

  Tracks the customer's total spending through the [`amountSpent`](https://shopify.dev/docs/api/admin-graphql/latest/objects/Customer#field-amountSpent) field and provides access to associated data such as payment methods and subscription contracts.

  ***

  **Caution:** Only use this data if it\&#39;s required for your app\&#39;s functionality. Shopify will restrict \<a href="https://shopify.dev/api/usage/access-scopes">access to scopes\</a> for apps that don\&#39;t have a legitimate use for the associated data.

  ***

* [Customer​Merge​Preview​Default​Fields.addresses](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CustomerMergePreviewDefaultFields#field-CustomerMergePreviewDefaultFields.fields.addresses)

  OBJECT

  The fields that will be kept as part of a customer merge preview.

***

## Possible returns

* edges

  [\[Mailing​Address​Edge!\]!](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/MailingAddressEdge)

  non-null

  The connection between the node and its parent. Each edge contains a minimum of the edge's cursor and the node.

* nodes

  [\[Mailing​Address!\]!](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/MailingAddress)

  non-null

  A list of nodes that are contained in MailingAddressEdge. You can fetch data about an individual node, or you can follow the edges to fetch data about a collection of related nodes. At each node, you specify the fields that you want to retrieve.

* page​Info

  [Page​Info!](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/PageInfo)

  non-null

  An object that’s used to retrieve [cursor information](https://shopify.dev/api/usage/pagination-graphql) about the current page.

***

## Map

### Fields with this connection

* [Customer.addressesV2](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/Customer#field-Customer.fields.addressesV2)
* [Customer​Merge​Preview​Default​Fields.addresses](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CustomerMergePreviewDefaultFields#field-CustomerMergePreviewDefaultFields.fields.addresses)

### Possible returns

* [Mailing​Address​Connection.edges](https://shopify.dev/docs/api/admin-graphql/2026-04/connections/MailingAddressConnection#returns-edges)
* [Mailing​Address​Connection.nodes](https://shopify.dev/docs/api/admin-graphql/2026-04/connections/MailingAddressConnection#returns-nodes)
* [Mailing​Address​Connection.pageInfo](https://shopify.dev/docs/api/admin-graphql/2026-04/connections/MailingAddressConnection#returns-pageInfo)

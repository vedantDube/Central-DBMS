---
title: ProductVariantComponentConnection - GraphQL Admin
description: >-
  An auto-generated type for paginating through multiple
  ProductVariantComponents.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/connections/ProductVariantComponentConnection
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/connections/ProductVariantComponentConnection.md
api_name: admin
api_type: graphql
type: connection
metadata:
  domain: admin
---

# Product​Variant​Component​Connection

connection

An auto-generated type for paginating through multiple ProductVariantComponents.

## Fields with this connection

* [Product​Variant.productVariantComponents](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/ProductVariant#field-ProductVariant.fields.productVariantComponents)

  OBJECT

  The `ProductVariant` object represents a version of a [product](https://shopify.dev/docs/api/admin-graphql/latest/objects/Product) that comes in more than one [option](https://shopify.dev/docs/api/admin-graphql/latest/objects/ProductOption), such as size or color. For example, if a merchant sells t-shirts with options for size and color, then a small, blue t-shirt would be one product variant and a large, blue t-shirt would be another.

  Use the `ProductVariant` object to manage the full lifecycle and configuration of a product's variants. Common use cases for using the `ProductVariant` object include:

  * Tracking inventory for each variant
  * Setting unique prices for each variant
  * Assigning barcodes and SKUs to connect variants to fulfillment services
  * Attaching variant-specific images and media
  * Setting delivery and tax requirements
  * Supporting product bundles, subscriptions, and selling plans

  A `ProductVariant` is associated with a parent [`Product`](https://shopify.dev/docs/api/admin-graphql/latest/objects/Product) object. `ProductVariant` serves as the central link between a product's merchandising configuration, inventory, pricing, fulfillment, and sales channels within the GraphQL Admin API schema. Each variant can reference other GraphQL types such as:

  * [`InventoryItem`](https://shopify.dev/docs/api/admin-graphql/latest/objects/InventoryItem): Used for inventory tracking
  * [`Image`](https://shopify.dev/docs/api/admin-graphql/latest/objects/Image): Used for variant-specific images
  * [`SellingPlanGroup`](https://shopify.dev/docs/api/admin-graphql/latest/objects/SellingPlanGroup): Used for subscriptions and selling plans

  Learn more about [Shopify's product model](https://shopify.dev/docs/apps/build/graphql/migrate/new-product-model/product-model-components).

***

## Possible returns

* edges

  [\[Product​Variant​Component​Edge!\]!](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/ProductVariantComponentEdge)

  non-null

  The connection between the node and its parent. Each edge contains a minimum of the edge's cursor and the node.

* nodes

  [\[Product​Variant​Component!\]!](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/ProductVariantComponent)

  non-null

  A list of nodes that are contained in ProductVariantComponentEdge. You can fetch data about an individual node, or you can follow the edges to fetch data about a collection of related nodes. At each node, you specify the fields that you want to retrieve.

* page​Info

  [Page​Info!](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/PageInfo)

  non-null

  An object that’s used to retrieve [cursor information](https://shopify.dev/api/usage/pagination-graphql) about the current page.

***

## Map

### Fields with this connection

* [Product​Variant.productVariantComponents](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/ProductVariant#field-ProductVariant.fields.productVariantComponents)

### Possible returns

* [Product​Variant​Component​Connection.edges](https://shopify.dev/docs/api/admin-graphql/2026-04/connections/ProductVariantComponentConnection#returns-edges)
* [Product​Variant​Component​Connection.nodes](https://shopify.dev/docs/api/admin-graphql/2026-04/connections/ProductVariantComponentConnection#returns-nodes)
* [Product​Variant​Component​Connection.pageInfo](https://shopify.dev/docs/api/admin-graphql/2026-04/connections/ProductVariantComponentConnection#returns-pageInfo)

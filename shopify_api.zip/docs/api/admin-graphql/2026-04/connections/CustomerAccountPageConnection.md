---
title: CustomerAccountPageConnection - GraphQL Admin
description: An auto-generated type for paginating through multiple CustomerAccountPages.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/connections/CustomerAccountPageConnection
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/connections/CustomerAccountPageConnection.md
api_name: admin
api_type: graphql
type: connection
metadata:
  domain: admin
---

# Customer​Account​Page​Connection

connection

An auto-generated type for paginating through multiple CustomerAccountPages.

## Queries with this connection

* [customer​Account​Pages](https://shopify.dev/docs/api/admin-graphql/2026-04/queries/customerAccountPages)

  query

  List of the shop's customer account pages.

  * after

    [String](https://shopify.dev/docs/api/admin-graphql/2026-04/scalars/String)

    ### Arguments

    The elements that come after the specified [cursor](https://shopify.dev/api/usage/pagination-graphql).

  * before

    [String](https://shopify.dev/docs/api/admin-graphql/2026-04/scalars/String)

    The elements that come before the specified [cursor](https://shopify.dev/api/usage/pagination-graphql).

  * first

    [Int](https://shopify.dev/docs/api/admin-graphql/2026-04/scalars/Int)

    The first `n` elements from the [paginated list](https://shopify.dev/api/usage/pagination-graphql).

  * last

    [Int](https://shopify.dev/docs/api/admin-graphql/2026-04/scalars/Int)

    The last `n` elements from the [paginated list](https://shopify.dev/api/usage/pagination-graphql).

  * reverse

    [Boolean](https://shopify.dev/docs/api/admin-graphql/2026-04/scalars/Boolean)

    Default:false

    Reverse the order of the underlying list.

  ***

***

## Possible returns

* edges

  [\[Customer​Account​Page​Edge!\]!](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CustomerAccountPageEdge)

  non-null

  The connection between the node and its parent. Each edge contains a minimum of the edge's cursor and the node.

* nodes

  [\[Customer​Account​Page!\]!](https://shopify.dev/docs/api/admin-graphql/2026-04/interfaces/CustomerAccountPage)

  non-null

  A list of nodes that are contained in CustomerAccountPageEdge. You can fetch data about an individual node, or you can follow the edges to fetch data about a collection of related nodes. At each node, you specify the fields that you want to retrieve.

* page​Info

  [Page​Info!](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/PageInfo)

  non-null

  An object that’s used to retrieve [cursor information](https://shopify.dev/api/usage/pagination-graphql) about the current page.

***

## Map

### Queries with this connection

* [customer​Account​Pages](https://shopify.dev/docs/api/admin-graphql/2026-04/queries/customerAccountPages)

### Possible returns

* [Customer​Account​Page​Connection.edges](https://shopify.dev/docs/api/admin-graphql/2026-04/connections/CustomerAccountPageConnection#returns-edges)
* [Customer​Account​Page​Connection.nodes](https://shopify.dev/docs/api/admin-graphql/2026-04/connections/CustomerAccountPageConnection#returns-nodes)
* [Customer​Account​Page​Connection.pageInfo](https://shopify.dev/docs/api/admin-graphql/2026-04/connections/CustomerAccountPageConnection#returns-pageInfo)

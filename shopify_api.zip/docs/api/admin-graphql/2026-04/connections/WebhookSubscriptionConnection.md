---
title: WebhookSubscriptionConnection - GraphQL Admin
description: An auto-generated type for paginating through multiple WebhookSubscriptions.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/connections/WebhookSubscriptionConnection
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/connections/WebhookSubscriptionConnection.md
api_name: admin
api_type: graphql
type: connection
metadata:
  domain: admin
---

# Webhook​Subscription​Connection

connection

An auto-generated type for paginating through multiple WebhookSubscriptions.

## Queries with this connection

* [webhook​Subscriptions](https://shopify.dev/docs/api/admin-graphql/2026-04/queries/webhookSubscriptions)

  query

  Retrieves a paginated list of webhook subscriptions created using the API for the current app and shop.

  ***

  **Note:** Returns only shop-scoped subscriptions, not app-scoped subscriptions configured in TOML files.

  ***

  Subscription details include event topics, endpoint URIs, filtering rules, field inclusion settings, and metafield namespace permissions. Results support cursor-based pagination that you can filter by topic, format, or custom search criteria.

  Building an app? If you only use app-specific webhooks, you won't need this. App-specific webhook subscriptions specified in your `shopify.app.toml` may be easier. They are automatically kept up to date by Shopify & require less maintenance. Please read [About managing webhook subscriptions](https://shopify.dev/docs/apps/build/webhooks/subscribe).

  * after

    [String](https://shopify.dev/docs/api/admin-graphql/2026-04/scalars/String)

    ### Arguments

    The elements that come after the specified [cursor](https://shopify.dev/api/usage/pagination-graphql).

  * before

    [String](https://shopify.dev/docs/api/admin-graphql/2026-04/scalars/String)

    The elements that come before the specified [cursor](https://shopify.dev/api/usage/pagination-graphql).

  * callback​Url

    [URL](https://shopify.dev/docs/api/admin-graphql/2026-04/scalars/URL)

    Deprecated

  * first

    [Int](https://shopify.dev/docs/api/admin-graphql/2026-04/scalars/Int)

    The first `n` elements from the [paginated list](https://shopify.dev/api/usage/pagination-graphql).

  * format

    [Webhook​Subscription​Format](https://shopify.dev/docs/api/admin-graphql/2026-04/enums/WebhookSubscriptionFormat)

    Response format to filter by.

  * last

    [Int](https://shopify.dev/docs/api/admin-graphql/2026-04/scalars/Int)

    The last `n` elements from the [paginated list](https://shopify.dev/api/usage/pagination-graphql).

  * query

    [String](https://shopify.dev/docs/api/admin-graphql/2026-04/scalars/String)

    A filter made up of terms, connectives, modifiers, and comparators. You can apply one or more filters to a query. Learn more about [Shopify API search syntax](https://shopify.dev/api/usage/search-syntax).

    * created\_at

      time

    * * id

        id

      * updated\_at

        time

      - Filter by `id` range.

      - Example:
        * `id:1234`
        * `id:>=1234`
        * `id:<=1234`

  * reverse

    [Boolean](https://shopify.dev/docs/api/admin-graphql/2026-04/scalars/Boolean)

    Default:false

    Reverse the order of the underlying list.

  * sort​Key

    [Webhook​Subscription​Sort​Keys](https://shopify.dev/docs/api/admin-graphql/2026-04/enums/WebhookSubscriptionSortKeys)

    Default:CREATED\_AT

    Sort the underlying list using a key. If your query is slow or returns an error, then [try specifying a sort key that matches the field used in the search](https://shopify.dev/api/usage/pagination-graphql#search-performance-considerations).

  * topics

    [\[Webhook​Subscription​Topic!\]](https://shopify.dev/docs/api/admin-graphql/2026-04/enums/WebhookSubscriptionTopic)

    List of webhook subscription topics to filter by.

  * uri

    [String](https://shopify.dev/docs/api/admin-graphql/2026-04/scalars/String)

    URI to filter by. Supports an HTTPS URL, a Google Pub/Sub URI (pubsub://{project-id}:{topic-id}) or an Amazon EventBridge event source ARN.

  ***

***

## Possible returns

* edges

  [\[Webhook​Subscription​Edge!\]!](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/WebhookSubscriptionEdge)

  non-null

  The connection between the node and its parent. Each edge contains a minimum of the edge's cursor and the node.

* nodes

  [\[Webhook​Subscription!\]!](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/WebhookSubscription)

  non-null

  A list of nodes that are contained in WebhookSubscriptionEdge. You can fetch data about an individual node, or you can follow the edges to fetch data about a collection of related nodes. At each node, you specify the fields that you want to retrieve.

* page​Info

  [Page​Info!](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/PageInfo)

  non-null

  An object that’s used to retrieve [cursor information](https://shopify.dev/api/usage/pagination-graphql) about the current page.

***

## Map

### Queries with this connection

* [webhook​Subscriptions](https://shopify.dev/docs/api/admin-graphql/2026-04/queries/webhookSubscriptions)

### Possible returns

* [Webhook​Subscription​Connection.edges](https://shopify.dev/docs/api/admin-graphql/2026-04/connections/WebhookSubscriptionConnection#returns-edges)
* [Webhook​Subscription​Connection.nodes](https://shopify.dev/docs/api/admin-graphql/2026-04/connections/WebhookSubscriptionConnection#returns-nodes)
* [Webhook​Subscription​Connection.pageInfo](https://shopify.dev/docs/api/admin-graphql/2026-04/connections/WebhookSubscriptionConnection#returns-pageInfo)

---
title: CashTrackingSessionConnection - GraphQL Admin
description: An auto-generated type for paginating through multiple CashTrackingSessions.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/connections/CashTrackingSessionConnection
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/connections/CashTrackingSessionConnection.md
api_name: admin
api_type: graphql
type: connection
metadata:
  domain: admin
---

# Cash​Tracking​Session​Connection

connection

An auto-generated type for paginating through multiple CashTrackingSessions.

## Queries with this connection

* [cash​Tracking​Sessions](https://shopify.dev/docs/api/admin-graphql/2026-04/queries/cashTrackingSessions)

  query

  Returns a shop's cash tracking sessions for locations with a POS Pro subscription.

  Tip: To query for cash tracking sessions in bulk, you can [perform a bulk operation](https://shopify.dev/docs/api/usage/bulk-operations/queries).

  * after

    [String](https://shopify.dev/docs/api/admin-graphql/2026-04/scalars/String)

    ### Arguments

    The elements that come after the specified [cursor](https://shopify.dev/api/usage/pagination-graphql).

  * before

    [String](https://shopify.dev/docs/api/admin-graphql/2026-04/scalars/String)

    The elements that come before the specified [cursor](https://shopify.dev/api/usage/pagination-graphql).

  * first

    [Int](https://shopify.dev/docs/api/admin-graphql/2026-04/scalars/Int)

    The first `n` elements from the [paginated list](https://shopify.dev/api/usage/pagination-graphql).

  * last

    [Int](https://shopify.dev/docs/api/admin-graphql/2026-04/scalars/Int)

    The last `n` elements from the [paginated list](https://shopify.dev/api/usage/pagination-graphql).

  * query

    [String](https://shopify.dev/docs/api/admin-graphql/2026-04/scalars/String)

    A filter made up of terms, connectives, modifiers, and comparators. You can apply one or more filters to a query. Learn more about [Shopify API search syntax](https://shopify.dev/api/usage/search-syntax).

    * closing\_time

      time

    * * id

        id

      * location\_id

        id

      - Filter by `id` range.

      - Example:
        * `id:1234`
        * `id:>=1234`
        * `id:<=1234`

    * opening\_time

      time

    * point\_of\_sale\_device\_ids

      string

    * status

      string

  * reverse

    [Boolean](https://shopify.dev/docs/api/admin-graphql/2026-04/scalars/Boolean)

    Default:false

    Reverse the order of the underlying list.

  * sort​Key

    [Cash​Tracking​Sessions​Sort​Keys](https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CashTrackingSessionsSortKeys)

    Default:ID

    Sort the underlying list using a key. If your query is slow or returns an error, then [try specifying a sort key that matches the field used in the search](https://shopify.dev/api/usage/pagination-graphql#search-performance-considerations).

  ***

***

## Possible returns

* edges

  [\[Cash​Tracking​Session​Edge!\]!](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CashTrackingSessionEdge)

  non-null

  The connection between the node and its parent. Each edge contains a minimum of the edge's cursor and the node.

* nodes

  [\[Cash​Tracking​Session!\]!](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CashTrackingSession)

  non-null

  A list of nodes that are contained in CashTrackingSessionEdge. You can fetch data about an individual node, or you can follow the edges to fetch data about a collection of related nodes. At each node, you specify the fields that you want to retrieve.

* page​Info

  [Page​Info!](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/PageInfo)

  non-null

  An object that’s used to retrieve [cursor information](https://shopify.dev/api/usage/pagination-graphql) about the current page.

***

## Map

### Queries with this connection

* [cash​Tracking​Sessions](https://shopify.dev/docs/api/admin-graphql/2026-04/queries/cashTrackingSessions)

### Possible returns

* [Cash​Tracking​Session​Connection.edges](https://shopify.dev/docs/api/admin-graphql/2026-04/connections/CashTrackingSessionConnection#returns-edges)
* [Cash​Tracking​Session​Connection.nodes](https://shopify.dev/docs/api/admin-graphql/2026-04/connections/CashTrackingSessionConnection#returns-nodes)
* [Cash​Tracking​Session​Connection.pageInfo](https://shopify.dev/docs/api/admin-graphql/2026-04/connections/CashTrackingSessionConnection#returns-pageInfo)

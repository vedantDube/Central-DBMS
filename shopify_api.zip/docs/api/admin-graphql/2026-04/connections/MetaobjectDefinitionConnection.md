---
title: MetaobjectDefinitionConnection - GraphQL Admin
description: An auto-generated type for paginating through multiple MetaobjectDefinitions.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/connections/MetaobjectDefinitionConnection
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/connections/MetaobjectDefinitionConnection.md
api_name: admin
api_type: graphql
type: connection
metadata:
  domain: admin
---

# Metaobject​Definition​Connection

connection

An auto-generated type for paginating through multiple MetaobjectDefinitions.

## Queries with this connection

* [metaobject​Definitions](https://shopify.dev/docs/api/admin-graphql/2026-04/queries/metaobjectDefinitions)

  query

  Returns a paginated list of all [`MetaobjectDefinition`](https://shopify.dev/docs/api/admin-graphql/latest/objects/MetaobjectDefinition) objects configured for the store. Metaobject definitions provide the schema for creating custom data structures composed of individual fields. Each definition specifies the field types, access permissions, and capabilities for [`Metaobject`](https://shopify.dev/docs/api/admin-graphql/latest/objects/Metaobject) entries of that type. Use this query to discover available metaobject types before creating or querying metaobject entries.

  Learn more about [managing metaobjects](https://shopify.dev/docs/apps/build/custom-data/metaobjects/manage-metaobjects).

  * after

    [String](https://shopify.dev/docs/api/admin-graphql/2026-04/scalars/String)

    ### Arguments

    The elements that come after the specified [cursor](https://shopify.dev/api/usage/pagination-graphql).

  * before

    [String](https://shopify.dev/docs/api/admin-graphql/2026-04/scalars/String)

    The elements that come before the specified [cursor](https://shopify.dev/api/usage/pagination-graphql).

  * first

    [Int](https://shopify.dev/docs/api/admin-graphql/2026-04/scalars/Int)

    The first `n` elements from the [paginated list](https://shopify.dev/api/usage/pagination-graphql).

  * last

    [Int](https://shopify.dev/docs/api/admin-graphql/2026-04/scalars/Int)

    The last `n` elements from the [paginated list](https://shopify.dev/api/usage/pagination-graphql).

  * reverse

    [Boolean](https://shopify.dev/docs/api/admin-graphql/2026-04/scalars/Boolean)

    Default:false

    Reverse the order of the underlying list.

  ***

***

## Possible returns

* edges

  [\[Metaobject​Definition​Edge!\]!](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/MetaobjectDefinitionEdge)

  non-null

  The connection between the node and its parent. Each edge contains a minimum of the edge's cursor and the node.

* nodes

  [\[Metaobject​Definition!\]!](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/MetaobjectDefinition)

  non-null

  A list of nodes that are contained in MetaobjectDefinitionEdge. You can fetch data about an individual node, or you can follow the edges to fetch data about a collection of related nodes. At each node, you specify the fields that you want to retrieve.

* page​Info

  [Page​Info!](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/PageInfo)

  non-null

  An object that’s used to retrieve [cursor information](https://shopify.dev/api/usage/pagination-graphql) about the current page.

***

## Map

### Queries with this connection

* [metaobject​Definitions](https://shopify.dev/docs/api/admin-graphql/2026-04/queries/metaobjectDefinitions)

### Possible returns

* [Metaobject​Definition​Connection.edges](https://shopify.dev/docs/api/admin-graphql/2026-04/connections/MetaobjectDefinitionConnection#returns-edges)
* [Metaobject​Definition​Connection.nodes](https://shopify.dev/docs/api/admin-graphql/2026-04/connections/MetaobjectDefinitionConnection#returns-nodes)
* [Metaobject​Definition​Connection.pageInfo](https://shopify.dev/docs/api/admin-graphql/2026-04/connections/MetaobjectDefinitionConnection#returns-pageInfo)

---
title: ResourcePublicationConnection - GraphQL Admin
description: An auto-generated type for paginating through multiple ResourcePublications.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/connections/ResourcePublicationConnection
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/connections/ResourcePublicationConnection.md
api_name: admin
api_type: graphql
type: connection
metadata:
  domain: admin
---

# Resource​Publication​Connection

connection

An auto-generated type for paginating through multiple ResourcePublications.

## Fields with this connection

* [Channel.collectionPublicationsV3](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/Channel#field-Channel.fields.collectionPublicationsV3)

  OBJECT

  A connection between a Shopify shop and an external selling platform that supports product syndication and optionally order ingestion. Each channel binds a merchant's account on a specific platform — such as Amazon, eBay, Google, or a point-of-sale system — to the shop, establishing the publishing destination for product feeds.

  Sales Channel applications use [`channelCreate`](https://shopify.dev/docs/api/admin-graphql/latest/mutations/channelCreate) to establish channels after merchant authentication, and can manage multiple channel connections per app. Each channel is bound to a channel specification that declares the platform's regional coverage, capabilities, and requirements.

  Use channels to manage where catalog items are syndicated, track publication status across platforms, and control [`Product`](https://shopify.dev/docs/api/admin-graphql/latest/objects/Product) visibility for different selling destinations.

* [Channel.productPublicationsV3](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/Channel#field-Channel.fields.productPublicationsV3)

  OBJECT

  A connection between a Shopify shop and an external selling platform that supports product syndication and optionally order ingestion. Each channel binds a merchant's account on a specific platform — such as Amazon, eBay, Google, or a point-of-sale system — to the shop, establishing the publishing destination for product feeds.

  Sales Channel applications use [`channelCreate`](https://shopify.dev/docs/api/admin-graphql/latest/mutations/channelCreate) to establish channels after merchant authentication, and can manage multiple channel connections per app. Each channel is bound to a channel specification that declares the platform's regional coverage, capabilities, and requirements.

  Use channels to manage where catalog items are syndicated, track publication status across platforms, and control [`Product`](https://shopify.dev/docs/api/admin-graphql/latest/objects/Product) visibility for different selling destinations.

* [Collection.resourcePublications](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/Collection#field-Collection.fields.resourcePublications)

  OBJECT

  The `Collection` object represents a group of [products](https://shopify.dev/docs/api/admin-graphql/latest/objects/Product) that merchants can organize to make their stores easier to browse and help customers find related products. Collections serve as the primary way to categorize and display products across [online stores](https://shopify.dev/docs/apps/build/online-store), [sales channels](https://shopify.dev/docs/apps/build/sales-channels), and marketing campaigns.

  The `Collection` object provides information to:

  * Organize products by category, season, or promotion.
  * Automate product grouping using rules (for example, by tag, type, or price).
  * Configure product sorting and display order (for example, alphabetical, best-selling, price, or manual).
  * Manage collection visibility and publication across sales channels.
  * Add rich descriptions, images, and metadata to enhance discovery.

  ***

  **Note:** Collections are unpublished by default. To make them available to customers, use the \<a href="https://shopify.dev/docs/api/admin-graphql/latest/mutations/publishablePublish">\<code>\<span class="PreventFireFoxApplyingGapToWBR">publishable\<wbr/>Publish\</span>\</code>\</a> mutation after creation.

  ***

  Collections can be displayed in a store with Shopify's theme system through [Liquid templates](https://shopify.dev/docs/storefronts/themes/architecture/templates/collection) and can be customized with [template suffixes](https://shopify.dev/docs/storefronts/themes/architecture/templates/alternate-templates) for unique layouts. They also support advanced features like translated content, resource feedback, and contextual publication for location-based catalogs.

  Learn about [using metafields with collection conditions](https://shopify.dev/docs/apps/build/custom-data/metafields/use-metafield-capabilities).

* [Product.resourcePublications](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/Product#field-Product.fields.resourcePublications)

  OBJECT

  The `Product` object lets you manage products in a merchant’s store.

  Products are the goods and services that merchants offer to customers. They can include various details such as title, description, price, images, and options such as size or color. You can use [product variants](https://shopify.dev/docs/api/admin-graphql/latest/objects/productvariant) to create or update different versions of the same product. You can also add or update product [media](https://shopify.dev/docs/api/admin-graphql/latest/interfaces/media). Products can be organized by grouping them into a [collection](https://shopify.dev/docs/api/admin-graphql/latest/objects/collection).

  Learn more about working with [Shopify's product model](https://shopify.dev/docs/apps/build/graphql/migrate/new-product-model/product-model-components), including limitations and considerations.

* [Publication.collectionPublicationsV3](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/Publication#field-Publication.fields.collectionPublicationsV3)

  OBJECT

  A group of [products](https://shopify.dev/docs/api/admin-graphql/latest/objects/Product) and [collections](https://shopify.dev/docs/api/admin-graphql/latest/objects/Collection) that are published to an app.

  Each publication manages which products and collections display on its associated [`Channel`](https://shopify.dev/docs/api/admin-graphql/latest/objects/Channel). Merchants can automatically publish products when they're created if [`autoPublish`](https://shopify.dev/docs/api/admin-graphql/latest/objects/Publication#field-Publication.fields.autoPublish) is enabled, or manually control publication through publication records.

  Publications support scheduled publishing through future publish dates for online store channels, allowing merchants to coordinate product launches and promotional campaigns. The [`catalog`](https://shopify.dev/docs/api/admin-graphql/latest/objects/Publication#field-Publication.fields.catalog) field links to pricing and availability rules specific to that publication's context.

* [Publication.productPublicationsV3](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/Publication#field-Publication.fields.productPublicationsV3)

  OBJECT

  A group of [products](https://shopify.dev/docs/api/admin-graphql/latest/objects/Product) and [collections](https://shopify.dev/docs/api/admin-graphql/latest/objects/Collection) that are published to an app.

  Each publication manages which products and collections display on its associated [`Channel`](https://shopify.dev/docs/api/admin-graphql/latest/objects/Channel). Merchants can automatically publish products when they're created if [`autoPublish`](https://shopify.dev/docs/api/admin-graphql/latest/objects/Publication#field-Publication.fields.autoPublish) is enabled, or manually control publication through publication records.

  Publications support scheduled publishing through future publish dates for online store channels, allowing merchants to coordinate product launches and promotional campaigns. The [`catalog`](https://shopify.dev/docs/api/admin-graphql/latest/objects/Publication#field-Publication.fields.catalog) field links to pricing and availability rules specific to that publication's context.

* [Publishable.resourcePublications](https://shopify.dev/docs/api/admin-graphql/2026-04/interfaces/Publishable#fields-resourcePublications)

  INTERFACE

  Represents a resource that can be published to a channel. A publishable resource can be either a Product or Collection.

***

## Possible returns

* edges

  [\[Resource​Publication​Edge!\]!](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/ResourcePublicationEdge)

  non-null

  The connection between the node and its parent. Each edge contains a minimum of the edge's cursor and the node.

* nodes

  [\[Resource​Publication!\]!](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/ResourcePublication)

  non-null

  A list of nodes that are contained in ResourcePublicationEdge. You can fetch data about an individual node, or you can follow the edges to fetch data about a collection of related nodes. At each node, you specify the fields that you want to retrieve.

* page​Info

  [Page​Info!](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/PageInfo)

  non-null

  An object that’s used to retrieve [cursor information](https://shopify.dev/api/usage/pagination-graphql) about the current page.

***

## Map

### Fields with this connection

* [Channel.collectionPublicationsV3](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/Channel#field-Channel.fields.collectionPublicationsV3)
* [Channel.productPublicationsV3](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/Channel#field-Channel.fields.productPublicationsV3)
* [Collection.resourcePublications](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/Collection#field-Collection.fields.resourcePublications)
* [Product.resourcePublications](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/Product#field-Product.fields.resourcePublications)
* [Publication.collectionPublicationsV3](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/Publication#field-Publication.fields.collectionPublicationsV3)
* [Publication.productPublicationsV3](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/Publication#field-Publication.fields.productPublicationsV3)
* [Publishable.resourcePublications](https://shopify.dev/docs/api/admin-graphql/2026-04/interfaces/Publishable#fields-resourcePublications)

### Possible returns

* [Resource​Publication​Connection.edges](https://shopify.dev/docs/api/admin-graphql/2026-04/connections/ResourcePublicationConnection#returns-edges)
* [Resource​Publication​Connection.nodes](https://shopify.dev/docs/api/admin-graphql/2026-04/connections/ResourcePublicationConnection#returns-nodes)
* [Resource​Publication​Connection.pageInfo](https://shopify.dev/docs/api/admin-graphql/2026-04/connections/ResourcePublicationConnection#returns-pageInfo)

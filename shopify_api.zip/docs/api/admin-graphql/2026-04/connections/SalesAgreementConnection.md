---
title: SalesAgreementConnection - GraphQL Admin
description: An auto-generated type for paginating through multiple SalesAgreements.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/connections/SalesAgreementConnection
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/connections/SalesAgreementConnection.md
api_name: admin
api_type: graphql
type: connection
metadata:
  domain: admin
---

# Sales​Agreement​Connection

connection

An auto-generated type for paginating through multiple SalesAgreements.

## Fields with this connection

* [Order.agreements](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/Order#field-Order.fields.agreements)

  OBJECT

  The `Order` object represents a customer's request to purchase one or more products from a store. Use the `Order` object to handle the complete purchase lifecycle from checkout to fulfillment.

  Use the `Order` object when you need to:

  * Display order details on customer account pages or admin dashboards.
  * Create orders for phone sales, wholesale customers, or subscription services.
  * Update order information like shipping addresses, notes, or fulfillment status.
  * Process returns, exchanges, and partial refunds.
  * Generate invoices, receipts, and shipping labels.

  The `Order` object serves as the central hub connecting customer information, product details, payment processing, and fulfillment data within the GraphQL Admin API schema.

  ***

  **Note:** Only the last 60 days\&#39; worth of orders from a store are accessible from the \<code>Order\</code> object by default. If you want to access older records, then you need to \<a href="https://shopify.dev/docs/api/usage/access-scopes#orders-permissions">request access to all orders\</a>. If your app is granted access, then you can add the \<code>\<span class="PreventFireFoxApplyingGapToWBR">read\<wbr/>\_all\<wbr/>\_orders\</span>\</code>, \<code>\<span class="PreventFireFoxApplyingGapToWBR">read\<wbr/>\_orders\</span>\</code>, and \<code>\<span class="PreventFireFoxApplyingGapToWBR">write\<wbr/>\_orders\</span>\</code> scopes.

  ***

  ***

  **Caution:** Only use orders data if it\&#39;s required for your app\&#39;s functionality. Shopify will restrict \<a href="https://shopify.dev/docs/api/usage/access-scopes#requesting-specific-permissions">access to scopes\</a> for apps that don\&#39;t have a legitimate use for the associated data.

  ***

  Learn more about [building apps for orders and fulfillment](https://shopify.dev/docs/apps/build/orders-fulfillment).

***

## Possible returns

* edges

  [\[Sales​Agreement​Edge!\]!](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/SalesAgreementEdge)

  non-null

  The connection between the node and its parent. Each edge contains a minimum of the edge's cursor and the node.

* nodes

  [\[Sales​Agreement!\]!](https://shopify.dev/docs/api/admin-graphql/2026-04/interfaces/SalesAgreement)

  non-null

  A list of nodes that are contained in SalesAgreementEdge. You can fetch data about an individual node, or you can follow the edges to fetch data about a collection of related nodes. At each node, you specify the fields that you want to retrieve.

* page​Info

  [Page​Info!](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/PageInfo)

  non-null

  An object that’s used to retrieve [cursor information](https://shopify.dev/api/usage/pagination-graphql) about the current page.

***

## Map

### Fields with this connection

* [Order.agreements](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/Order#field-Order.fields.agreements)

### Possible returns

* [Sales​Agreement​Connection.edges](https://shopify.dev/docs/api/admin-graphql/2026-04/connections/SalesAgreementConnection#returns-edges)
* [Sales​Agreement​Connection.nodes](https://shopify.dev/docs/api/admin-graphql/2026-04/connections/SalesAgreementConnection#returns-nodes)
* [Sales​Agreement​Connection.pageInfo](https://shopify.dev/docs/api/admin-graphql/2026-04/connections/SalesAgreementConnection#returns-pageInfo)

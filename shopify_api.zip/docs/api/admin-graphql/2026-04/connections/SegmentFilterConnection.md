---
title: SegmentFilterConnection - GraphQL Admin
description: An auto-generated type for paginating through multiple SegmentFilters.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/connections/SegmentFilterConnection
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/connections/SegmentFilterConnection.md
api_name: admin
api_type: graphql
type: connection
metadata:
  domain: admin
---

# Segment​Filter​Connection

connection

An auto-generated type for paginating through multiple SegmentFilters.

## Queries with this connection

* [segment​Filters](https://shopify.dev/docs/api/admin-graphql/2026-04/queries/segmentFilters)

  query

  A list of filters.

  * after

    [String](https://shopify.dev/docs/api/admin-graphql/2026-04/scalars/String)

    ### Arguments

    The elements that come after the specified [cursor](https://shopify.dev/api/usage/pagination-graphql).

  * before

    [String](https://shopify.dev/docs/api/admin-graphql/2026-04/scalars/String)

    The elements that come before the specified [cursor](https://shopify.dev/api/usage/pagination-graphql).

  * first

    [Int](https://shopify.dev/docs/api/admin-graphql/2026-04/scalars/Int)

    The first `n` elements from the [paginated list](https://shopify.dev/api/usage/pagination-graphql).

  * last

    [Int](https://shopify.dev/docs/api/admin-graphql/2026-04/scalars/Int)

    The last `n` elements from the [paginated list](https://shopify.dev/api/usage/pagination-graphql).

  ***

* [segment​Filter​Suggestions](https://shopify.dev/docs/api/admin-graphql/2026-04/queries/segmentFilterSuggestions)

  query

  A list of filter suggestions associated with a segment. A segment is a group of members (commonly customers) that meet specific criteria.

  * after

    [String](https://shopify.dev/docs/api/admin-graphql/2026-04/scalars/String)

    ### Arguments

    The elements that come after the specified [cursor](https://shopify.dev/api/usage/pagination-graphql).

  * first

    [Int!](https://shopify.dev/docs/api/admin-graphql/2026-04/scalars/Int)

    required

    The first `n` elements from the [paginated list](https://shopify.dev/api/usage/pagination-graphql).

  * search

    [String!](https://shopify.dev/docs/api/admin-graphql/2026-04/scalars/String)

    required

    Returns the elements of a list by keyword or term.

  ***

***

## Possible returns

* edges

  [\[Segment​Filter​Edge!\]!](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/SegmentFilterEdge)

  non-null

  The connection between the node and its parent. Each edge contains a minimum of the edge's cursor and the node.

* nodes

  [\[Segment​Filter!\]!](https://shopify.dev/docs/api/admin-graphql/2026-04/interfaces/SegmentFilter)

  non-null

  A list of nodes that are contained in SegmentFilterEdge. You can fetch data about an individual node, or you can follow the edges to fetch data about a collection of related nodes. At each node, you specify the fields that you want to retrieve.

* page​Info

  [Page​Info!](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/PageInfo)

  non-null

  An object that’s used to retrieve [cursor information](https://shopify.dev/api/usage/pagination-graphql) about the current page.

***

## Map

### Queries with this connection

* [segment​Filter​Suggestions](https://shopify.dev/docs/api/admin-graphql/2026-04/queries/segmentFilterSuggestions)
* [segment​Filters](https://shopify.dev/docs/api/admin-graphql/2026-04/queries/segmentFilters)

### Possible returns

* [Segment​Filter​Connection.edges](https://shopify.dev/docs/api/admin-graphql/2026-04/connections/SegmentFilterConnection#returns-edges)
* [Segment​Filter​Connection.nodes](https://shopify.dev/docs/api/admin-graphql/2026-04/connections/SegmentFilterConnection#returns-nodes)
* [Segment​Filter​Connection.pageInfo](https://shopify.dev/docs/api/admin-graphql/2026-04/connections/SegmentFilterConnection#returns-pageInfo)

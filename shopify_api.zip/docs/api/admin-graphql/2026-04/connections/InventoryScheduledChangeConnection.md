---
title: InventoryScheduledChangeConnection - GraphQL Admin
description: >-
  An auto-generated type for paginating through multiple
  InventoryScheduledChanges.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/connections/InventoryScheduledChangeConnection
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/connections/InventoryScheduledChangeConnection.md
api_name: admin
api_type: graphql
type: connection
metadata:
  domain: admin
---

# Inventory​Scheduled​Change​Connection

connection

An auto-generated type for paginating through multiple InventoryScheduledChanges.

## Fields with this connection

* [Inventory​Level.scheduledChanges](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/InventoryLevel#field-InventoryLevel.fields.scheduledChanges)

  OBJECT

  Deprecated

***

## Possible returns

* edges

  [\[Inventory​Scheduled​Change​Edge!\]!](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/InventoryScheduledChangeEdge)

  non-null

  The connection between the node and its parent. Each edge contains a minimum of the edge's cursor and the node.

* nodes

  [\[Inventory​Scheduled​Change!\]!](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/InventoryScheduledChange)

  non-null

  A list of nodes that are contained in InventoryScheduledChangeEdge. You can fetch data about an individual node, or you can follow the edges to fetch data about a collection of related nodes. At each node, you specify the fields that you want to retrieve.

* page​Info

  [Page​Info!](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/PageInfo)

  non-null

  An object that’s used to retrieve [cursor information](https://shopify.dev/api/usage/pagination-graphql) about the current page.

***

## Map

### Possible returns

* [Inventory​Scheduled​Change​Connection.edges](https://shopify.dev/docs/api/admin-graphql/2026-04/connections/InventoryScheduledChangeConnection#returns-edges)
* [Inventory​Scheduled​Change​Connection.nodes](https://shopify.dev/docs/api/admin-graphql/2026-04/connections/InventoryScheduledChangeConnection#returns-nodes)
* [Inventory​Scheduled​Change​Connection.pageInfo](https://shopify.dev/docs/api/admin-graphql/2026-04/connections/InventoryScheduledChangeConnection#returns-pageInfo)

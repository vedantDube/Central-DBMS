---
title: PaymentCustomizationConnection - GraphQL Admin
description: An auto-generated type for paginating through multiple PaymentCustomizations.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/connections/PaymentCustomizationConnection
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/connections/PaymentCustomizationConnection.md
api_name: admin
api_type: graphql
type: connection
metadata:
  domain: admin
---

# Payment​Customization​Connection

connection

An auto-generated type for paginating through multiple PaymentCustomizations.

## Queries with this connection

* [payment​Customizations](https://shopify.dev/docs/api/admin-graphql/2026-04/queries/paymentCustomizations)

  query

  The payment customizations.

  * after

    [String](https://shopify.dev/docs/api/admin-graphql/2026-04/scalars/String)

    ### Arguments

    The elements that come after the specified [cursor](https://shopify.dev/api/usage/pagination-graphql).

  * before

    [String](https://shopify.dev/docs/api/admin-graphql/2026-04/scalars/String)

    The elements that come before the specified [cursor](https://shopify.dev/api/usage/pagination-graphql).

  * first

    [Int](https://shopify.dev/docs/api/admin-graphql/2026-04/scalars/Int)

    The first `n` elements from the [paginated list](https://shopify.dev/api/usage/pagination-graphql).

  * last

    [Int](https://shopify.dev/docs/api/admin-graphql/2026-04/scalars/Int)

    The last `n` elements from the [paginated list](https://shopify.dev/api/usage/pagination-graphql).

  * query

    [String](https://shopify.dev/docs/api/admin-graphql/2026-04/scalars/String)

    A filter made up of terms, connectives, modifiers, and comparators. You can apply one or more filters to a query. Learn more about [Shopify API search syntax](https://shopify.dev/api/usage/search-syntax).

    * enabled

      boolean

    * function\_id

      string

    * id

      id

      Filter by `id` range.

      Example:

      * `id:1234`
      * `id:>=1234`
      * `id:<=1234`

  * reverse

    [Boolean](https://shopify.dev/docs/api/admin-graphql/2026-04/scalars/Boolean)

    Default:false

    Reverse the order of the underlying list.

  ***

***

## Possible returns

* edges

  [\[Payment​Customization​Edge!\]!](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/PaymentCustomizationEdge)

  non-null

  The connection between the node and its parent. Each edge contains a minimum of the edge's cursor and the node.

* nodes

  [\[Payment​Customization!\]!](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/PaymentCustomization)

  non-null

  A list of nodes that are contained in PaymentCustomizationEdge. You can fetch data about an individual node, or you can follow the edges to fetch data about a collection of related nodes. At each node, you specify the fields that you want to retrieve.

* page​Info

  [Page​Info!](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/PageInfo)

  non-null

  An object that’s used to retrieve [cursor information](https://shopify.dev/api/usage/pagination-graphql) about the current page.

***

## Map

### Queries with this connection

* [payment​Customizations](https://shopify.dev/docs/api/admin-graphql/2026-04/queries/paymentCustomizations)

### Possible returns

* [Payment​Customization​Connection.edges](https://shopify.dev/docs/api/admin-graphql/2026-04/connections/PaymentCustomizationConnection#returns-edges)
* [Payment​Customization​Connection.nodes](https://shopify.dev/docs/api/admin-graphql/2026-04/connections/PaymentCustomizationConnection#returns-nodes)
* [Payment​Customization​Connection.pageInfo](https://shopify.dev/docs/api/admin-graphql/2026-04/connections/PaymentCustomizationConnection#returns-pageInfo)

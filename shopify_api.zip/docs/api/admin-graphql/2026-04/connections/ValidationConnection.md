---
title: ValidationConnection - GraphQL Admin
description: An auto-generated type for paginating through multiple Validations.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/connections/ValidationConnection
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/connections/ValidationConnection.md
api_name: admin
api_type: graphql
type: connection
metadata:
  domain: admin
---

# Validation​Connection

connection

An auto-generated type for paginating through multiple Validations.

## Queries with this connection

* [validations](https://shopify.dev/docs/api/admin-graphql/2026-04/queries/validations)

  query

  Validations available on the shop.

  * after

    [String](https://shopify.dev/docs/api/admin-graphql/2026-04/scalars/String)

    ### Arguments

    The elements that come after the specified [cursor](https://shopify.dev/api/usage/pagination-graphql).

  * before

    [String](https://shopify.dev/docs/api/admin-graphql/2026-04/scalars/String)

    The elements that come before the specified [cursor](https://shopify.dev/api/usage/pagination-graphql).

  * first

    [Int](https://shopify.dev/docs/api/admin-graphql/2026-04/scalars/Int)

    The first `n` elements from the [paginated list](https://shopify.dev/api/usage/pagination-graphql).

  * last

    [Int](https://shopify.dev/docs/api/admin-graphql/2026-04/scalars/Int)

    The last `n` elements from the [paginated list](https://shopify.dev/api/usage/pagination-graphql).

  * reverse

    [Boolean](https://shopify.dev/docs/api/admin-graphql/2026-04/scalars/Boolean)

    Default:false

    Reverse the order of the underlying list.

  * sort​Key

    [Validation​Sort​Keys](https://shopify.dev/docs/api/admin-graphql/2026-04/enums/ValidationSortKeys)

    Default:ID

    Sort the underlying list using a key. If your query is slow or returns an error, then [try specifying a sort key that matches the field used in the search](https://shopify.dev/api/usage/pagination-graphql#search-performance-considerations).

  ***

***

## Possible returns

* edges

  [\[Validation​Edge!\]!](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/ValidationEdge)

  non-null

  The connection between the node and its parent. Each edge contains a minimum of the edge's cursor and the node.

* nodes

  [\[Validation!\]!](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/Validation)

  non-null

  A list of nodes that are contained in ValidationEdge. You can fetch data about an individual node, or you can follow the edges to fetch data about a collection of related nodes. At each node, you specify the fields that you want to retrieve.

* page​Info

  [Page​Info!](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/PageInfo)

  non-null

  An object that’s used to retrieve [cursor information](https://shopify.dev/api/usage/pagination-graphql) about the current page.

***

## Map

### Queries with this connection

* [validations](https://shopify.dev/docs/api/admin-graphql/2026-04/queries/validations)

### Possible returns

* [Validation​Connection.edges](https://shopify.dev/docs/api/admin-graphql/2026-04/connections/ValidationConnection#returns-edges)
* [Validation​Connection.nodes](https://shopify.dev/docs/api/admin-graphql/2026-04/connections/ValidationConnection#returns-nodes)
* [Validation​Connection.pageInfo](https://shopify.dev/docs/api/admin-graphql/2026-04/connections/ValidationConnection#returns-pageInfo)

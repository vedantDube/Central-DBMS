---
title: AppDiscountTypeConnection - GraphQL Admin
description: An auto-generated type for paginating through multiple AppDiscountTypes.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/connections/AppDiscountTypeConnection
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/connections/AppDiscountTypeConnection.md
api_name: admin
api_type: graphql
type: connection
metadata:
  domain: admin
---

# App​Discount​Type​Connection

connection

An auto-generated type for paginating through multiple AppDiscountTypes.

## Queries with this connection

* [app​Discount​Types​Nodes](https://shopify.dev/docs/api/admin-graphql/2026-04/queries/appDiscountTypesNodes)

  query

  A list of app discount types installed by apps.

  * after

    [String](https://shopify.dev/docs/api/admin-graphql/2026-04/scalars/String)

    ### Arguments

    The elements that come after the specified [cursor](https://shopify.dev/api/usage/pagination-graphql).

  * before

    [String](https://shopify.dev/docs/api/admin-graphql/2026-04/scalars/String)

    The elements that come before the specified [cursor](https://shopify.dev/api/usage/pagination-graphql).

  * first

    [Int](https://shopify.dev/docs/api/admin-graphql/2026-04/scalars/Int)

    The first `n` elements from the [paginated list](https://shopify.dev/api/usage/pagination-graphql).

  * last

    [Int](https://shopify.dev/docs/api/admin-graphql/2026-04/scalars/Int)

    The last `n` elements from the [paginated list](https://shopify.dev/api/usage/pagination-graphql).

  * reverse

    [Boolean](https://shopify.dev/docs/api/admin-graphql/2026-04/scalars/Boolean)

    Default:false

    Reverse the order of the underlying list.

  ***

***

## Possible returns

* edges

  [\[App​Discount​Type​Edge!\]!](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/AppDiscountTypeEdge)

  non-null

  The connection between the node and its parent. Each edge contains a minimum of the edge's cursor and the node.

* nodes

  [\[App​Discount​Type!\]!](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/AppDiscountType)

  non-null

  A list of nodes that are contained in AppDiscountTypeEdge. You can fetch data about an individual node, or you can follow the edges to fetch data about a collection of related nodes. At each node, you specify the fields that you want to retrieve.

* page​Info

  [Page​Info!](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/PageInfo)

  non-null

  An object that’s used to retrieve [cursor information](https://shopify.dev/api/usage/pagination-graphql) about the current page.

***

## Map

### Queries with this connection

* [app​Discount​Types​Nodes](https://shopify.dev/docs/api/admin-graphql/2026-04/queries/appDiscountTypesNodes)

### Possible returns

* [App​Discount​Type​Connection.edges](https://shopify.dev/docs/api/admin-graphql/2026-04/connections/AppDiscountTypeConnection#returns-edges)
* [App​Discount​Type​Connection.nodes](https://shopify.dev/docs/api/admin-graphql/2026-04/connections/AppDiscountTypeConnection#returns-nodes)
* [App​Discount​Type​Connection.pageInfo](https://shopify.dev/docs/api/admin-graphql/2026-04/connections/AppDiscountTypeConnection#returns-pageInfo)

---
title: ArticleAuthorConnection - GraphQL Admin
description: An auto-generated type for paginating through multiple ArticleAuthors.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/connections/ArticleAuthorConnection
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/connections/ArticleAuthorConnection.md
api_name: admin
api_type: graphql
type: connection
metadata:
  domain: admin
---

# Article​Author​Connection

connection

An auto-generated type for paginating through multiple ArticleAuthors.

## Queries with this connection

* [article​Authors](https://shopify.dev/docs/api/admin-graphql/2026-04/queries/articleAuthors)

  query

  List of article authors for the shop.

  * after

    [String](https://shopify.dev/docs/api/admin-graphql/2026-04/scalars/String)

    ### Arguments

    The elements that come after the specified [cursor](https://shopify.dev/api/usage/pagination-graphql).

  * before

    [String](https://shopify.dev/docs/api/admin-graphql/2026-04/scalars/String)

    The elements that come before the specified [cursor](https://shopify.dev/api/usage/pagination-graphql).

  * first

    [Int](https://shopify.dev/docs/api/admin-graphql/2026-04/scalars/Int)

    The first `n` elements from the [paginated list](https://shopify.dev/api/usage/pagination-graphql).

  * last

    [Int](https://shopify.dev/docs/api/admin-graphql/2026-04/scalars/Int)

    The last `n` elements from the [paginated list](https://shopify.dev/api/usage/pagination-graphql).

  * reverse

    [Boolean](https://shopify.dev/docs/api/admin-graphql/2026-04/scalars/Boolean)

    Default:false

    Reverse the order of the underlying list.

  ***

***

## Possible returns

* edges

  [\[Article​Author​Edge!\]!](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/ArticleAuthorEdge)

  non-null

  The connection between the node and its parent. Each edge contains a minimum of the edge's cursor and the node.

* nodes

  [\[Article​Author!\]!](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/ArticleAuthor)

  non-null

  A list of nodes that are contained in ArticleAuthorEdge. You can fetch data about an individual node, or you can follow the edges to fetch data about a collection of related nodes. At each node, you specify the fields that you want to retrieve.

* page​Info

  [Page​Info!](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/PageInfo)

  non-null

  An object that’s used to retrieve [cursor information](https://shopify.dev/api/usage/pagination-graphql) about the current page.

***

## Map

### Queries with this connection

* [article​Authors](https://shopify.dev/docs/api/admin-graphql/2026-04/queries/articleAuthors)

### Possible returns

* [Article​Author​Connection.edges](https://shopify.dev/docs/api/admin-graphql/2026-04/connections/ArticleAuthorConnection#returns-edges)
* [Article​Author​Connection.nodes](https://shopify.dev/docs/api/admin-graphql/2026-04/connections/ArticleAuthorConnection#returns-nodes)
* [Article​Author​Connection.pageInfo](https://shopify.dev/docs/api/admin-graphql/2026-04/connections/ArticleAuthorConnection#returns-pageInfo)

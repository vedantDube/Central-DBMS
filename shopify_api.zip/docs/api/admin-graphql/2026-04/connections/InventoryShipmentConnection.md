---
title: InventoryShipmentConnection - GraphQL Admin
description: An auto-generated type for paginating through multiple InventoryShipments.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/connections/InventoryShipmentConnection
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/connections/InventoryShipmentConnection.md
api_name: admin
api_type: graphql
type: connection
metadata:
  domain: admin
---

# Inventory​Shipment​Connection

connection

An auto-generated type for paginating through multiple InventoryShipments.

## Fields with this connection

* [Inventory​Transfer.shipments](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/InventoryTransfer#field-InventoryTransfer.fields.shipments)

  OBJECT

  Tracks the movement of [`InventoryItem`](https://shopify.dev/docs/api/admin-graphql/latest/objects/InventoryItem) objects between [`Location`](https://shopify.dev/docs/api/admin-graphql/latest/objects/Location) objects. A transfer includes origin and destination information, [`InventoryTransferLineItem`](https://shopify.dev/docs/api/admin-graphql/latest/objects/InventoryTransferLineItem) objects with quantities, and shipment details.

  Transfers progress through multiple [`statuses`](https://shopify.dev/docs/api/admin-graphql/latest/enums/InventoryTransferStatus). The transfer maintains [`LocationSnapshot`](https://shopify.dev/docs/api/admin-graphql/latest/objects/LocationSnapshot) objects of location details to preserve historical data even if locations change or are deleted later.

***

## Queries with this connection

* [inventory​Shipments](https://shopify.dev/docs/api/admin-graphql/2026-04/queries/inventoryShipments)

  query

  Returns a paginated list of [`InventoryShipment`](https://shopify.dev/docs/api/admin-graphql/latest/objects/InventoryShipment) objects.

  Supports filtering by barcode (e.g. `barcode:"12345"`), status (e.g. `status:"draft"` or `status:"in_transit"`), and destination (e.g. `destination_id:12345`).

  * after

    [String](https://shopify.dev/docs/api/admin-graphql/2026-04/scalars/String)

    ### Arguments

    The elements that come after the specified [cursor](https://shopify.dev/api/usage/pagination-graphql).

  * before

    [String](https://shopify.dev/docs/api/admin-graphql/2026-04/scalars/String)

    The elements that come before the specified [cursor](https://shopify.dev/api/usage/pagination-graphql).

  * first

    [Int](https://shopify.dev/docs/api/admin-graphql/2026-04/scalars/Int)

    The first `n` elements from the [paginated list](https://shopify.dev/api/usage/pagination-graphql).

  * last

    [Int](https://shopify.dev/docs/api/admin-graphql/2026-04/scalars/Int)

    The last `n` elements from the [paginated list](https://shopify.dev/api/usage/pagination-graphql).

  * query

    [String](https://shopify.dev/docs/api/admin-graphql/2026-04/scalars/String)

    A filter made up of terms, connectives, modifiers, and comparators. You can apply one or more filters to a query. Learn more about [Shopify API search syntax](https://shopify.dev/api/usage/search-syntax).

    * barcode

      string

    * destination\_id

      id

    * * id

        id

      * status

        string

      - Filter by `id` range.

      - Example:
        * `id:1234`
        * `id:>=1234`
        * `id:<=1234`

    * tracking\_number

      string

  * sort​Key

    [Inventory​Shipment​Sort​Keys](https://shopify.dev/docs/api/admin-graphql/2026-04/enums/InventoryShipmentSortKeys)

    Default:ID

    Sort the underlying list using a key. If your query is slow or returns an error, then [try specifying a sort key that matches the field used in the search](https://shopify.dev/api/usage/pagination-graphql#search-performance-considerations).

  ***

***

## Possible returns

* edges

  [\[Inventory​Shipment​Edge!\]!](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/InventoryShipmentEdge)

  non-null

  The connection between the node and its parent. Each edge contains a minimum of the edge's cursor and the node.

* nodes

  [\[Inventory​Shipment!\]!](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/InventoryShipment)

  non-null

  A list of nodes that are contained in InventoryShipmentEdge. You can fetch data about an individual node, or you can follow the edges to fetch data about a collection of related nodes. At each node, you specify the fields that you want to retrieve.

* page​Info

  [Page​Info!](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/PageInfo)

  non-null

  An object that’s used to retrieve [cursor information](https://shopify.dev/api/usage/pagination-graphql) about the current page.

***

## Map

### Fields with this connection

* [Inventory​Transfer.shipments](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/InventoryTransfer#field-InventoryTransfer.fields.shipments)

### Queries with this connection

* [inventory​Shipments](https://shopify.dev/docs/api/admin-graphql/2026-04/queries/inventoryShipments)

### Possible returns

* [Inventory​Shipment​Connection.edges](https://shopify.dev/docs/api/admin-graphql/2026-04/connections/InventoryShipmentConnection#returns-edges)
* [Inventory​Shipment​Connection.nodes](https://shopify.dev/docs/api/admin-graphql/2026-04/connections/InventoryShipmentConnection#returns-nodes)
* [Inventory​Shipment​Connection.pageInfo](https://shopify.dev/docs/api/admin-graphql/2026-04/connections/InventoryShipmentConnection#returns-pageInfo)

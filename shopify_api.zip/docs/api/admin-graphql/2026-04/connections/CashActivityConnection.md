---
title: CashActivityConnection - GraphQL Admin
description: An auto-generated type for paginating through multiple CashActivities.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/connections/CashActivityConnection
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/connections/CashActivityConnection.md
api_name: admin
api_type: graphql
type: connection
metadata:
  domain: admin
---

# Cash​Activity​Connection

connection

An auto-generated type for paginating through multiple CashActivities.

## Fields with this connection

* [Cash​Drawer.cashActivities](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CashDrawer#field-CashDrawer.fields.cashActivities)

  OBJECT

  A cash drawer for cash management.

* [Point​Of​Sale​Device​Payment​Session.cashActivities](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/PointOfSaleDevicePaymentSession#field-PointOfSaleDevicePaymentSession.fields.cashActivities)

  OBJECT

  Tracks the payment activity for a point of sale device.

***

## Possible returns

* edges

  [\[Cash​Activity​Edge!\]!](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CashActivityEdge)

  non-null

  The connection between the node and its parent. Each edge contains a minimum of the edge's cursor and the node.

* nodes

  [\[Cash​Activity!\]!](https://shopify.dev/docs/api/admin-graphql/2026-04/interfaces/CashActivity)

  non-null

  A list of nodes that are contained in CashActivityEdge. You can fetch data about an individual node, or you can follow the edges to fetch data about a collection of related nodes. At each node, you specify the fields that you want to retrieve.

* page​Info

  [Page​Info!](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/PageInfo)

  non-null

  An object that’s used to retrieve [cursor information](https://shopify.dev/api/usage/pagination-graphql) about the current page.

***

## Map

### Fields with this connection

* [Cash​Drawer.cashActivities](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CashDrawer#field-CashDrawer.fields.cashActivities)
* [Point​Of​Sale​Device​Payment​Session.cashActivities](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/PointOfSaleDevicePaymentSession#field-PointOfSaleDevicePaymentSession.fields.cashActivities)

### Possible returns

* [Cash​Activity​Connection.edges](https://shopify.dev/docs/api/admin-graphql/2026-04/connections/CashActivityConnection#returns-edges)
* [Cash​Activity​Connection.nodes](https://shopify.dev/docs/api/admin-graphql/2026-04/connections/CashActivityConnection#returns-nodes)
* [Cash​Activity​Connection.pageInfo](https://shopify.dev/docs/api/admin-graphql/2026-04/connections/CashActivityConnection#returns-pageInfo)

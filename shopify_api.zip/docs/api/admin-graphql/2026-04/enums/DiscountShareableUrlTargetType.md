---
title: DiscountShareableUrlTargetType - GraphQL Admin
description: The type of page where a shareable discount URL lands.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/DiscountShareableUrlTargetType
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/DiscountShareableUrlTargetType.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Discount​Shareable​Url​Target​Type

enum

The type of page where a shareable discount URL lands.

## Valid values

* COLLECTION

  The URL lands on a collection page.

* HOME

  The URL lands on a home page.

* PRODUCT

  The URL lands on a product page.

***

## Fields

* [Discount​Shareable​Url.targetType](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/DiscountShareableUrl#field-DiscountShareableUrl.fields.targetType)

  OBJECT

  A shareable URL for a discount code.

***

## Map

### Fields with this enum

* [Discount​Shareable​Url.targetType](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/DiscountShareableUrl#field-DiscountShareableUrl.fields.targetType)

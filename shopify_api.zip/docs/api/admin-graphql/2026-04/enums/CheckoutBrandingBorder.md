---
title: CheckoutBrandingBorder - GraphQL Admin
description: Possible values for the border.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutBrandingBorder
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutBrandingBorder.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Checkout​Branding​Border

enum

Possible values for the border.

## Valid values

* BLOCK\_​END

  The Block End border.

* FULL

  The Full border.

* NONE

  The None border.

***

## Fields

* [Checkout​Branding​Select.border](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutBrandingSelect#field-CheckoutBrandingSelect.fields.border)

  OBJECT

  The selects customizations.

* [Checkout​Branding​Select​Input.border](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutBrandingSelectInput#fields-border)

  INPUT OBJECT

  The input fields used to update the selects customizations.

* [Checkout​Branding​Text​Field.border](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutBrandingTextField#field-CheckoutBrandingTextField.fields.border)

  OBJECT

  The text fields customizations.

* [Checkout​Branding​Text​Field​Input.border](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutBrandingTextFieldInput#fields-border)

  INPUT OBJECT

  The input fields used to update the text fields customizations.

***

## Map

### Fields with this enum

* [Checkout​Branding​Select.border](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutBrandingSelect#field-CheckoutBrandingSelect.fields.border)
* [Checkout​Branding​Text​Field.border](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutBrandingTextField#field-CheckoutBrandingTextField.fields.border)

### Inputs with this enum

* [Checkout​Branding​Select​Input.border](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutBrandingSelectInput#fields-border)
* [Checkout​Branding​Text​Field​Input.border](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutBrandingTextFieldInput#fields-border)

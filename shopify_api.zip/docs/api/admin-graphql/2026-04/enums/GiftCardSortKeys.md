---
title: GiftCardSortKeys - GraphQL Admin
description: The set of valid sort keys for the GiftCard query.
api_version: 2026-04
source_url:
  html: 'https://shopify.dev/docs/api/admin-graphql/2026-04/enums/GiftCardSortKeys'
  md: 'https://shopify.dev/docs/api/admin-graphql/2026-04/enums/GiftCardSortKeys.md'
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Gift​Card​Sort​Keys

enum

The set of valid sort keys for the GiftCard query.

## Valid values

* AMOUNT\_​SPENT

  Sort by the `amount_spent` value.

* BALANCE

  Sort by the `balance` value.

* CODE

  Sort by the `code` value.

* CREATED\_​AT

  Sort by the `created_at` value.

* CUSTOMER\_​NAME

  Sort by the `customer_name` value.

* DISABLED\_​AT

  Sort by the `disabled_at` value.

* EXPIRES\_​ON

  Sort by the `expires_on` value.

* ID

  Sort by the `id` value.

* INITIAL\_​VALUE

  Sort by the `initial_value` value.

* UPDATED\_​AT

  Sort by the `updated_at` value.

***

## Fields

* [Customer​Merge​Preview​Default​Fields.giftCards(sortKey)](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CustomerMergePreviewDefaultFields#field-CustomerMergePreviewDefaultFields.fields.giftCards.arguments.sortKey)

  ARGUMENT

  The fields that will be kept as part of a customer merge preview.

* [Query​Root.giftCards(sortKey)](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/QueryRoot#field-QueryRoot.fields.giftCards.arguments.sortKey)

  ARGUMENT

  The schema's entry-point for queries. This acts as the public, top-level API from which all queries must start.

* [gift​Cards.sortKey](https://shopify.dev/docs/api/admin-graphql/2026-04/queries/giftCards#arguments-sortKey)

  ARGUMENT

***

## Map

### Arguments with this enum

* [Customer​Merge​Preview​Default​Fields.giftCards(sortKey)](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CustomerMergePreviewDefaultFields#field-CustomerMergePreviewDefaultFields.fields.giftCards.arguments.sortKey)
* [Query​Root.giftCards(sortKey)](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/QueryRoot#field-QueryRoot.fields.giftCards.arguments.sortKey)
* [gift​Cards.sortKey](https://shopify.dev/docs/api/admin-graphql/2026-04/queries/giftCards#arguments-sortKey)

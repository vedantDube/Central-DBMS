---
title: CarrierServiceSortKeys - GraphQL Admin
description: The set of valid sort keys for the CarrierService query.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CarrierServiceSortKeys
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CarrierServiceSortKeys.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Carrier​Service​Sort​Keys

enum

The set of valid sort keys for the CarrierService query.

## Valid values

* CREATED\_​AT

  Sort by the `created_at` value.

* ID

  Sort by the `id` value.

* UPDATED\_​AT

  Sort by the `updated_at` value.

***

## Fields

* [Query​Root.carrierServices(sortKey)](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/QueryRoot#field-QueryRoot.fields.carrierServices.arguments.sortKey)

  ARGUMENT

  The schema's entry-point for queries. This acts as the public, top-level API from which all queries must start.

* [carrier​Services.sortKey](https://shopify.dev/docs/api/admin-graphql/2026-04/queries/carrierServices#arguments-sortKey)

  ARGUMENT

***

## Map

### Arguments with this enum

* [Query​Root.carrierServices(sortKey)](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/QueryRoot#field-QueryRoot.fields.carrierServices.arguments.sortKey)
* [carrier​Services.sortKey](https://shopify.dev/docs/api/admin-graphql/2026-04/queries/carrierServices#arguments-sortKey)

---
title: FileContentType - GraphQL Admin
description: The possible content types for a file object.
api_version: 2026-04
source_url:
  html: 'https://shopify.dev/docs/api/admin-graphql/2026-04/enums/FileContentType'
  md: 'https://shopify.dev/docs/api/admin-graphql/2026-04/enums/FileContentType.md'
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# File​Content​Type

enum

The possible content types for a file object.

## Valid values

* EXTERNAL\_​VIDEO

  An externally hosted video.

* FILE

  A Shopify-hosted generic file.

* IMAGE

  A Shopify-hosted image.

* MODEL\_​3D

  A Shopify-hosted 3D model.

* VIDEO

  A Shopify-hosted video file. It's recommended to use this type for all video files.

***

## Fields

* [File​Create​Input.contentType](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/FileCreateInput#fields-contentType)

  INPUT OBJECT

  The input fields that are required to create a file object.

* [File​Set​Input.contentType](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/FileSetInput#fields-contentType)

  INPUT OBJECT

  The input fields required to create or update a file object.

***

## Map

### Inputs with this enum

* [File​Create​Input.contentType](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/FileCreateInput#fields-contentType)
* [File​Set​Input.contentType](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/FileSetInput#fields-contentType)

---
title: AppSubscriptionTrialExtendUserErrorCode - GraphQL Admin
description: >-
  Possible error codes that can be returned by
  `AppSubscriptionTrialExtendUserError`.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/AppSubscriptionTrialExtendUserErrorCode
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/AppSubscriptionTrialExtendUserErrorCode.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# App​Subscription​Trial​Extend​User​Error​Code

enum

Possible error codes that can be returned by `AppSubscriptionTrialExtendUserError`.

## Valid values

* SUBSCRIPTION\_​NOT\_​ACTIVE

  The app subscription isn't active.

* SUBSCRIPTION\_​NOT\_​FOUND

  The app subscription wasn't found.

* TRIAL\_​NOT\_​ACTIVE

  The trial isn't active.

***

## Fields

* [App​Subscription​Trial​Extend​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/AppSubscriptionTrialExtendUserError#field-AppSubscriptionTrialExtendUserError.fields.code)

  OBJECT

  An error that occurs during the execution of `AppSubscriptionTrialExtend`.

***

## Map

### Fields with this enum

* [App​Subscription​Trial​Extend​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/AppSubscriptionTrialExtendUserError#field-AppSubscriptionTrialExtendUserError.fields.code)

---
title: CheckoutAndAccountsConfigurationBrandingSpacingKeyword - GraphQL Admin
description: The spacing between UI elements.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutAndAccountsConfigurationBrandingSpacingKeyword
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutAndAccountsConfigurationBrandingSpacingKeyword.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Checkout​And​Accounts​Configuration​Branding​Spacing​Keyword

enum

The spacing between UI elements.

## Valid values

* BASE

  The Base spacing.

* LARGE

  The Large spacing.

* LARGE\_​100

  The Large 100 spacing.

* LARGE\_​200

  The Large 200 spacing.

* LARGE\_​300

  The Large 300 spacing.

* LARGE\_​400

  The Large 400 spacing.

* LARGE\_​500

  The Large 500 spacing.

* NONE

  The None spacing.

* SMALL

  The Small spacing.

* SMALL\_​100

  The Small 100 spacing.

* SMALL\_​200

  The Small 200 spacing.

* SMALL\_​300

  The Small 300 spacing.

* SMALL\_​400

  The Small 400 spacing.

* SMALL\_​500

  The Small 500 spacing.

***

## Fields

* [Checkout​And​Accounts​Configuration​Branding​Checkout​Footer.padding](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingCheckoutFooter#field-CheckoutAndAccountsConfigurationBrandingCheckoutFooter.fields.padding)

  OBJECT

  A container for the checkout footer section customizations.

* [Checkout​And​Accounts​Configuration​Branding​Checkout​Footer​Input.padding](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingCheckoutFooterInput#fields-padding)

  INPUT OBJECT

  The input fields for customizing the checkout footer.

* [Checkout​And​Accounts​Configuration​Branding​Checkout​Header.padding](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingCheckoutHeader#field-CheckoutAndAccountsConfigurationBrandingCheckoutHeader.fields.padding)

  OBJECT

  The checkout header customizations.

* [Checkout​And​Accounts​Configuration​Branding​Checkout​Header​Input.padding](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingCheckoutHeaderInput#fields-padding)

  INPUT OBJECT

  The input fields for customizing the checkout header.

* [Checkout​And​Accounts​Configuration​Branding​Choice​List​Group.spacing](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingChoiceListGroup#field-CheckoutAndAccountsConfigurationBrandingChoiceListGroup.fields.spacing)

  OBJECT

  The customizations that apply to the 'group' variant of ChoiceList.

* [Checkout​And​Accounts​Configuration​Branding​Choice​List​Group​Input.spacing](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingChoiceListGroupInput#fields-spacing)

  INPUT OBJECT

  The input fields for customizing the 'group' variant of ChoiceList.

* [Checkout​And​Accounts​Configuration​Branding​Customer​Accounts​Footer.padding](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingCustomerAccountsFooter#field-CheckoutAndAccountsConfigurationBrandingCustomerAccountsFooter.fields.padding)

  OBJECT

  A container for the customer accounts footer section customizations.

* [Checkout​And​Accounts​Configuration​Branding​Customer​Accounts​Footer​Input.padding](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingCustomerAccountsFooterInput#fields-padding)

  INPUT OBJECT

  The input fields for customizing the customer accounts footer.

* [Checkout​And​Accounts​Configuration​Branding​Customer​Accounts​Header.padding](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingCustomerAccountsHeader#field-CheckoutAndAccountsConfigurationBrandingCustomerAccountsHeader.fields.padding)

  OBJECT

  The checkout header customizations.

* [Checkout​And​Accounts​Configuration​Branding​Customer​Accounts​Header​Input.padding](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingCustomerAccountsHeaderInput#fields-padding)

  INPUT OBJECT

  The input fields for customizing the customer accounts header.

* [Checkout​And​Accounts​Configuration​Branding​Customer​Accounts​Main​Section.padding](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingCustomerAccountsMainSection#field-CheckoutAndAccountsConfigurationBrandingCustomerAccountsMainSection.fields.padding)

  OBJECT

  The customer accounts branding section customizations.

* [Checkout​And​Accounts​Configuration​Branding​Customer​Accounts​Main​Section​Input.padding](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingCustomerAccountsMainSectionInput#fields-padding)

  INPUT OBJECT

  The input fields for customizing the customer accounts branding section.

* [Checkout​And​Accounts​Configuration​Branding​Footer.padding](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingFooter#field-CheckoutAndAccountsConfigurationBrandingFooter.fields.padding)

  OBJECT

  A container for the footer section customizations.

* [Checkout​And​Accounts​Configuration​Branding​Footer​Input.padding](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingFooterInput#fields-padding)

  INPUT OBJECT

  The input fields for customizing the checkout footer.

* [Checkout​And​Accounts​Configuration​Branding​Header.padding](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingHeader#field-CheckoutAndAccountsConfigurationBrandingHeader.fields.padding)

  OBJECT

  The header customizations.

* [Checkout​And​Accounts​Configuration​Branding​Header​Input.padding](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingHeaderInput#fields-padding)

  INPUT OBJECT

  The input fields for customizing the header.

* [Checkout​And​Accounts​Configuration​Branding​Main​Section.padding](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingMainSection#field-CheckoutAndAccountsConfigurationBrandingMainSection.fields.padding)

  OBJECT

  The main sections customizations.

* [Checkout​And​Accounts​Configuration​Branding​Main​Section​Input.padding](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingMainSectionInput#fields-padding)

  INPUT OBJECT

  The input fields for customizing the main sections.

* [Checkout​And​Accounts​Configuration​Branding​Order​Summary​Section.padding](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingOrderSummarySection#field-CheckoutAndAccountsConfigurationBrandingOrderSummarySection.fields.padding)

  OBJECT

  The order summary sections customizations.

* [Checkout​And​Accounts​Configuration​Branding​Order​Summary​Section​Input.padding](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingOrderSummarySectionInput#fields-padding)

  INPUT OBJECT

  The input fields for customizing the order summary sections.

* [Checkout​And​Accounts​Configuration​Branding​Sign​In​Header.padding](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingSignInHeader#field-CheckoutAndAccountsConfigurationBrandingSignInHeader.fields.padding)

  OBJECT

  The sign-in header customizations.

* [Checkout​And​Accounts​Configuration​Branding​Sign​In​Header​Input.padding](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingSignInHeaderInput#fields-padding)

  INPUT OBJECT

  The input fields for customizing the sign-in header.

***

## Map

### Fields with this enum

* [Checkout​And​Accounts​Configuration​Branding​Checkout​Footer.padding](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingCheckoutFooter#field-CheckoutAndAccountsConfigurationBrandingCheckoutFooter.fields.padding)
* [Checkout​And​Accounts​Configuration​Branding​Checkout​Header.padding](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingCheckoutHeader#field-CheckoutAndAccountsConfigurationBrandingCheckoutHeader.fields.padding)
* [Checkout​And​Accounts​Configuration​Branding​Choice​List​Group.spacing](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingChoiceListGroup#field-CheckoutAndAccountsConfigurationBrandingChoiceListGroup.fields.spacing)
* [Checkout​And​Accounts​Configuration​Branding​Customer​Accounts​Footer.padding](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingCustomerAccountsFooter#field-CheckoutAndAccountsConfigurationBrandingCustomerAccountsFooter.fields.padding)
* [Checkout​And​Accounts​Configuration​Branding​Customer​Accounts​Header.padding](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingCustomerAccountsHeader#field-CheckoutAndAccountsConfigurationBrandingCustomerAccountsHeader.fields.padding)
* [Checkout​And​Accounts​Configuration​Branding​Customer​Accounts​Main​Section.padding](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingCustomerAccountsMainSection#field-CheckoutAndAccountsConfigurationBrandingCustomerAccountsMainSection.fields.padding)
* [Checkout​And​Accounts​Configuration​Branding​Footer.padding](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingFooter#field-CheckoutAndAccountsConfigurationBrandingFooter.fields.padding)
* [Checkout​And​Accounts​Configuration​Branding​Header.padding](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingHeader#field-CheckoutAndAccountsConfigurationBrandingHeader.fields.padding)
* [Checkout​And​Accounts​Configuration​Branding​Main​Section.padding](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingMainSection#field-CheckoutAndAccountsConfigurationBrandingMainSection.fields.padding)
* [Checkout​And​Accounts​Configuration​Branding​Order​Summary​Section.padding](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingOrderSummarySection#field-CheckoutAndAccountsConfigurationBrandingOrderSummarySection.fields.padding)
* [Checkout​And​Accounts​Configuration​Branding​Sign​In​Header.padding](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingSignInHeader#field-CheckoutAndAccountsConfigurationBrandingSignInHeader.fields.padding)

### Inputs with this enum

* [Checkout​And​Accounts​Configuration​Branding​Checkout​Footer​Input.padding](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingCheckoutFooterInput#fields-padding)
* [Checkout​And​Accounts​Configuration​Branding​Checkout​Header​Input.padding](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingCheckoutHeaderInput#fields-padding)
* [Checkout​And​Accounts​Configuration​Branding​Choice​List​Group​Input.spacing](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingChoiceListGroupInput#fields-spacing)
* [Checkout​And​Accounts​Configuration​Branding​Customer​Accounts​Footer​Input.padding](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingCustomerAccountsFooterInput#fields-padding)
* [Checkout​And​Accounts​Configuration​Branding​Customer​Accounts​Header​Input.padding](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingCustomerAccountsHeaderInput#fields-padding)
* [Checkout​And​Accounts​Configuration​Branding​Customer​Accounts​Main​Section​Input.padding](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingCustomerAccountsMainSectionInput#fields-padding)
* [Checkout​And​Accounts​Configuration​Branding​Footer​Input.padding](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingFooterInput#fields-padding)
* [Checkout​And​Accounts​Configuration​Branding​Header​Input.padding](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingHeaderInput#fields-padding)
* [Checkout​And​Accounts​Configuration​Branding​Main​Section​Input.padding](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingMainSectionInput#fields-padding)
* [Checkout​And​Accounts​Configuration​Branding​Order​Summary​Section​Input.padding](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingOrderSummarySectionInput#fields-padding)
* [Checkout​And​Accounts​Configuration​Branding​Sign​In​Header​Input.padding](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingSignInHeaderInput#fields-padding)

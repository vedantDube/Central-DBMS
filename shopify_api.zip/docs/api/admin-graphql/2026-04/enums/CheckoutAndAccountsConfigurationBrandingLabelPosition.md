---
title: CheckoutAndAccountsConfigurationBrandingLabelPosition - GraphQL Admin
description: The label position options.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutAndAccountsConfigurationBrandingLabelPosition
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutAndAccountsConfigurationBrandingLabelPosition.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Checkout​And​Accounts​Configuration​Branding​Label​Position

enum

The label position options.

## Valid values

* INSIDE

  The Inside label position.

* OUTSIDE

  The Outside label position.

***

## Fields

* [Checkout​And​Accounts​Configuration​Branding​Control.labelPosition](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingControl#field-CheckoutAndAccountsConfigurationBrandingControl.fields.labelPosition)

  OBJECT

  The form controls customizations.

* [Checkout​And​Accounts​Configuration​Branding​Control​Input.labelPosition](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingControlInput#fields-labelPosition)

  INPUT OBJECT

  The input fields for customizing the form controls.

***

## Map

### Fields with this enum

* [Checkout​And​Accounts​Configuration​Branding​Control.labelPosition](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingControl#field-CheckoutAndAccountsConfigurationBrandingControl.fields.labelPosition)

### Inputs with this enum

* [Checkout​And​Accounts​Configuration​Branding​Control​Input.labelPosition](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingControlInput#fields-labelPosition)

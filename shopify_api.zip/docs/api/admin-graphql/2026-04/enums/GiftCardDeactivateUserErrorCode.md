---
title: GiftCardDeactivateUserErrorCode - GraphQL Admin
description: Possible error codes that can be returned by `GiftCardDeactivateUserError`.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/GiftCardDeactivateUserErrorCode
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/GiftCardDeactivateUserErrorCode.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Gift​Card​Deactivate​User​Error​Code

enum

Possible error codes that can be returned by `GiftCardDeactivateUserError`.

## Valid values

* GIFT\_​CARD\_​NOT\_​FOUND

  The gift card could not be found.

***

## Fields

* [Gift​Card​Deactivate​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/GiftCardDeactivateUserError#field-GiftCardDeactivateUserError.fields.code)

  OBJECT

  An error that occurs during the execution of `GiftCardDeactivate`.

***

## Map

### Fields with this enum

* [Gift​Card​Deactivate​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/GiftCardDeactivateUserError#field-GiftCardDeactivateUserError.fields.code)

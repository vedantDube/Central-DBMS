---
title: BulkOperationsSortKeys - GraphQL Admin
description: The set of valid sort keys for the BulkOperations query.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/BulkOperationsSortKeys
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/BulkOperationsSortKeys.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Bulk​Operations​Sort​Keys

enum

The set of valid sort keys for the BulkOperations query.

## Valid values

* COMPLETED\_​AT

  Sort by the `completed_at` value.

* CREATED\_​AT

  Sort by the `created_at` value.

***

## Fields

* [Query​Root.bulkOperations(sortKey)](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/QueryRoot#field-QueryRoot.fields.bulkOperations.arguments.sortKey)

  ARGUMENT

  The schema's entry-point for queries. This acts as the public, top-level API from which all queries must start.

* [bulk​Operations.sortKey](https://shopify.dev/docs/api/admin-graphql/2026-04/queries/bulkOperations#arguments-sortKey)

  ARGUMENT

***

## Map

### Arguments with this enum

* [Query​Root.bulkOperations(sortKey)](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/QueryRoot#field-QueryRoot.fields.bulkOperations.arguments.sortKey)
* [bulk​Operations.sortKey](https://shopify.dev/docs/api/admin-graphql/2026-04/queries/bulkOperations#arguments-sortKey)

---
title: InventoryShipmentSetTrackingUserErrorCode - GraphQL Admin
description: >-
  Possible error codes that can be returned by
  `InventoryShipmentSetTrackingUserError`.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/InventoryShipmentSetTrackingUserErrorCode
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/InventoryShipmentSetTrackingUserErrorCode.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Inventory​Shipment​Set​Tracking​User​Error​Code

enum

Possible error codes that can be returned by `InventoryShipmentSetTrackingUserError`.

## Valid values

* INVALID\_​URL

  The URL is invalid.

* SHIPMENT\_​NOT\_​FOUND

  The shipment was not found.

***

## Fields

* [Inventory​Shipment​Set​Tracking​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/InventoryShipmentSetTrackingUserError#field-InventoryShipmentSetTrackingUserError.fields.code)

  OBJECT

  An error that occurs during the execution of `InventoryShipmentSetTracking`.

***

## Map

### Fields with this enum

* [Inventory​Shipment​Set​Tracking​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/InventoryShipmentSetTrackingUserError#field-InventoryShipmentSetTrackingUserError.fields.code)

---
title: CommentNotSpamUserErrorCode - GraphQL Admin
description: Possible error codes that can be returned by `CommentNotSpamUserError`.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CommentNotSpamUserErrorCode
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CommentNotSpamUserErrorCode.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Comment​Not​Spam​User​Error​Code

enum

Possible error codes that can be returned by `CommentNotSpamUserError`.

## Valid values

* NOT\_​FOUND

  The record with the ID used as the input value couldn't be found.

***

## Fields

* [Comment​Not​Spam​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CommentNotSpamUserError#field-CommentNotSpamUserError.fields.code)

  OBJECT

  An error that occurs during the execution of `CommentNotSpam`.

***

## Map

### Fields with this enum

* [Comment​Not​Spam​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CommentNotSpamUserError#field-CommentNotSpamUserError.fields.code)

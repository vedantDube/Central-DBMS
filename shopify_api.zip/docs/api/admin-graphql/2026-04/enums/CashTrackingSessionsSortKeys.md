---
title: CashTrackingSessionsSortKeys - GraphQL Admin
description: The set of valid sort keys for the CashTrackingSessions query.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CashTrackingSessionsSortKeys
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CashTrackingSessionsSortKeys.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Cash​Tracking​Sessions​Sort​Keys

enum

The set of valid sort keys for the CashTrackingSessions query.

## Valid values

* CLOSING\_​TIME\_​ASC

  Sort by the `closing_time_asc` value.

* CLOSING\_​TIME\_​DESC

  Sort by the `closing_time_desc` value.

* ID

  Sort by the `id` value.

* OPENING\_​TIME\_​ASC

  Sort by the `opening_time_asc` value.

* OPENING\_​TIME\_​DESC

  Sort by the `opening_time_desc` value.

* TOTAL\_​DISCREPANCY\_​ASC

  Sort by the `total_discrepancy_asc` value.

* TOTAL\_​DISCREPANCY\_​DESC

  Sort by the `total_discrepancy_desc` value.

***

## Fields

* [Query​Root.cashTrackingSessions(sortKey)](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/QueryRoot#field-QueryRoot.fields.cashTrackingSessions.arguments.sortKey)

  ARGUMENT

  The schema's entry-point for queries. This acts as the public, top-level API from which all queries must start.

* [cash​Tracking​Sessions.sortKey](https://shopify.dev/docs/api/admin-graphql/2026-04/queries/cashTrackingSessions#arguments-sortKey)

  ARGUMENT

***

## Map

### Arguments with this enum

* [Query​Root.cashTrackingSessions(sortKey)](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/QueryRoot#field-QueryRoot.fields.cashTrackingSessions.arguments.sortKey)
* [cash​Tracking​Sessions.sortKey](https://shopify.dev/docs/api/admin-graphql/2026-04/queries/cashTrackingSessions#arguments-sortKey)

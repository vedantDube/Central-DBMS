---
title: CustomerConsentCollectedFrom - GraphQL Admin
description: >-
  The source that collected the customer's consent to receive marketing
  materials.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CustomerConsentCollectedFrom
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CustomerConsentCollectedFrom.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Customer​Consent​Collected​From

enum

The source that collected the customer's consent to receive marketing materials.

## Valid values

* OTHER

  The customer consent was collected outside of Shopify.

* SHOPIFY

  The customer consent was collected by Shopify.

***

## Fields

* [Customer​Sms​Marketing​Consent​State.consentCollectedFrom](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CustomerSmsMarketingConsentState#field-CustomerSmsMarketingConsentState.fields.consentCollectedFrom)

  OBJECT

  The record of when a customer consented to receive marketing material by SMS.

  The customer's consent state reflects the record with the most recent date when consent was updated.

* [Customer​Phone​Number.marketingCollectedFrom](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CustomerPhoneNumber#field-CustomerPhoneNumber.fields.marketingCollectedFrom)

  OBJECT

  Deprecated

***

## Map

### Fields with this enum

* [Customer​Sms​Marketing​Consent​State.consentCollectedFrom](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CustomerSmsMarketingConsentState#field-CustomerSmsMarketingConsentState.fields.consentCollectedFrom)

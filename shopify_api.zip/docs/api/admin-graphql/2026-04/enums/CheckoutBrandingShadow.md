---
title: CheckoutBrandingShadow - GraphQL Admin
description: The container shadow.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutBrandingShadow
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutBrandingShadow.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Checkout​Branding​Shadow

enum

The container shadow.

## Valid values

* BASE

  The Base shadow.

* LARGE\_​100

  The Large 100 shadow.

* LARGE\_​200

  The Large 200 shadow.

* SMALL\_​100

  The Small 100 shadow.

* SMALL\_​200

  The Small 200 shadow.

***

## Fields

* [Checkout​Branding​Main​Section.shadow](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutBrandingMainSection#field-CheckoutBrandingMainSection.fields.shadow)

  OBJECT

  The main sections customizations.

* [Checkout​Branding​Main​Section​Input.shadow](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutBrandingMainSectionInput#fields-shadow)

  INPUT OBJECT

  The input fields used to update the main sections customizations.

* [Checkout​Branding​Order​Summary​Section.shadow](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutBrandingOrderSummarySection#field-CheckoutBrandingOrderSummarySection.fields.shadow)

  OBJECT

  The order summary sections customizations.

* [Checkout​Branding​Order​Summary​Section​Input.shadow](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutBrandingOrderSummarySectionInput#fields-shadow)

  INPUT OBJECT

  The input fields used to update the order summary sections customizations.

***

## Map

### Fields with this enum

* [Checkout​Branding​Main​Section.shadow](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutBrandingMainSection#field-CheckoutBrandingMainSection.fields.shadow)
* [Checkout​Branding​Order​Summary​Section.shadow](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutBrandingOrderSummarySection#field-CheckoutBrandingOrderSummarySection.fields.shadow)

### Inputs with this enum

* [Checkout​Branding​Main​Section​Input.shadow](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutBrandingMainSectionInput#fields-shadow)
* [Checkout​Branding​Order​Summary​Section​Input.shadow](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutBrandingOrderSummarySectionInput#fields-shadow)

---
title: ImageContentType - GraphQL Admin
description: List of supported image content types.
api_version: 2026-04
source_url:
  html: 'https://shopify.dev/docs/api/admin-graphql/2026-04/enums/ImageContentType'
  md: 'https://shopify.dev/docs/api/admin-graphql/2026-04/enums/ImageContentType.md'
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Image​Content​Type

enum

List of supported image content types.

## Valid values

* JPG

  A JPG image.

* PNG

  A PNG image.

* WEBP

  A WEBP image.

***

## Fields

* [Image.transformedSrc(preferredContentType)](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/Image#field-Image.fields.transformedSrc.arguments.preferredContentType)

  ARGUMENT

  Represents an image resource.

* [Image​Transform​Input.preferredContentType](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/ImageTransformInput#fields-preferredContentType)

  INPUT OBJECT

  The available options for transforming an image.

  All transformation options are considered best effort. Any transformation that the original image type doesn't support will be ignored.

***

## Map

### Inputs with this enum

* [Image​Transform​Input.preferredContentType](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/ImageTransformInput#fields-preferredContentType)

### Arguments with this enum

* [Image.transformedSrc(preferredContentType)](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/Image#field-Image.fields.transformedSrc.arguments.preferredContentType)

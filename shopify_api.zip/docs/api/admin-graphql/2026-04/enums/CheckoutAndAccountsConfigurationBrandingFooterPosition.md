---
title: CheckoutAndAccountsConfigurationBrandingFooterPosition - GraphQL Admin
description: Possible values for the footer position.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutAndAccountsConfigurationBrandingFooterPosition
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutAndAccountsConfigurationBrandingFooterPosition.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Checkout​And​Accounts​Configuration​Branding​Footer​Position

enum

Possible values for the footer position.

## Valid values

* END

  The End footer position.

* INLINE

  The Inline footer position.

***

## Fields

* [Checkout​And​Accounts​Configuration​Branding​Checkout​Footer.position](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingCheckoutFooter#field-CheckoutAndAccountsConfigurationBrandingCheckoutFooter.fields.position)

  OBJECT

  A container for the checkout footer section customizations.

* [Checkout​And​Accounts​Configuration​Branding​Checkout​Footer​Input.position](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingCheckoutFooterInput#fields-position)

  INPUT OBJECT

  The input fields for customizing the checkout footer.

***

## Map

### Fields with this enum

* [Checkout​And​Accounts​Configuration​Branding​Checkout​Footer.position](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingCheckoutFooter#field-CheckoutAndAccountsConfigurationBrandingCheckoutFooter.fields.position)

### Inputs with this enum

* [Checkout​And​Accounts​Configuration​Branding​Checkout​Footer​Input.position](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingCheckoutFooterInput#fields-position)

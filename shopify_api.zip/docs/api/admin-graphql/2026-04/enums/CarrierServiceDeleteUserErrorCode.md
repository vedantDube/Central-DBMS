---
title: CarrierServiceDeleteUserErrorCode - GraphQL Admin
description: Possible error codes that can be returned by `CarrierServiceDeleteUserError`.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CarrierServiceDeleteUserErrorCode
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CarrierServiceDeleteUserErrorCode.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Carrier​Service​Delete​User​Error​Code

enum

Possible error codes that can be returned by `CarrierServiceDeleteUserError`.

## Valid values

* CARRIER\_​SERVICE\_​DELETE\_​FAILED

  Carrier service deletion failed.

***

## Fields

* [Carrier​Service​Delete​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CarrierServiceDeleteUserError#field-CarrierServiceDeleteUserError.fields.code)

  OBJECT

  An error that occurs during the execution of `CarrierServiceDelete`.

***

## Map

### Fields with this enum

* [Carrier​Service​Delete​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CarrierServiceDeleteUserError#field-CarrierServiceDeleteUserError.fields.code)

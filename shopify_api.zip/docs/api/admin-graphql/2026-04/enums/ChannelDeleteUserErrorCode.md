---
title: ChannelDeleteUserErrorCode - GraphQL Admin
description: Possible error codes that can be returned by `ChannelDeleteUserError`.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/ChannelDeleteUserErrorCode
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/ChannelDeleteUserErrorCode.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Channel​Delete​User​Error​Code

enum

Possible error codes that can be returned by `ChannelDeleteUserError`.

## Valid values

* INVALID

  The input value is invalid.

* NOT\_​FOUND

  The record with the ID used as the input value couldn't be found.

***

## Fields

* [Channel​Delete​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/ChannelDeleteUserError#field-ChannelDeleteUserError.fields.code)

  OBJECT

  An error that occurs during the execution of `ChannelDelete`.

***

## Map

### Fields with this enum

* [Channel​Delete​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/ChannelDeleteUserError#field-ChannelDeleteUserError.fields.code)

---
title: ChannelCreateUserErrorCode - GraphQL Admin
description: Possible error codes that can be returned by `ChannelCreateUserError`.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/ChannelCreateUserErrorCode
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/ChannelCreateUserErrorCode.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Channel​Create​User​Error​Code

enum

Possible error codes that can be returned by `ChannelCreateUserError`.

## Valid values

* INVALID

  The input value is invalid.

* NOT\_​FOUND

  The record with the ID used as the input value couldn't be found.

***

## Fields

* [Channel​Create​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/ChannelCreateUserError#field-ChannelCreateUserError.fields.code)

  OBJECT

  An error that occurs during the execution of `ChannelCreate`.

***

## Map

### Fields with this enum

* [Channel​Create​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/ChannelCreateUserError#field-ChannelCreateUserError.fields.code)

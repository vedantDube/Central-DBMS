---
title: CheckoutAndAccountsConfigurationBrandingBorder - GraphQL Admin
description: Possible values for the border.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutAndAccountsConfigurationBrandingBorder
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutAndAccountsConfigurationBrandingBorder.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Checkout​And​Accounts​Configuration​Branding​Border

enum

Possible values for the border.

## Valid values

* BLOCK\_​END

  The Block End border.

* FULL

  The Full border.

* NONE

  The None border.

***

## Fields

* [Checkout​And​Accounts​Configuration​Branding​Select.border](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingSelect#field-CheckoutAndAccountsConfigurationBrandingSelect.fields.border)

  OBJECT

  The selects customizations.

* [Checkout​And​Accounts​Configuration​Branding​Select​Input.border](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingSelectInput#fields-border)

  INPUT OBJECT

  The input fields for customizing the selects.

* [Checkout​And​Accounts​Configuration​Branding​Text​Field.border](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingTextField#field-CheckoutAndAccountsConfigurationBrandingTextField.fields.border)

  OBJECT

  The text fields customizations.

* [Checkout​And​Accounts​Configuration​Branding​Text​Field​Input.border](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingTextFieldInput#fields-border)

  INPUT OBJECT

  The input fields for customizing the text fields.

***

## Map

### Fields with this enum

* [Checkout​And​Accounts​Configuration​Branding​Select.border](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingSelect#field-CheckoutAndAccountsConfigurationBrandingSelect.fields.border)
* [Checkout​And​Accounts​Configuration​Branding​Text​Field.border](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingTextField#field-CheckoutAndAccountsConfigurationBrandingTextField.fields.border)

### Inputs with this enum

* [Checkout​And​Accounts​Configuration​Branding​Select​Input.border](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingSelectInput#fields-border)
* [Checkout​And​Accounts​Configuration​Branding​Text​Field​Input.border](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingTextFieldInput#fields-border)

---
title: CheckoutAndAccountsConfigurationBrandingShadow - GraphQL Admin
description: The container shadow.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutAndAccountsConfigurationBrandingShadow
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutAndAccountsConfigurationBrandingShadow.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Checkout​And​Accounts​Configuration​Branding​Shadow

enum

The container shadow.

## Valid values

* BASE

  The Base shadow.

* LARGE\_​100

  The Large 100 shadow.

* LARGE\_​200

  The Large 200 shadow.

* SMALL\_​100

  The Small 100 shadow.

* SMALL\_​200

  The Small 200 shadow.

***

## Fields

* [Checkout​And​Accounts​Configuration​Branding​Customer​Accounts​Main​Section.shadow](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingCustomerAccountsMainSection#field-CheckoutAndAccountsConfigurationBrandingCustomerAccountsMainSection.fields.shadow)

  OBJECT

  The customer accounts branding section customizations.

* [Checkout​And​Accounts​Configuration​Branding​Customer​Accounts​Main​Section​Input.shadow](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingCustomerAccountsMainSectionInput#fields-shadow)

  INPUT OBJECT

  The input fields for customizing the customer accounts branding section.

* [Checkout​And​Accounts​Configuration​Branding​Main​Section.shadow](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingMainSection#field-CheckoutAndAccountsConfigurationBrandingMainSection.fields.shadow)

  OBJECT

  The main sections customizations.

* [Checkout​And​Accounts​Configuration​Branding​Main​Section​Input.shadow](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingMainSectionInput#fields-shadow)

  INPUT OBJECT

  The input fields for customizing the main sections.

* [Checkout​And​Accounts​Configuration​Branding​Order​Summary​Section.shadow](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingOrderSummarySection#field-CheckoutAndAccountsConfigurationBrandingOrderSummarySection.fields.shadow)

  OBJECT

  The order summary sections customizations.

* [Checkout​And​Accounts​Configuration​Branding​Order​Summary​Section​Input.shadow](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingOrderSummarySectionInput#fields-shadow)

  INPUT OBJECT

  The input fields for customizing the order summary sections.

***

## Map

### Fields with this enum

* [Checkout​And​Accounts​Configuration​Branding​Customer​Accounts​Main​Section.shadow](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingCustomerAccountsMainSection#field-CheckoutAndAccountsConfigurationBrandingCustomerAccountsMainSection.fields.shadow)
* [Checkout​And​Accounts​Configuration​Branding​Main​Section.shadow](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingMainSection#field-CheckoutAndAccountsConfigurationBrandingMainSection.fields.shadow)
* [Checkout​And​Accounts​Configuration​Branding​Order​Summary​Section.shadow](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingOrderSummarySection#field-CheckoutAndAccountsConfigurationBrandingOrderSummarySection.fields.shadow)

### Inputs with this enum

* [Checkout​And​Accounts​Configuration​Branding​Customer​Accounts​Main​Section​Input.shadow](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingCustomerAccountsMainSectionInput#fields-shadow)
* [Checkout​And​Accounts​Configuration​Branding​Main​Section​Input.shadow](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingMainSectionInput#fields-shadow)
* [Checkout​And​Accounts​Configuration​Branding​Order​Summary​Section​Input.shadow](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingOrderSummarySectionInput#fields-shadow)

---
title: CashManagementSystemReasonCodeEnum - GraphQL Admin
description: System reason codes for cash management.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CashManagementSystemReasonCodeEnum
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CashManagementSystemReasonCodeEnum.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Cash​Management​System​Reason​Code​Enum

enum

System reason codes for cash management.

## Valid values

* AUTO\_​END\_​SESSION\_​LOCATION\_​CHANGE

  Point of sale device payment session was automatically closed because the device switched to a different location.

* AUTO\_​END\_​SESSION\_​LOGOUT

  Point of sale device payment session was automatically closed because a staff member logged out.

* AUTO\_​START\_​SESSION\_​CHECKOUT

  Point of sale device payment session was automatically opened by a cash payment at checkout.

* CASH\_​PAYOUT

  Cash payout.

* FLOAT\_​SETUP

  Float setup.

* OTHER

  Deprecated

***

## Fields

* [Cash​Management​System​Reason​Code.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CashManagementSystemReasonCode#field-CashManagementSystemReasonCode.fields.code)

  OBJECT

  System reason code.

***

## Map

### Fields with this enum

* [Cash​Management​System​Reason​Code.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CashManagementSystemReasonCode#field-CashManagementSystemReasonCode.fields.code)

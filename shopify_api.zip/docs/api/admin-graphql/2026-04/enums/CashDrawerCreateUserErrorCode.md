---
title: CashDrawerCreateUserErrorCode - GraphQL Admin
description: Possible error codes that can be returned by `CashDrawerCreateUserError`.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CashDrawerCreateUserErrorCode
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CashDrawerCreateUserErrorCode.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Cash​Drawer​Create​User​Error​Code

enum

Possible error codes that can be returned by `CashDrawerCreateUserError`.

## Valid values

* CASH\_​DRAWER\_​ALREADY\_​EXISTS

  A cash drawer with this name already exists at the specified location.

* INTERNAL\_​ERROR

  Unexpected internal error happened.

* INVALID\_​NAME

  The name provided is invalid.

* LOCATION\_​NOT\_​FOUND

  The location was not found.

* NOT\_​SAVED

  Failed to create cash drawer.

***

## Fields

* [Cash​Drawer​Create​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CashDrawerCreateUserError#field-CashDrawerCreateUserError.fields.code)

  OBJECT

  An error that occurs during the execution of `CashDrawerCreate`.

***

## Map

### Fields with this enum

* [Cash​Drawer​Create​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CashDrawerCreateUserError#field-CashDrawerCreateUserError.fields.code)

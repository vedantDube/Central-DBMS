---
title: AppUninstallAppUninstallErrorCode - GraphQL Admin
description: Possible error codes that can be returned by `AppUninstallAppUninstallError`.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/AppUninstallAppUninstallErrorCode
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/AppUninstallAppUninstallErrorCode.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# App​Uninstall​App​Uninstall​Error​Code

enum

Possible error codes that can be returned by `AppUninstallAppUninstallError`.

## Valid values

* APP\_​NOT\_​FOUND

  The app cannot be found.

* APP\_​NOT\_​INSTALLED

  The app is not installed.

* APP\_​UNINSTALL\_​ERROR

  An error occurred while uninstalling the app.

* USER\_​PERMISSIONS\_​INSUFFICIENT

  User does not have sufficient permissions to uninstall this app.

***

## Fields

* [App​Uninstall​App​Uninstall​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/AppUninstallAppUninstallError#field-AppUninstallAppUninstallError.fields.code)

  OBJECT

  Represents an error that happens while uninstalling an app.

***

## Map

### Fields with this enum

* [App​Uninstall​App​Uninstall​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/AppUninstallAppUninstallError#field-AppUninstallAppUninstallError.fields.code)

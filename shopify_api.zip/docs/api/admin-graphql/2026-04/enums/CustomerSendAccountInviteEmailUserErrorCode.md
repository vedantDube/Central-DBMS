---
title: CustomerSendAccountInviteEmailUserErrorCode - GraphQL Admin
description: >-
  Possible error codes that can be returned by
  `CustomerSendAccountInviteEmailUserError`.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CustomerSendAccountInviteEmailUserErrorCode
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CustomerSendAccountInviteEmailUserErrorCode.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Customer​Send​Account​Invite​Email​User​Error​Code

enum

Possible error codes that can be returned by `CustomerSendAccountInviteEmailUserError`.

## Valid values

* INVALID

  The input value is invalid.

***

## Fields

* [Customer​Send​Account​Invite​Email​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CustomerSendAccountInviteEmailUserError#field-CustomerSendAccountInviteEmailUserError.fields.code)

  OBJECT

  Defines errors for customerSendAccountInviteEmail mutation.

***

## Map

### Fields with this enum

* [Customer​Send​Account​Invite​Email​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CustomerSendAccountInviteEmailUserError#field-CustomerSendAccountInviteEmailUserError.fields.code)

---
title: CashDrawerUpdateUserErrorCode - GraphQL Admin
description: Possible error codes that can be returned by `CashDrawerUpdateUserError`.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CashDrawerUpdateUserErrorCode
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CashDrawerUpdateUserErrorCode.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Cash​Drawer​Update​User​Error​Code

enum

Possible error codes that can be returned by `CashDrawerUpdateUserError`.

## Valid values

* CASH\_​DRAWER\_​ALREADY\_​EXISTS

  A cash drawer with this name already exists at the specified location.

* CASH\_​DRAWER\_​NOT\_​FOUND

  The cash drawer was not found.

* INTERNAL\_​ERROR

  Unexpected internal error happened.

* INVALID\_​NAME

  The name provided is invalid.

* NOT\_​SAVED

  Failed to update cash drawer.

***

## Fields

* [Cash​Drawer​Update​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CashDrawerUpdateUserError#field-CashDrawerUpdateUserError.fields.code)

  OBJECT

  An error that occurs during the execution of `CashDrawerUpdate`.

***

## Map

### Fields with this enum

* [Cash​Drawer​Update​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CashDrawerUpdateUserError#field-CashDrawerUpdateUserError.fields.code)

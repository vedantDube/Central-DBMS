---
title: CheckoutBrandingTypographyLetterCase - GraphQL Admin
description: Possible values for the typography letter case.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutBrandingTypographyLetterCase
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutBrandingTypographyLetterCase.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Checkout​Branding​Typography​Letter​Case

enum

Possible values for the typography letter case.

## Valid values

* LOWER

  All letters are is lower case.

* NONE

  No letter casing applied.

* TITLE

  Capitalize the first letter of each word.

* UPPER

  All letters are uppercase.

***

## Fields

* [Checkout​Branding​Typography​Style.letterCase](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutBrandingTypographyStyle#field-CheckoutBrandingTypographyStyle.fields.letterCase)

  OBJECT

  The typography customizations.

* [Checkout​Branding​Typography​Style​Global.letterCase](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutBrandingTypographyStyleGlobal#field-CheckoutBrandingTypographyStyleGlobal.fields.letterCase)

  OBJECT

  The global typography customizations.

* [Checkout​Branding​Typography​Style​Global​Input.letterCase](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutBrandingTypographyStyleGlobalInput#fields-letterCase)

  INPUT OBJECT

  The input fields used to update the global typography customizations.

* [Checkout​Branding​Typography​Style​Input.letterCase](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutBrandingTypographyStyleInput#fields-letterCase)

  INPUT OBJECT

  The input fields used to update the typography customizations.

***

## Map

### Fields with this enum

* [Checkout​Branding​Typography​Style.letterCase](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutBrandingTypographyStyle#field-CheckoutBrandingTypographyStyle.fields.letterCase)
* [Checkout​Branding​Typography​Style​Global.letterCase](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutBrandingTypographyStyleGlobal#field-CheckoutBrandingTypographyStyleGlobal.fields.letterCase)

### Inputs with this enum

* [Checkout​Branding​Typography​Style​Global​Input.letterCase](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutBrandingTypographyStyleGlobalInput#fields-letterCase)
* [Checkout​Branding​Typography​Style​Input.letterCase](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutBrandingTypographyStyleInput#fields-letterCase)

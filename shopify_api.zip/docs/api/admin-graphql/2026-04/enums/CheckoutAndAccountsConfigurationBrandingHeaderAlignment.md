---
title: CheckoutAndAccountsConfigurationBrandingHeaderAlignment - GraphQL Admin
description: The possible header alignments.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutAndAccountsConfigurationBrandingHeaderAlignment
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutAndAccountsConfigurationBrandingHeaderAlignment.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Checkout​And​Accounts​Configuration​Branding​Header​Alignment

enum

The possible header alignments.

## Valid values

* CENTER

  Center alignment.

* END

  End alignment.

* START

  Start alignment.

***

## Fields

* [Checkout​And​Accounts​Configuration​Branding​Checkout​Header.alignment](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingCheckoutHeader#field-CheckoutAndAccountsConfigurationBrandingCheckoutHeader.fields.alignment)

  OBJECT

  The checkout header customizations.

* [Checkout​And​Accounts​Configuration​Branding​Checkout​Header​Input.alignment](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingCheckoutHeaderInput#fields-alignment)

  INPUT OBJECT

  The input fields for customizing the checkout header.

* [Checkout​And​Accounts​Configuration​Branding​Customer​Accounts​Header.alignment](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingCustomerAccountsHeader#field-CheckoutAndAccountsConfigurationBrandingCustomerAccountsHeader.fields.alignment)

  OBJECT

  The checkout header customizations.

* [Checkout​And​Accounts​Configuration​Branding​Customer​Accounts​Header​Input.alignment](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingCustomerAccountsHeaderInput#fields-alignment)

  INPUT OBJECT

  The input fields for customizing the customer accounts header.

* [Checkout​And​Accounts​Configuration​Branding​Header.alignment](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingHeader#field-CheckoutAndAccountsConfigurationBrandingHeader.fields.alignment)

  OBJECT

  The header customizations.

* [Checkout​And​Accounts​Configuration​Branding​Header​Input.alignment](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingHeaderInput#fields-alignment)

  INPUT OBJECT

  The input fields for customizing the header.

***

## Map

### Fields with this enum

* [Checkout​And​Accounts​Configuration​Branding​Checkout​Header.alignment](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingCheckoutHeader#field-CheckoutAndAccountsConfigurationBrandingCheckoutHeader.fields.alignment)
* [Checkout​And​Accounts​Configuration​Branding​Customer​Accounts​Header.alignment](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingCustomerAccountsHeader#field-CheckoutAndAccountsConfigurationBrandingCustomerAccountsHeader.fields.alignment)
* [Checkout​And​Accounts​Configuration​Branding​Header.alignment](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingHeader#field-CheckoutAndAccountsConfigurationBrandingHeader.fields.alignment)

### Inputs with this enum

* [Checkout​And​Accounts​Configuration​Branding​Checkout​Header​Input.alignment](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingCheckoutHeaderInput#fields-alignment)
* [Checkout​And​Accounts​Configuration​Branding​Customer​Accounts​Header​Input.alignment](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingCustomerAccountsHeaderInput#fields-alignment)
* [Checkout​And​Accounts​Configuration​Branding​Header​Input.alignment](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingHeaderInput#fields-alignment)

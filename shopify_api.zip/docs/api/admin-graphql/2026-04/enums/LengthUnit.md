---
title: LengthUnit - GraphQL Admin
description: Units of measurement for length.
api_version: 2026-04
source_url:
  html: 'https://shopify.dev/docs/api/admin-graphql/2026-04/enums/LengthUnit'
  md: 'https://shopify.dev/docs/api/admin-graphql/2026-04/enums/LengthUnit.md'
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Length​Unit

enum

Units of measurement for length.

## Valid values

* CENTIMETERS

  100 centimeters equals 1 meter.

* FEET

  Imperial system unit of length.

* INCHES

  12 inches equals 1 foot.

* METERS

  Metric system unit of length.

* MILLIMETERS

  1000 millimeters equals 1 meter.

* YARDS

  1 yard equals 3 feet.

***

## Fields

* [Object​Dimensions​Input.unit](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/ObjectDimensionsInput#fields-unit)

  INPUT OBJECT

  The input fields for dimensions of an object.

***

## Map

### Inputs with this enum

* [Object​Dimensions​Input.unit](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/ObjectDimensionsInput#fields-unit)

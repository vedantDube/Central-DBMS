---
title: CashActivitiesSortKeys - GraphQL Admin
description: The set of valid sort keys for the CashActivities query.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CashActivitiesSortKeys
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CashActivitiesSortKeys.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Cash​Activities​Sort​Keys

enum

The set of valid sort keys for the CashActivities query.

## Valid values

* ID

  Sort by the `id` value.

* TIME

  Sort by the `time` value.

***

## Fields

* [Cash​Drawer.cashActivities(sortKey)](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CashDrawer#field-CashDrawer.fields.cashActivities.arguments.sortKey)

  ARGUMENT

  A cash drawer for cash management.

***

## Map

### Arguments with this enum

* [Cash​Drawer.cashActivities(sortKey)](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CashDrawer#field-CashDrawer.fields.cashActivities.arguments.sortKey)

---
title: CheckoutAndAccountsConfigurationBrandingFontLoadingStrategy - GraphQL Admin
description: |-
  The font loading strategy determines how a font face is displayed after it is
  loaded or failed to load. For more information:
  https://developer.mozilla.org/en-US/docs/Web/CSS/@font-face/font-display.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutAndAccountsConfigurationBrandingFontLoadingStrategy
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutAndAccountsConfigurationBrandingFontLoadingStrategy.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Checkout​And​Accounts​Configuration​Branding​Font​Loading​Strategy

enum

The font loading strategy determines how a font face is displayed after it is loaded or failed to load. For more information: <https://developer.mozilla.org/en-US/docs/Web/CSS/@font-face/font-display>.

## Valid values

* AUTO

  The font display strategy is defined by the browser user agent.

* BLOCK

  Gives the font face a short block period and an infinite swap period.

* FALLBACK

  Gives the font face an extremely small block period and a short swap period.

* OPTIONAL

  Gives the font face an extremely small block period and no swap period.

* SWAP

  Gives the font face an extremely small block period and an infinite swap period.

***

## Fields

* [Checkout​And​Accounts​Configuration​Branding​Custom​Font​Group.loadingStrategy](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingCustomFontGroup#field-CheckoutAndAccountsConfigurationBrandingCustomFontGroup.fields.loadingStrategy)

  OBJECT

  The custom font group customizations.

* [Checkout​And​Accounts​Configuration​Branding​Custom​Font​Group​Input.loadingStrategy](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingCustomFontGroupInput#fields-loadingStrategy)

  INPUT OBJECT

  The input fields for customizing a custom font group.

* [Checkout​And​Accounts​Configuration​Branding​Shopify​Font​Group.loadingStrategy](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingShopifyFontGroup#field-CheckoutAndAccountsConfigurationBrandingShopifyFontGroup.fields.loadingStrategy)

  OBJECT

  The Shopify font group customizations.

* [Checkout​And​Accounts​Configuration​Branding​Shopify​Font​Group​Input.loadingStrategy](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingShopifyFontGroupInput#fields-loadingStrategy)

  INPUT OBJECT

  The input fields for customizing a Shopify font group.

***

## Map

### Fields with this enum

* [Checkout​And​Accounts​Configuration​Branding​Custom​Font​Group.loadingStrategy](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingCustomFontGroup#field-CheckoutAndAccountsConfigurationBrandingCustomFontGroup.fields.loadingStrategy)
* [Checkout​And​Accounts​Configuration​Branding​Shopify​Font​Group.loadingStrategy](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingShopifyFontGroup#field-CheckoutAndAccountsConfigurationBrandingShopifyFontGroup.fields.loadingStrategy)

### Inputs with this enum

* [Checkout​And​Accounts​Configuration​Branding​Custom​Font​Group​Input.loadingStrategy](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingCustomFontGroupInput#fields-loadingStrategy)
* [Checkout​And​Accounts​Configuration​Branding​Shopify​Font​Group​Input.loadingStrategy](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingShopifyFontGroupInput#fields-loadingStrategy)

---
title: CheckoutAndAccountsConfigurationBrandingSpacing - GraphQL Admin
description: Possible values for the spacing.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutAndAccountsConfigurationBrandingSpacing
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutAndAccountsConfigurationBrandingSpacing.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Checkout​And​Accounts​Configuration​Branding​Spacing

enum

Possible values for the spacing.

## Valid values

* BASE

  The Base spacing.

* EXTRA\_​LOOSE

  The Extra Loose spacing.

* EXTRA\_​TIGHT

  The Extra Tight spacing.

* LOOSE

  The Loose spacing.

* NONE

  The None spacing.

* TIGHT

  The Tight spacing.

***

## Fields

* [Checkout​And​Accounts​Configuration​Branding​Button.blockPadding](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingButton#field-CheckoutAndAccountsConfigurationBrandingButton.fields.blockPadding)

  OBJECT

  The buttons customizations.

* [Checkout​And​Accounts​Configuration​Branding​Button.inlinePadding](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingButton#field-CheckoutAndAccountsConfigurationBrandingButton.fields.inlinePadding)

  OBJECT

  The buttons customizations.

* [Checkout​And​Accounts​Configuration​Branding​Button​Input.blockPadding](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingButtonInput#fields-blockPadding)

  INPUT OBJECT

  The input fields for customizing the buttons.

* [Checkout​And​Accounts​Configuration​Branding​Button​Input.inlinePadding](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingButtonInput#fields-inlinePadding)

  INPUT OBJECT

  The input fields for customizing the buttons.

***

## Map

### Fields with this enum

* [Checkout​And​Accounts​Configuration​Branding​Button.blockPadding](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingButton#field-CheckoutAndAccountsConfigurationBrandingButton.fields.blockPadding)
* [Checkout​And​Accounts​Configuration​Branding​Button.inlinePadding](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingButton#field-CheckoutAndAccountsConfigurationBrandingButton.fields.inlinePadding)

### Inputs with this enum

* [Checkout​And​Accounts​Configuration​Branding​Button​Input.blockPadding](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingButtonInput#fields-blockPadding)
* [Checkout​And​Accounts​Configuration​Branding​Button​Input.inlinePadding](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingButtonInput#fields-inlinePadding)

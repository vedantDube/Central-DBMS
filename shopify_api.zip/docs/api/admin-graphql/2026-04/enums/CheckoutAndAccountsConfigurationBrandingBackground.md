---
title: CheckoutAndAccountsConfigurationBrandingBackground - GraphQL Admin
description: The container background style.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutAndAccountsConfigurationBrandingBackground
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutAndAccountsConfigurationBrandingBackground.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Checkout​And​Accounts​Configuration​Branding​Background

enum

The container background style.

## Valid values

* BASE

  The Base background style.

* SUBDUED

  The Subdued background style.

***

## Fields

* [Checkout​And​Accounts​Configuration​Branding​Checkout​Footer.background](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingCheckoutFooter#field-CheckoutAndAccountsConfigurationBrandingCheckoutFooter.fields.background)

  OBJECT

  A container for the checkout footer section customizations.

* [Checkout​And​Accounts​Configuration​Branding​Checkout​Footer​Input.background](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingCheckoutFooterInput#fields-background)

  INPUT OBJECT

  The input fields for customizing the checkout footer.

* [Checkout​And​Accounts​Configuration​Branding​Checkout​Header.background](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingCheckoutHeader#field-CheckoutAndAccountsConfigurationBrandingCheckoutHeader.fields.background)

  OBJECT

  The checkout header customizations.

* [Checkout​And​Accounts​Configuration​Branding​Checkout​Header​Input.background](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingCheckoutHeaderInput#fields-background)

  INPUT OBJECT

  The input fields for customizing the checkout header.

* [Checkout​And​Accounts​Configuration​Branding​Customer​Accounts​Main​Section.background](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingCustomerAccountsMainSection#field-CheckoutAndAccountsConfigurationBrandingCustomerAccountsMainSection.fields.background)

  OBJECT

  The customer accounts branding section customizations.

* [Checkout​And​Accounts​Configuration​Branding​Customer​Accounts​Main​Section​Input.background](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingCustomerAccountsMainSectionInput#fields-background)

  INPUT OBJECT

  The input fields for customizing the customer accounts branding section.

* [Checkout​And​Accounts​Configuration​Branding​Footer.background](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingFooter#field-CheckoutAndAccountsConfigurationBrandingFooter.fields.background)

  OBJECT

  A container for the footer section customizations.

* [Checkout​And​Accounts​Configuration​Branding​Footer​Input.background](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingFooterInput#fields-background)

  INPUT OBJECT

  The input fields for customizing the checkout footer.

* [Checkout​And​Accounts​Configuration​Branding​Header.background](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingHeader#field-CheckoutAndAccountsConfigurationBrandingHeader.fields.background)

  OBJECT

  The header customizations.

* [Checkout​And​Accounts​Configuration​Branding​Header​Input.background](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingHeaderInput#fields-background)

  INPUT OBJECT

  The input fields for customizing the header.

* [Checkout​And​Accounts​Configuration​Branding​Main​Section.background](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingMainSection#field-CheckoutAndAccountsConfigurationBrandingMainSection.fields.background)

  OBJECT

  The main sections customizations.

* [Checkout​And​Accounts​Configuration​Branding​Main​Section​Input.background](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingMainSectionInput#fields-background)

  INPUT OBJECT

  The input fields for customizing the main sections.

* [Checkout​And​Accounts​Configuration​Branding​Order​Summary​Section.background](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingOrderSummarySection#field-CheckoutAndAccountsConfigurationBrandingOrderSummarySection.fields.background)

  OBJECT

  The order summary sections customizations.

* [Checkout​And​Accounts​Configuration​Branding​Order​Summary​Section​Input.background](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingOrderSummarySectionInput#fields-background)

  INPUT OBJECT

  The input fields for customizing the order summary sections.

***

## Map

### Fields with this enum

* [Checkout​And​Accounts​Configuration​Branding​Checkout​Footer.background](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingCheckoutFooter#field-CheckoutAndAccountsConfigurationBrandingCheckoutFooter.fields.background)
* [Checkout​And​Accounts​Configuration​Branding​Checkout​Header.background](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingCheckoutHeader#field-CheckoutAndAccountsConfigurationBrandingCheckoutHeader.fields.background)
* [Checkout​And​Accounts​Configuration​Branding​Customer​Accounts​Main​Section.background](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingCustomerAccountsMainSection#field-CheckoutAndAccountsConfigurationBrandingCustomerAccountsMainSection.fields.background)
* [Checkout​And​Accounts​Configuration​Branding​Footer.background](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingFooter#field-CheckoutAndAccountsConfigurationBrandingFooter.fields.background)
* [Checkout​And​Accounts​Configuration​Branding​Header.background](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingHeader#field-CheckoutAndAccountsConfigurationBrandingHeader.fields.background)
* [Checkout​And​Accounts​Configuration​Branding​Main​Section.background](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingMainSection#field-CheckoutAndAccountsConfigurationBrandingMainSection.fields.background)
* [Checkout​And​Accounts​Configuration​Branding​Order​Summary​Section.background](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingOrderSummarySection#field-CheckoutAndAccountsConfigurationBrandingOrderSummarySection.fields.background)

### Inputs with this enum

* [Checkout​And​Accounts​Configuration​Branding​Checkout​Footer​Input.background](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingCheckoutFooterInput#fields-background)
* [Checkout​And​Accounts​Configuration​Branding​Checkout​Header​Input.background](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingCheckoutHeaderInput#fields-background)
* [Checkout​And​Accounts​Configuration​Branding​Customer​Accounts​Main​Section​Input.background](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingCustomerAccountsMainSectionInput#fields-background)
* [Checkout​And​Accounts​Configuration​Branding​Footer​Input.background](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingFooterInput#fields-background)
* [Checkout​And​Accounts​Configuration​Branding​Header​Input.background](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingHeaderInput#fields-background)
* [Checkout​And​Accounts​Configuration​Branding​Main​Section​Input.background](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingMainSectionInput#fields-background)
* [Checkout​And​Accounts​Configuration​Branding​Order​Summary​Section​Input.background](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingOrderSummarySectionInput#fields-background)

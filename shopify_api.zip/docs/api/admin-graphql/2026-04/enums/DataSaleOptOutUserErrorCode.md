---
title: DataSaleOptOutUserErrorCode - GraphQL Admin
description: Possible error codes that can be returned by `DataSaleOptOutUserError`.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/DataSaleOptOutUserErrorCode
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/DataSaleOptOutUserErrorCode.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Data​Sale​Opt​Out​User​Error​Code

enum

Possible error codes that can be returned by `DataSaleOptOutUserError`.

## Valid values

* FAILED

  Data sale opt out failed.

***

## Fields

* [Data​Sale​Opt​Out​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/DataSaleOptOutUserError#field-DataSaleOptOutUserError.fields.code)

  OBJECT

  An error that occurs during the execution of `DataSaleOptOut`.

***

## Map

### Fields with this enum

* [Data​Sale​Opt​Out​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/DataSaleOptOutUserError#field-DataSaleOptOutUserError.fields.code)

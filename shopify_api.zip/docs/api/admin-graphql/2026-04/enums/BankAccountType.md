---
title: BankAccountType - GraphQL Admin
description: The type of bank account.
api_version: 2026-04
source_url:
  html: 'https://shopify.dev/docs/api/admin-graphql/2026-04/enums/BankAccountType'
  md: 'https://shopify.dev/docs/api/admin-graphql/2026-04/enums/BankAccountType.md'
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Bank​Account​Type

enum

The type of bank account.

## Valid values

* CHECKING

  A checking account.

* SAVINGS

  A savings account.

***

## Fields

* [Bank​Account.accountType](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/BankAccount#field-BankAccount.fields.accountType)

  OBJECT

  Represents a bank account payment instrument.

***

## Map

### Fields with this enum

* [Bank​Account.accountType](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/BankAccount#field-BankAccount.fields.accountType)

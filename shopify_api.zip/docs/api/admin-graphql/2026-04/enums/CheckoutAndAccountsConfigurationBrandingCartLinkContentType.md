---
title: CheckoutAndAccountsConfigurationBrandingCartLinkContentType - GraphQL Admin
description: Possible values for the cart link content type for the header.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutAndAccountsConfigurationBrandingCartLinkContentType
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutAndAccountsConfigurationBrandingCartLinkContentType.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Checkout​And​Accounts​Configuration​Branding​Cart​Link​Content​Type

enum

Possible values for the cart link content type for the header.

## Valid values

* ICON

  The checkout header content type icon value.

* IMAGE

  The checkout header content type image value.

* TEXT

  The checkout header content type text value.

***

## Fields

* [Checkout​And​Accounts​Configuration​Branding​Header​Cart​Link.contentType](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingHeaderCartLink#field-CheckoutAndAccountsConfigurationBrandingHeaderCartLink.fields.contentType)

  OBJECT

  The header cart link customizations.

* [Checkout​And​Accounts​Configuration​Branding​Header​Cart​Link​Input.contentType](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingHeaderCartLinkInput#fields-contentType)

  INPUT OBJECT

  The input fields for customizing the cart link for 1-page checkout. This field allows to customize the cart icon that renders by default on 1-page checkout.

***

## Map

### Fields with this enum

* [Checkout​And​Accounts​Configuration​Branding​Header​Cart​Link.contentType](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingHeaderCartLink#field-CheckoutAndAccountsConfigurationBrandingHeaderCartLink.fields.contentType)

### Inputs with this enum

* [Checkout​And​Accounts​Configuration​Branding​Header​Cart​Link​Input.contentType](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingHeaderCartLinkInput#fields-contentType)

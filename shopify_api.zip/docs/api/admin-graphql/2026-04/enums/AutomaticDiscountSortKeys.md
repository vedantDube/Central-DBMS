---
title: AutomaticDiscountSortKeys - GraphQL Admin
description: The set of valid sort keys for the AutomaticDiscount query.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/AutomaticDiscountSortKeys
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/AutomaticDiscountSortKeys.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Automatic​Discount​Sort​Keys

enum

The set of valid sort keys for the AutomaticDiscount query.

## Valid values

* CREATED\_​AT

  Sort by the `created_at` value.

* ID

  Sort by the `id` value.

***

## Fields

* [Query​Root.automaticDiscountNodes(sortKey)](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/QueryRoot#field-QueryRoot.fields.automaticDiscountNodes.arguments.sortKey)

  ARGUMENT

  The schema's entry-point for queries. This acts as the public, top-level API from which all queries must start.

* [Query​Root.automaticDiscounts(sortKey)](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/QueryRoot#field-QueryRoot.fields.automaticDiscounts.arguments.sortKey)

  ARGUMENT

  The schema's entry-point for queries. This acts as the public, top-level API from which all queries must start.

* [automatic​Discount​Nodes.sortKey](https://shopify.dev/docs/api/admin-graphql/2026-04/queries/automaticDiscountNodes#arguments-sortKey)

  ARGUMENT

* [automatic​Discounts.sortKey](https://shopify.dev/docs/api/admin-graphql/2026-04/queries/automaticDiscounts#arguments-sortKey)

  ARGUMENT

***

## Map

### Arguments with this enum

* [Query​Root.automaticDiscountNodes(sortKey)](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/QueryRoot#field-QueryRoot.fields.automaticDiscountNodes.arguments.sortKey)
* [Query​Root.automaticDiscounts(sortKey)](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/QueryRoot#field-QueryRoot.fields.automaticDiscounts.arguments.sortKey)
* [automatic​Discount​Nodes.sortKey](https://shopify.dev/docs/api/admin-graphql/2026-04/queries/automaticDiscountNodes#arguments-sortKey)
* [automatic​Discounts.sortKey](https://shopify.dev/docs/api/admin-graphql/2026-04/queries/automaticDiscounts#arguments-sortKey)

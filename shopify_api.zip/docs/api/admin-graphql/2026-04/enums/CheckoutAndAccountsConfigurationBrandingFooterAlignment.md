---
title: CheckoutAndAccountsConfigurationBrandingFooterAlignment - GraphQL Admin
description: Possible values for the footer alignment.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutAndAccountsConfigurationBrandingFooterAlignment
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutAndAccountsConfigurationBrandingFooterAlignment.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Checkout​And​Accounts​Configuration​Branding​Footer​Alignment

enum

Possible values for the footer alignment.

## Valid values

* CENTER

  The checkout footer alignment Center value.

* END

  The checkout footer alignment End value.

* START

  The checkout footer alignment Start value.

***

## Fields

* [Checkout​And​Accounts​Configuration​Branding​Checkout​Footer.alignment](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingCheckoutFooter#field-CheckoutAndAccountsConfigurationBrandingCheckoutFooter.fields.alignment)

  OBJECT

  A container for the checkout footer section customizations.

* [Checkout​And​Accounts​Configuration​Branding​Checkout​Footer​Input.alignment](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingCheckoutFooterInput#fields-alignment)

  INPUT OBJECT

  The input fields for customizing the checkout footer.

* [Checkout​And​Accounts​Configuration​Branding​Customer​Accounts​Footer.alignment](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingCustomerAccountsFooter#field-CheckoutAndAccountsConfigurationBrandingCustomerAccountsFooter.fields.alignment)

  OBJECT

  A container for the customer accounts footer section customizations.

* [Checkout​And​Accounts​Configuration​Branding​Customer​Accounts​Footer​Input.alignment](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingCustomerAccountsFooterInput#fields-alignment)

  INPUT OBJECT

  The input fields for customizing the customer accounts footer.

* [Checkout​And​Accounts​Configuration​Branding​Footer.alignment](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingFooter#field-CheckoutAndAccountsConfigurationBrandingFooter.fields.alignment)

  OBJECT

  A container for the footer section customizations.

* [Checkout​And​Accounts​Configuration​Branding​Footer​Input.alignment](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingFooterInput#fields-alignment)

  INPUT OBJECT

  The input fields for customizing the checkout footer.

***

## Map

### Fields with this enum

* [Checkout​And​Accounts​Configuration​Branding​Checkout​Footer.alignment](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingCheckoutFooter#field-CheckoutAndAccountsConfigurationBrandingCheckoutFooter.fields.alignment)
* [Checkout​And​Accounts​Configuration​Branding​Customer​Accounts​Footer.alignment](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingCustomerAccountsFooter#field-CheckoutAndAccountsConfigurationBrandingCustomerAccountsFooter.fields.alignment)
* [Checkout​And​Accounts​Configuration​Branding​Footer.alignment](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingFooter#field-CheckoutAndAccountsConfigurationBrandingFooter.fields.alignment)

### Inputs with this enum

* [Checkout​And​Accounts​Configuration​Branding​Checkout​Footer​Input.alignment](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingCheckoutFooterInput#fields-alignment)
* [Checkout​And​Accounts​Configuration​Branding​Customer​Accounts​Footer​Input.alignment](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingCustomerAccountsFooterInput#fields-alignment)
* [Checkout​And​Accounts​Configuration​Branding​Footer​Input.alignment](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingFooterInput#fields-alignment)

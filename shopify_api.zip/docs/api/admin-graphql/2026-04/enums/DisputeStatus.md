---
title: DisputeStatus - GraphQL Admin
description: The possible statuses of a dispute.
api_version: 2026-04
source_url:
  html: 'https://shopify.dev/docs/api/admin-graphql/2026-04/enums/DisputeStatus'
  md: 'https://shopify.dev/docs/api/admin-graphql/2026-04/enums/DisputeStatus.md'
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Dispute​Status

enum

The possible statuses of a dispute.

## Valid values

* ACCEPTED

* LOST

* NEEDS\_​RESPONSE

* PREVENTED

  A dispute that was prevented from becoming a formal chargeback.

* UNDER\_​REVIEW

* WON

* CHARGE\_​REFUNDED

  Deprecated

***

## Fields

* [Order​Dispute​Summary.status](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/OrderDisputeSummary#field-OrderDisputeSummary.fields.status)

  OBJECT

  A summary of the important details for a dispute on an order.

* [Shopify​Payments​Dispute.status](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/ShopifyPaymentsDispute#field-ShopifyPaymentsDispute.fields.status)

  OBJECT

  A dispute occurs when a buyer questions the legitimacy of a charge with their financial institution.

***

## Map

### Fields with this enum

* [Order​Dispute​Summary.status](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/OrderDisputeSummary#field-OrderDisputeSummary.fields.status)
* [Shopify​Payments​Dispute.status](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/ShopifyPaymentsDispute#field-ShopifyPaymentsDispute.fields.status)

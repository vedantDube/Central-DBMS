---
title: CheckoutBrandingFooterPosition - GraphQL Admin
description: Possible values for the footer position.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutBrandingFooterPosition
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutBrandingFooterPosition.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Checkout​Branding​Footer​Position

enum

Possible values for the footer position.

## Valid values

* END

  The End footer position.

* INLINE

  The Inline footer position.

***

## Fields

* [Checkout​Branding​Footer.position](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutBrandingFooter#field-CheckoutBrandingFooter.fields.position)

  OBJECT

  A container for the footer section customizations.

* [Checkout​Branding​Footer​Input.position](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutBrandingFooterInput#fields-position)

  INPUT OBJECT

  The input fields when mutating the checkout footer settings.

***

## Map

### Fields with this enum

* [Checkout​Branding​Footer.position](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutBrandingFooter#field-CheckoutBrandingFooter.fields.position)

### Inputs with this enum

* [Checkout​Branding​Footer​Input.position](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutBrandingFooterInput#fields-position)

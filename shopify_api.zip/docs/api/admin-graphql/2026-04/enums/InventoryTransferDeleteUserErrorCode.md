---
title: InventoryTransferDeleteUserErrorCode - GraphQL Admin
description: >-
  Possible error codes that can be returned by
  `InventoryTransferDeleteUserError`.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/InventoryTransferDeleteUserErrorCode
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/InventoryTransferDeleteUserErrorCode.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Inventory​Transfer​Delete​User​Error​Code

enum

Possible error codes that can be returned by `InventoryTransferDeleteUserError`.

## Valid values

* INVALID\_​TRANSFER\_​STATUS

  Current transfer status does not support this operation.

* TRANSFER\_​NOT\_​FOUND

  The transfer was not found.

***

## Fields

* [Inventory​Transfer​Delete​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/InventoryTransferDeleteUserError#field-InventoryTransferDeleteUserError.fields.code)

  OBJECT

  An error that occurs during the execution of `InventoryTransferDelete`.

***

## Map

### Fields with this enum

* [Inventory​Transfer​Delete​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/InventoryTransferDeleteUserError#field-InventoryTransferDeleteUserError.fields.code)

---
title: CheckoutBrandingTypographyWeight - GraphQL Admin
description: Possible values for the font weight.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutBrandingTypographyWeight
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutBrandingTypographyWeight.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Checkout​Branding​Typography​Weight

enum

Possible values for the font weight.

## Valid values

* BASE

  The base weight.

* BOLD

  The bold weight.

***

## Fields

* [Checkout​Branding​Typography​Style.weight](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutBrandingTypographyStyle#field-CheckoutBrandingTypographyStyle.fields.weight)

  OBJECT

  The typography customizations.

* [Checkout​Branding​Typography​Style​Input.weight](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutBrandingTypographyStyleInput#fields-weight)

  INPUT OBJECT

  The input fields used to update the typography customizations.

***

## Map

### Fields with this enum

* [Checkout​Branding​Typography​Style.weight](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutBrandingTypographyStyle#field-CheckoutBrandingTypographyStyle.fields.weight)

### Inputs with this enum

* [Checkout​Branding​Typography​Style​Input.weight](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutBrandingTypographyStyleInput#fields-weight)

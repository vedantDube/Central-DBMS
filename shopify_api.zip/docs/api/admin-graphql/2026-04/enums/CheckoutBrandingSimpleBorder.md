---
title: CheckoutBrandingSimpleBorder - GraphQL Admin
description: Possible values for the simple border.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutBrandingSimpleBorder
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutBrandingSimpleBorder.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Checkout​Branding​Simple​Border

enum

Possible values for the simple border.

## Valid values

* FULL

  The Full simple border.

* NONE

  The None simple border.

***

## Fields

* [Checkout​Branding​Button.border](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutBrandingButton#field-CheckoutBrandingButton.fields.border)

  OBJECT

  The buttons customizations.

* [Checkout​Branding​Button​Input.border](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutBrandingButtonInput#fields-border)

  INPUT OBJECT

  The input fields used to update the buttons customizations.

* [Checkout​Branding​Control.border](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutBrandingControl#field-CheckoutBrandingControl.fields.border)

  OBJECT

  The form controls customizations.

* [Checkout​Branding​Control​Input.border](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutBrandingControlInput#fields-border)

  INPUT OBJECT

  The input fields used to update the form controls customizations.

* [Checkout​Branding​Main​Section.border](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutBrandingMainSection#field-CheckoutBrandingMainSection.fields.border)

  OBJECT

  The main sections customizations.

* [Checkout​Branding​Main​Section​Input.border](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutBrandingMainSectionInput#fields-border)

  INPUT OBJECT

  The input fields used to update the main sections customizations.

* [Checkout​Branding​Merchandise​Thumbnail.border](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutBrandingMerchandiseThumbnail#field-CheckoutBrandingMerchandiseThumbnail.fields.border)

  OBJECT

  The merchandise thumbnails customizations.

* [Checkout​Branding​Merchandise​Thumbnail​Input.border](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutBrandingMerchandiseThumbnailInput#fields-border)

  INPUT OBJECT

  The input fields used to update the merchandise thumbnails customizations.

* [Checkout​Branding​Order​Summary​Section.border](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutBrandingOrderSummarySection#field-CheckoutBrandingOrderSummarySection.fields.border)

  OBJECT

  The order summary sections customizations.

* [Checkout​Branding​Order​Summary​Section​Input.border](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutBrandingOrderSummarySectionInput#fields-border)

  INPUT OBJECT

  The input fields used to update the order summary sections customizations.

***

## Map

### Fields with this enum

* [Checkout​Branding​Button.border](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutBrandingButton#field-CheckoutBrandingButton.fields.border)
* [Checkout​Branding​Control.border](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutBrandingControl#field-CheckoutBrandingControl.fields.border)
* [Checkout​Branding​Main​Section.border](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutBrandingMainSection#field-CheckoutBrandingMainSection.fields.border)
* [Checkout​Branding​Merchandise​Thumbnail.border](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutBrandingMerchandiseThumbnail#field-CheckoutBrandingMerchandiseThumbnail.fields.border)
* [Checkout​Branding​Order​Summary​Section.border](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutBrandingOrderSummarySection#field-CheckoutBrandingOrderSummarySection.fields.border)

### Inputs with this enum

* [Checkout​Branding​Button​Input.border](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutBrandingButtonInput#fields-border)
* [Checkout​Branding​Control​Input.border](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutBrandingControlInput#fields-border)
* [Checkout​Branding​Main​Section​Input.border](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutBrandingMainSectionInput#fields-border)
* [Checkout​Branding​Merchandise​Thumbnail​Input.border](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutBrandingMerchandiseThumbnailInput#fields-border)
* [Checkout​Branding​Order​Summary​Section​Input.border](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutBrandingOrderSummarySectionInput#fields-border)

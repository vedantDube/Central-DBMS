---
title: CustomerState - GraphQL Admin
description: The valid values for the state of a customer's account with a shop.
api_version: 2026-04
source_url:
  html: 'https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CustomerState'
  md: 'https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CustomerState.md'
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Customer​State

enum

The valid values for the state of a customer's account with a shop.

## Valid values

* DECLINED

  The customer declined the email invite to create an account.

* DISABLED

  The customer doesn't have an active account. Customer accounts can be disabled from the Shopify admin at any time.

* ENABLED

  The customer has created an account.

* INVITED

  The customer has received an email invite to create an account.

***

## Fields

* [Customer.state](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/Customer#field-Customer.fields.state)

  OBJECT

  Information about a customer of the shop, such as the customer's contact details, purchase history, and marketing preferences.

  Tracks the customer's total spending through the [`amountSpent`](https://shopify.dev/docs/api/admin-graphql/latest/objects/Customer#field-amountSpent) field and provides access to associated data such as payment methods and subscription contracts.

  ***

  **Caution:** Only use this data if it\&#39;s required for your app\&#39;s functionality. Shopify will restrict \<a href="https://shopify.dev/api/usage/access-scopes">access to scopes\</a> for apps that don\&#39;t have a legitimate use for the associated data.

  ***

***

## Map

### Fields with this enum

* [Customer.state](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/Customer#field-Customer.fields.state)

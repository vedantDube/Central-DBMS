---
title: AppInstallationPrivacy - GraphQL Admin
description: The levels of privacy of an app installation.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/AppInstallationPrivacy
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/AppInstallationPrivacy.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# App​Installation​Privacy

enum

The levels of privacy of an app installation.

## Valid values

* PRIVATE
* PUBLIC

***

## Fields

* [Query​Root.appInstallations(privacy)](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/QueryRoot#field-QueryRoot.fields.appInstallations.arguments.privacy)

  ARGUMENT

  The schema's entry-point for queries. This acts as the public, top-level API from which all queries must start.

* [app​Installations.privacy](https://shopify.dev/docs/api/admin-graphql/2026-04/queries/appInstallations#arguments-privacy)

  ARGUMENT

***

## Map

### Arguments with this enum

* [Query​Root.appInstallations(privacy)](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/QueryRoot#field-QueryRoot.fields.appInstallations.arguments.privacy)
* [app​Installations.privacy](https://shopify.dev/docs/api/admin-graphql/2026-04/queries/appInstallations#arguments-privacy)

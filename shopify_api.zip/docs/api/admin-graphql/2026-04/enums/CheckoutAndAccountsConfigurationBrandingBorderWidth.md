---
title: CheckoutAndAccountsConfigurationBrandingBorderWidth - GraphQL Admin
description: The container border width.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutAndAccountsConfigurationBrandingBorderWidth
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutAndAccountsConfigurationBrandingBorderWidth.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Checkout​And​Accounts​Configuration​Branding​Border​Width

enum

The container border width.

## Valid values

* BASE

  The Base border width.

* LARGE

  The Large border width.

* LARGE\_​100

  The Large 100 border width.

* LARGE\_​200

  The Large 200 border width.

***

## Fields

* [Checkout​And​Accounts​Configuration​Branding​Container​Divider.borderWidth](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingContainerDivider#field-CheckoutAndAccountsConfigurationBrandingContainerDivider.fields.borderWidth)

  OBJECT

  The container's divider customizations.

* [Checkout​And​Accounts​Configuration​Branding​Container​Divider​Input.borderWidth](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingContainerDividerInput#fields-borderWidth)

  INPUT OBJECT

  The input fields for customizing a container's divider.

* [Checkout​And​Accounts​Configuration​Branding​Customer​Accounts​Main​Section.borderWidth](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingCustomerAccountsMainSection#field-CheckoutAndAccountsConfigurationBrandingCustomerAccountsMainSection.fields.borderWidth)

  OBJECT

  The customer accounts branding section customizations.

* [Checkout​And​Accounts​Configuration​Branding​Customer​Accounts​Main​Section​Input.borderWidth](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingCustomerAccountsMainSectionInput#fields-borderWidth)

  INPUT OBJECT

  The input fields for customizing the customer accounts branding section.

* [Checkout​And​Accounts​Configuration​Branding​Divider​Style.borderWidth](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingDividerStyle#field-CheckoutAndAccountsConfigurationBrandingDividerStyle.fields.borderWidth)

  OBJECT

  The customizations for the page, content, main, and order summary dividers.

* [Checkout​And​Accounts​Configuration​Branding​Divider​Style​Input.borderWidth](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingDividerStyleInput#fields-borderWidth)

  INPUT OBJECT

  The input fields for customizing the global divider.

* [Checkout​And​Accounts​Configuration​Branding​Main​Section.borderWidth](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingMainSection#field-CheckoutAndAccountsConfigurationBrandingMainSection.fields.borderWidth)

  OBJECT

  The main sections customizations.

* [Checkout​And​Accounts​Configuration​Branding​Main​Section​Input.borderWidth](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingMainSectionInput#fields-borderWidth)

  INPUT OBJECT

  The input fields for customizing the main sections.

* [Checkout​And​Accounts​Configuration​Branding​Order​Summary​Section.borderWidth](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingOrderSummarySection#field-CheckoutAndAccountsConfigurationBrandingOrderSummarySection.fields.borderWidth)

  OBJECT

  The order summary sections customizations.

* [Checkout​And​Accounts​Configuration​Branding​Order​Summary​Section​Input.borderWidth](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingOrderSummarySectionInput#fields-borderWidth)

  INPUT OBJECT

  The input fields for customizing the order summary sections.

***

## Map

### Fields with this enum

* [Checkout​And​Accounts​Configuration​Branding​Container​Divider.borderWidth](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingContainerDivider#field-CheckoutAndAccountsConfigurationBrandingContainerDivider.fields.borderWidth)
* [Checkout​And​Accounts​Configuration​Branding​Customer​Accounts​Main​Section.borderWidth](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingCustomerAccountsMainSection#field-CheckoutAndAccountsConfigurationBrandingCustomerAccountsMainSection.fields.borderWidth)
* [Checkout​And​Accounts​Configuration​Branding​Divider​Style.borderWidth](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingDividerStyle#field-CheckoutAndAccountsConfigurationBrandingDividerStyle.fields.borderWidth)
* [Checkout​And​Accounts​Configuration​Branding​Main​Section.borderWidth](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingMainSection#field-CheckoutAndAccountsConfigurationBrandingMainSection.fields.borderWidth)
* [Checkout​And​Accounts​Configuration​Branding​Order​Summary​Section.borderWidth](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingOrderSummarySection#field-CheckoutAndAccountsConfigurationBrandingOrderSummarySection.fields.borderWidth)

### Inputs with this enum

* [Checkout​And​Accounts​Configuration​Branding​Container​Divider​Input.borderWidth](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingContainerDividerInput#fields-borderWidth)
* [Checkout​And​Accounts​Configuration​Branding​Customer​Accounts​Main​Section​Input.borderWidth](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingCustomerAccountsMainSectionInput#fields-borderWidth)
* [Checkout​And​Accounts​Configuration​Branding​Divider​Style​Input.borderWidth](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingDividerStyleInput#fields-borderWidth)
* [Checkout​And​Accounts​Configuration​Branding​Main​Section​Input.borderWidth](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingMainSectionInput#fields-borderWidth)
* [Checkout​And​Accounts​Configuration​Branding​Order​Summary​Section​Input.borderWidth](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingOrderSummarySectionInput#fields-borderWidth)

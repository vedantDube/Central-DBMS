---
title: BlogCreateUserErrorCode - GraphQL Admin
description: Possible error codes that can be returned by `BlogCreateUserError`.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/BlogCreateUserErrorCode
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/BlogCreateUserErrorCode.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Blog​Create​User​Error​Code

enum

Possible error codes that can be returned by `BlogCreateUserError`.

## Valid values

* INCLUSION

  The input value isn't included in the list.

* INVALID

  The input value is invalid.

* INVALID\_​TYPE

  The metafield type is invalid.

* INVALID\_​VALUE

  The value is invalid for the metafield type or for the definition options.

* TOO\_​LONG

  The input value is too long.

***

## Fields

* [Blog​Create​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/BlogCreateUserError#field-BlogCreateUserError.fields.code)

  OBJECT

  An error that occurs during the execution of `BlogCreate`.

***

## Map

### Fields with this enum

* [Blog​Create​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/BlogCreateUserError#field-BlogCreateUserError.fields.code)

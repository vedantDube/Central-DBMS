---
title: CollectionDuplicateUserErrorCode - GraphQL Admin
description: Possible error codes that can be returned by `CollectionDuplicateUserError`.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CollectionDuplicateUserErrorCode
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CollectionDuplicateUserErrorCode.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Collection​Duplicate​User​Error​Code

enum

Possible error codes that can be returned by `CollectionDuplicateUserError`.

## Valid values

* COLLECTION\_​NOT\_​FOUND

  The collection was not found. Please check the collection ID and try again.

***

## Fields

* [Collection​Duplicate​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CollectionDuplicateUserError#field-CollectionDuplicateUserError.fields.code)

  OBJECT

  Errors related to collection duplication.

***

## Map

### Fields with this enum

* [Collection​Duplicate​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CollectionDuplicateUserError#field-CollectionDuplicateUserError.fields.code)

---
title: InventoryTransferDuplicateUserErrorCode - GraphQL Admin
description: >-
  Possible error codes that can be returned by
  `InventoryTransferDuplicateUserError`.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/InventoryTransferDuplicateUserErrorCode
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/InventoryTransferDuplicateUserErrorCode.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Inventory​Transfer​Duplicate​User​Error​Code

enum

Possible error codes that can be returned by `InventoryTransferDuplicateUserError`.

## Valid values

* IDEMPOTENCY\_​CONCURRENT\_​REQUEST

  This request is currently in progress, please try again.

* IDEMPOTENCY\_​KEY\_​PARAMETER\_​MISMATCH

  The same idempotency key cannot be used with different operation parameters.

* TRANSFER\_​NOT\_​FOUND

  The transfer was not found.

***

## Fields

* [Inventory​Transfer​Duplicate​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/InventoryTransferDuplicateUserError#field-InventoryTransferDuplicateUserError.fields.code)

  OBJECT

  An error that occurs during the execution of `InventoryTransferDuplicate`.

***

## Map

### Fields with this enum

* [Inventory​Transfer​Duplicate​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/InventoryTransferDuplicateUserError#field-InventoryTransferDuplicateUserError.fields.code)

---
title: CustomerEmailMarketingConsentUpdateUserErrorCode - GraphQL Admin
description: >-
  Possible error codes that can be returned by
  `CustomerEmailMarketingConsentUpdateUserError`.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CustomerEmailMarketingConsentUpdateUserErrorCode
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CustomerEmailMarketingConsentUpdateUserErrorCode.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Customer​Email​Marketing​Consent​Update​User​Error​Code

enum

Possible error codes that can be returned by `CustomerEmailMarketingConsentUpdateUserError`.

## Valid values

* INCLUSION

  The input value isn't included in the list.

* INTERNAL\_​ERROR

  Unexpected internal error happened.

* INVALID

  The input value is invalid.

* MISSING\_​ARGUMENT

  Missing a required argument.

***

## Fields

* [Customer​Email​Marketing​Consent​Update​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CustomerEmailMarketingConsentUpdateUserError#field-CustomerEmailMarketingConsentUpdateUserError.fields.code)

  OBJECT

  An error that occurs during the execution of `CustomerEmailMarketingConsentUpdate`.

***

## Map

### Fields with this enum

* [Customer​Email​Marketing​Consent​Update​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CustomerEmailMarketingConsentUpdateUserError#field-CustomerEmailMarketingConsentUpdateUserError.fields.code)

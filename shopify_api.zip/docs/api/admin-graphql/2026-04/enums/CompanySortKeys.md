---
title: CompanySortKeys - GraphQL Admin
description: The set of valid sort keys for the Company query.
api_version: 2026-04
source_url:
  html: 'https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CompanySortKeys'
  md: 'https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CompanySortKeys.md'
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Company​Sort​Keys

enum

The set of valid sort keys for the Company query.

## Valid values

* CREATED\_​AT

  Sort by the `created_at` value.

* ID

  Sort by the `id` value.

* NAME

  Sort by the `name` value.

* ORDER\_​COUNT

  Sort by the `order_count` value.

* SINCE\_​DATE

  Sort by the `since_date` value.

* TOTAL\_​SPENT

  Sort by the `total_spent` value.

* UPDATED\_​AT

  Sort by the `updated_at` value.

***

## Fields

* [Query​Root.companies(sortKey)](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/QueryRoot#field-QueryRoot.fields.companies.arguments.sortKey)

  ARGUMENT

  The schema's entry-point for queries. This acts as the public, top-level API from which all queries must start.

* [companies.sortKey](https://shopify.dev/docs/api/admin-graphql/2026-04/queries/companies#arguments-sortKey)

  ARGUMENT

***

## Map

### Arguments with this enum

* [Query​Root.companies(sortKey)](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/QueryRoot#field-QueryRoot.fields.companies.arguments.sortKey)
* [companies.sortKey](https://shopify.dev/docs/api/admin-graphql/2026-04/queries/companies#arguments-sortKey)

---
title: AbandonmentUpdateActivitiesDeliveryStatusesUserErrorCode - GraphQL Admin
description: >-
  Possible error codes that can be returned by
  `AbandonmentUpdateActivitiesDeliveryStatusesUserError`.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/AbandonmentUpdateActivitiesDeliveryStatusesUserErrorCode
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/AbandonmentUpdateActivitiesDeliveryStatusesUserErrorCode.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Abandonment​Update​Activities​Delivery​Statuses​User​Error​Code

enum

Possible error codes that can be returned by `AbandonmentUpdateActivitiesDeliveryStatusesUserError`.

## Valid values

* ABANDONMENT\_​NOT\_​FOUND

  Unable to find an Abandonment for the provided ID.

* DELIVERY\_​STATUS\_​INFO\_​NOT\_​FOUND

  Unable to find delivery status info for the provided ID.

* MARKETING\_​ACTIVITY\_​NOT\_​FOUND

  Unable to find a marketing activity for the provided ID.

***

## Fields

* [Abandonment​Update​Activities​Delivery​Statuses​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/AbandonmentUpdateActivitiesDeliveryStatusesUserError#field-AbandonmentUpdateActivitiesDeliveryStatusesUserError.fields.code)

  OBJECT

  An error that occurs during the execution of `AbandonmentUpdateActivitiesDeliveryStatuses`.

***

## Map

### Fields with this enum

* [Abandonment​Update​Activities​Delivery​Statuses​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/AbandonmentUpdateActivitiesDeliveryStatusesUserError#field-AbandonmentUpdateActivitiesDeliveryStatusesUserError.fields.code)

---
title: CheckoutAndAccountsConfigurationUserErrorCode - GraphQL Admin
description: >-
  Possible error codes that can be returned by
  `CheckoutAndAccountsConfigurationUserError`.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutAndAccountsConfigurationUserErrorCode
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutAndAccountsConfigurationUserErrorCode.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Checkout​And​Accounts​Configuration​User​Error​Code

enum

Possible error codes that can be returned by `CheckoutAndAccountsConfigurationUserError`.

## Valid values

* BLANK

  The input value is blank.

* INTERNAL\_​SERVER\_​ERROR

  Internal error. Looks like something went wrong on our end.

* INVALID

  The input value is invalid.

* MISSING

  One or more required fields are missing in the input.

* NOT\_​FOUND

  One or more requested items couldn't be found.

* TRANSIENT

  The request could not be completed — please try again later.

***

## Fields

* [Checkout​And​Accounts​Configuration​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationUserError#field-CheckoutAndAccountsConfigurationUserError.fields.code)

  OBJECT

  An error that occurs during the execution of a mutation for managing checkout and accounts configurations.

***

## Map

### Fields with this enum

* [Checkout​And​Accounts​Configuration​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationUserError#field-CheckoutAndAccountsConfigurationUserError.fields.code)

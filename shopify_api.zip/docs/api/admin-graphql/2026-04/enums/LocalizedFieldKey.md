---
title: LocalizedFieldKey - GraphQL Admin
description: The key of a localized field.
api_version: 2026-04
source_url:
  html: 'https://shopify.dev/docs/api/admin-graphql/2026-04/enums/LocalizedFieldKey'
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/LocalizedFieldKey.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Localized​Field​Key

enum

The key of a localized field.

## Valid values

* SHIPPING\_​CREDENTIAL\_​BR

  Localized field key 'shipping\_credential\_br' for country Brazil.

* SHIPPING\_​CREDENTIAL\_​CL

  Localized field key 'shipping\_credential\_cl' for country Chile.

* SHIPPING\_​CREDENTIAL\_​CN

  Localized field key 'shipping\_credential\_cn' for country China.

* SHIPPING\_​CREDENTIAL\_​CO

  Localized field key 'shipping\_credential\_co' for country Colombia.

* SHIPPING\_​CREDENTIAL\_​CR

  Localized field key 'shipping\_credential\_cr' for country Costa Rica.

* SHIPPING\_​CREDENTIAL\_​EC

  Localized field key 'shipping\_credential\_ec' for country Ecuador.

* SHIPPING\_​CREDENTIAL\_​ES

  Localized field key 'shipping\_credential\_es' for country Spain.

* SHIPPING\_​CREDENTIAL\_​GT

  Localized field key 'shipping\_credential\_gt' for country Guatemala.

* SHIPPING\_​CREDENTIAL\_​ID

  Localized field key 'shipping\_credential\_id' for country Indonesia.

* SHIPPING\_​CREDENTIAL\_​KR

  Localized field key 'shipping\_credential\_kr' for country South Korea.

* SHIPPING\_​CREDENTIAL\_​MX

  Localized field key 'shipping\_credential\_mx' for country Mexico.

* SHIPPING\_​CREDENTIAL\_​MY

  Localized field key 'shipping\_credential\_my' for country Malaysia.

* SHIPPING\_​CREDENTIAL\_​PE

  Localized field key 'shipping\_credential\_pe' for country Peru.

* SHIPPING\_​CREDENTIAL\_​PT

  Localized field key 'shipping\_credential\_pt' for country Portugal.

* SHIPPING\_​CREDENTIAL\_​PY

  Localized field key 'shipping\_credential\_py' for country Paraguay.

* SHIPPING\_​CREDENTIAL\_​TR

  Localized field key 'shipping\_credential\_tr' for country Turkey.

* SHIPPING\_​CREDENTIAL\_​TW

  Localized field key 'shipping\_credential\_tw' for country Taiwan.

* SHIPPING\_​CREDENTIAL\_​TYPE\_​CO

  Localized field key 'shipping\_credential\_type\_co' for country Colombia.

* TAX\_​CREDENTIAL\_​BR

  Localized field key 'tax\_credential\_br' for country Brazil.

* TAX\_​CREDENTIAL\_​CL

  Localized field key 'tax\_credential\_cl' for country Chile.

* TAX\_​CREDENTIAL\_​CO

  Localized field key 'tax\_credential\_co' for country Colombia.

* TAX\_​CREDENTIAL\_​CR

  Localized field key 'tax\_credential\_cr' for country Costa Rica.

* TAX\_​CREDENTIAL\_​EC

  Localized field key 'tax\_credential\_ec' for country Ecuador.

* TAX\_​CREDENTIAL\_​ES

  Localized field key 'tax\_credential\_es' for country Spain.

* TAX\_​CREDENTIAL\_​GT

  Localized field key 'tax\_credential\_gt' for country Guatemala.

* TAX\_​CREDENTIAL\_​ID

  Localized field key 'tax\_credential\_id' for country Indonesia.

* TAX\_​CREDENTIAL\_​IT

  Localized field key 'tax\_credential\_it' for country Italy.

* TAX\_​CREDENTIAL\_​MX

  Localized field key 'tax\_credential\_mx' for country Mexico.

* TAX\_​CREDENTIAL\_​MY

  Localized field key 'tax\_credential\_my' for country Malaysia.

* TAX\_​CREDENTIAL\_​PE

  Localized field key 'tax\_credential\_pe' for country Peru.

* TAX\_​CREDENTIAL\_​PT

  Localized field key 'tax\_credential\_pt' for country Portugal.

* TAX\_​CREDENTIAL\_​PY

  Localized field key 'tax\_credential\_py' for country Paraguay.

* TAX\_​CREDENTIAL\_​TR

  Localized field key 'tax\_credential\_tr' for country Turkey.

* TAX\_​CREDENTIAL\_​TYPE\_​CO

  Localized field key 'tax\_credential\_type\_co' for country Colombia.

* TAX\_​CREDENTIAL\_​TYPE\_​MX

  Localized field key 'tax\_credential\_type\_mx' for country Mexico.

* TAX\_​CREDENTIAL\_​USE\_​MX

  Localized field key 'tax\_credential\_use\_mx' for country Mexico.

* TAX\_​EMAIL\_​IT

  Localized field key 'tax\_email\_it' for country Italy.

***

## Fields

* [Localized​Field.key](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/LocalizedField#field-LocalizedField.fields.key)

  OBJECT

  Represents the value captured by a localized field. Localized fields are additional fields required by certain countries on international orders. For example, some countries require additional fields for customs information or tax identification numbers.

* [Localized​Field​Input.key](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/LocalizedFieldInput#fields-key)

  INPUT OBJECT

  The input fields for a LocalizedFieldInput.

***

## Map

### Fields with this enum

* [Localized​Field.key](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/LocalizedField#field-LocalizedField.fields.key)

### Inputs with this enum

* [Localized​Field​Input.key](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/LocalizedFieldInput#fields-key)

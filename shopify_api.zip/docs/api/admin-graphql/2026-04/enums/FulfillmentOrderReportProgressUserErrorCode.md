---
title: FulfillmentOrderReportProgressUserErrorCode - GraphQL Admin
description: >-
  Possible error codes that can be returned by
  `FulfillmentOrderReportProgressUserError`.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/FulfillmentOrderReportProgressUserErrorCode
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/FulfillmentOrderReportProgressUserErrorCode.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Fulfillment​Order​Report​Progress​User​Error​Code

enum

Possible error codes that can be returned by `FulfillmentOrderReportProgressUserError`.

## Valid values

* FULFILLMENT\_​ORDER\_​CONTAINS\_​PICKED\_​ITEMS

  The fulfillment order contains picked items.

* FULFILLMENT\_​ORDER\_​INVALID\_​DELIVERY\_​METHOD

  Progress cannot be reported for a fulfillment order with this delivery method.

* FULFILLMENT\_​ORDER\_​INVALID\_​FULFILLMENT\_​SERVICE\_​OWNERSHIP

  The fulfillment order is not assigned to the requesting fulfillment service.

* FULFILLMENT\_​ORDER\_​NOT\_​FOUND

  The fulfillment order could not be found.

* FULFILLMENT\_​ORDER\_​STATUS\_​INVALID

  The fulfillment order status is invalid.

* FULFILLMENT\_​ORDER\_​UNSUPPORTED\_​ACTION

  The action is not supported for the fulfillment order.

* MARKETPLACE\_​APP\_​NOT\_​ELIGIBLE

  Marketplace apps are not eligible to report progress on fulfillment orders.

***

## Fields

* [Fulfillment​Order​Report​Progress​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/FulfillmentOrderReportProgressUserError#field-FulfillmentOrderReportProgressUserError.fields.code)

  OBJECT

  An error that occurs during the execution of `FulfillmentOrderReportProgress`.

***

## Map

### Fields with this enum

* [Fulfillment​Order​Report​Progress​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/FulfillmentOrderReportProgressUserError#field-FulfillmentOrderReportProgressUserError.fields.code)

---
title: CustomerPaymentMethodGetUpdateUrlUserErrorCode - GraphQL Admin
description: >-
  Possible error codes that can be returned by
  `CustomerPaymentMethodGetUpdateUrlUserError`.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CustomerPaymentMethodGetUpdateUrlUserErrorCode
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CustomerPaymentMethodGetUpdateUrlUserErrorCode.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Customer​Payment​Method​Get​Update​Url​User​Error​Code

enum

Possible error codes that can be returned by `CustomerPaymentMethodGetUpdateUrlUserError`.

## Valid values

* CUSTOMER\_​DOES\_​NOT\_​EXIST

  Customer doesn't exist.

* INVALID\_​INSTRUMENT

  Invalid payment instrument.

* PAYMENT\_​METHOD\_​DOES\_​NOT\_​EXIST

  Payment method doesn't exist.

* TOO\_​MANY\_​REQUESTS

  Too many requests.

***

## Fields

* [Customer​Payment​Method​Get​Update​Url​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CustomerPaymentMethodGetUpdateUrlUserError#field-CustomerPaymentMethodGetUpdateUrlUserError.fields.code)

  OBJECT

  An error that occurs during the execution of `CustomerPaymentMethodGetUpdateUrl`.

***

## Map

### Fields with this enum

* [Customer​Payment​Method​Get​Update​Url​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CustomerPaymentMethodGetUpdateUrlUserError#field-CustomerPaymentMethodGetUpdateUrlUserError.fields.code)

---
title: CheckoutAndAccountsConfigurationsGraphQLSortKeys - GraphQL Admin
description: >-
  The set of valid sort keys for the CheckoutAndAccountsConfigurationsGraphQL
  query.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutAndAccountsConfigurationsGraphQLSortKeys
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutAndAccountsConfigurationsGraphQLSortKeys.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Checkout​And​Accounts​Configurations​Graph​QLSort​Keys

enum

The set of valid sort keys for the CheckoutAndAccountsConfigurationsGraphQL query.

## Valid values

* CREATED\_​AT

  Sort by the `created_at` value.

* EDITED\_​AT

  Sort by the `edited_at` value.

* ID

  Sort by the `id` value.

* IS\_​PUBLISHED

  Sort by the `is_published` value.

***

## Fields

* [Query​Root.checkoutAndAccountsConfigurations(sortKey)](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/QueryRoot#field-QueryRoot.fields.checkoutAndAccountsConfigurations.arguments.sortKey)

  ARGUMENT

  The schema's entry-point for queries. This acts as the public, top-level API from which all queries must start.

* [checkout​And​Accounts​Configurations.sortKey](https://shopify.dev/docs/api/admin-graphql/2026-04/queries/checkoutAndAccountsConfigurations#arguments-sortKey)

  ARGUMENT

***

## Map

### Arguments with this enum

* [Query​Root.checkoutAndAccountsConfigurations(sortKey)](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/QueryRoot#field-QueryRoot.fields.checkoutAndAccountsConfigurations.arguments.sortKey)
* [checkout​And​Accounts​Configurations.sortKey](https://shopify.dev/docs/api/admin-graphql/2026-04/queries/checkoutAndAccountsConfigurations#arguments-sortKey)

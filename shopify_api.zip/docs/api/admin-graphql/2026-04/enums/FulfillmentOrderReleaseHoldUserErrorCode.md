---
title: FulfillmentOrderReleaseHoldUserErrorCode - GraphQL Admin
description: >-
  Possible error codes that can be returned by
  `FulfillmentOrderReleaseHoldUserError`.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/FulfillmentOrderReleaseHoldUserErrorCode
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/FulfillmentOrderReleaseHoldUserErrorCode.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Fulfillment​Order​Release​Hold​User​Error​Code

enum

Possible error codes that can be returned by `FulfillmentOrderReleaseHoldUserError`.

## Valid values

* FULFILLMENT\_​ORDER\_​NOT\_​FOUND

  The fulfillment order wasn't found.

* INVALID\_​ACCESS

  The app doesn't have access to release the fulfillment hold.

***

## Fields

* [Fulfillment​Order​Release​Hold​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/FulfillmentOrderReleaseHoldUserError#field-FulfillmentOrderReleaseHoldUserError.fields.code)

  OBJECT

  An error that occurs during the execution of `FulfillmentOrderReleaseHold`.

***

## Map

### Fields with this enum

* [Fulfillment​Order​Release​Hold​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/FulfillmentOrderReleaseHoldUserError#field-FulfillmentOrderReleaseHoldUserError.fields.code)

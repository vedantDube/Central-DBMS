---
title: CustomerMergeRequestStatus - GraphQL Admin
description: The status of the customer merge request.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CustomerMergeRequestStatus
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CustomerMergeRequestStatus.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Customer​Merge​Request​Status

enum

The status of the customer merge request.

## Valid values

* COMPLETED

  The customer merge request has been completed.

* FAILED

  The customer merge request has failed.

* IN\_​PROGRESS

  The customer merge request is currently in progress.

* REQUESTED

  The customer merge request has been requested.

***

## Fields

* [Customer​Merge​Request.status](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CustomerMergeRequest#field-CustomerMergeRequest.fields.status)

  OBJECT

  A merge request for merging two customers.

***

## Map

### Fields with this enum

* [Customer​Merge​Request.status](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CustomerMergeRequest#field-CustomerMergeRequest.fields.status)

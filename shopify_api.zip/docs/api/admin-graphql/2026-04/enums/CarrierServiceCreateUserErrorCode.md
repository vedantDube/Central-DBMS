---
title: CarrierServiceCreateUserErrorCode - GraphQL Admin
description: Possible error codes that can be returned by `CarrierServiceCreateUserError`.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CarrierServiceCreateUserErrorCode
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CarrierServiceCreateUserErrorCode.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Carrier​Service​Create​User​Error​Code

enum

Possible error codes that can be returned by `CarrierServiceCreateUserError`.

## Valid values

* CARRIER\_​SERVICE\_​CREATE\_​FAILED

  Carrier service creation failed.

***

## Fields

* [Carrier​Service​Create​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CarrierServiceCreateUserError#field-CarrierServiceCreateUserError.fields.code)

  OBJECT

  An error that occurs during the execution of `CarrierServiceCreate`.

***

## Map

### Fields with this enum

* [Carrier​Service​Create​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CarrierServiceCreateUserError#field-CarrierServiceCreateUserError.fields.code)

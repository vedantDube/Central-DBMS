---
title: CheckoutBrandingBorderWidth - GraphQL Admin
description: The container border width.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutBrandingBorderWidth
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutBrandingBorderWidth.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Checkout​Branding​Border​Width

enum

The container border width.

## Valid values

* BASE

  The Base border width.

* LARGE

  The Large border width.

* LARGE\_​100

  The Large 100 border width.

* LARGE\_​200

  The Large 200 border width.

***

## Fields

* [Checkout​Branding​Container​Divider.borderWidth](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutBrandingContainerDivider#field-CheckoutBrandingContainerDivider.fields.borderWidth)

  OBJECT

  The container's divider customizations.

* [Checkout​Branding​Container​Divider​Input.borderWidth](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutBrandingContainerDividerInput#fields-borderWidth)

  INPUT OBJECT

  The input fields used to update a container's divider customizations.

* [Checkout​Branding​Divider​Style.borderWidth](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutBrandingDividerStyle#field-CheckoutBrandingDividerStyle.fields.borderWidth)

  OBJECT

  The customizations for the page, content, main, and order summary dividers.

* [Checkout​Branding​Divider​Style​Input.borderWidth](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutBrandingDividerStyleInput#fields-borderWidth)

  INPUT OBJECT

  The input fields used to update the page, content, main and order summary dividers customizations.

* [Checkout​Branding​Main​Section.borderWidth](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutBrandingMainSection#field-CheckoutBrandingMainSection.fields.borderWidth)

  OBJECT

  The main sections customizations.

* [Checkout​Branding​Main​Section​Input.borderWidth](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutBrandingMainSectionInput#fields-borderWidth)

  INPUT OBJECT

  The input fields used to update the main sections customizations.

* [Checkout​Branding​Order​Summary​Section.borderWidth](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutBrandingOrderSummarySection#field-CheckoutBrandingOrderSummarySection.fields.borderWidth)

  OBJECT

  The order summary sections customizations.

* [Checkout​Branding​Order​Summary​Section​Input.borderWidth](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutBrandingOrderSummarySectionInput#fields-borderWidth)

  INPUT OBJECT

  The input fields used to update the order summary sections customizations.

***

## Map

### Fields with this enum

* [Checkout​Branding​Container​Divider.borderWidth](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutBrandingContainerDivider#field-CheckoutBrandingContainerDivider.fields.borderWidth)
* [Checkout​Branding​Divider​Style.borderWidth](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutBrandingDividerStyle#field-CheckoutBrandingDividerStyle.fields.borderWidth)
* [Checkout​Branding​Main​Section.borderWidth](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutBrandingMainSection#field-CheckoutBrandingMainSection.fields.borderWidth)
* [Checkout​Branding​Order​Summary​Section.borderWidth](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutBrandingOrderSummarySection#field-CheckoutBrandingOrderSummarySection.fields.borderWidth)

### Inputs with this enum

* [Checkout​Branding​Container​Divider​Input.borderWidth](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutBrandingContainerDividerInput#fields-borderWidth)
* [Checkout​Branding​Divider​Style​Input.borderWidth](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutBrandingDividerStyleInput#fields-borderWidth)
* [Checkout​Branding​Main​Section​Input.borderWidth](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutBrandingMainSectionInput#fields-borderWidth)
* [Checkout​Branding​Order​Summary​Section​Input.borderWidth](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutBrandingOrderSummarySectionInput#fields-borderWidth)

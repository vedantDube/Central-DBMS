---
title: CustomerRequestDataErasureErrorCode - GraphQL Admin
description: >-
  Possible error codes that can be returned by
  `CustomerRequestDataErasureUserError`.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CustomerRequestDataErasureErrorCode
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CustomerRequestDataErasureErrorCode.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Customer​Request​Data​Erasure​Error​Code

enum

Possible error codes that can be returned by `CustomerRequestDataErasureUserError`.

## Valid values

* DOES\_​NOT\_​EXIST

  Customer does not exist.

* FAILED\_​TO\_​REQUEST

  Failed to request customer data erasure.

***

## Fields

* [Customer​Request​Data​Erasure​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CustomerRequestDataErasureUserError#field-CustomerRequestDataErasureUserError.fields.code)

  OBJECT

  An error that occurs when requesting a customer data erasure.

***

## Map

### Fields with this enum

* [Customer​Request​Data​Erasure​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CustomerRequestDataErasureUserError#field-CustomerRequestDataErasureUserError.fields.code)

---
title: CheckoutBrandingBorderStyle - GraphQL Admin
description: The container border style.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutBrandingBorderStyle
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutBrandingBorderStyle.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Checkout​Branding​Border​Style

enum

The container border style.

## Valid values

* BASE

  The Base border style.

* DASHED

  The Dashed border style.

* DOTTED

  The Dotted border style.

***

## Fields

* [Checkout​Branding​Container​Divider.borderStyle](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutBrandingContainerDivider#field-CheckoutBrandingContainerDivider.fields.borderStyle)

  OBJECT

  The container's divider customizations.

* [Checkout​Branding​Container​Divider​Input.borderStyle](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutBrandingContainerDividerInput#fields-borderStyle)

  INPUT OBJECT

  The input fields used to update a container's divider customizations.

* [Checkout​Branding​Divider​Style.borderStyle](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutBrandingDividerStyle#field-CheckoutBrandingDividerStyle.fields.borderStyle)

  OBJECT

  The customizations for the page, content, main, and order summary dividers.

* [Checkout​Branding​Divider​Style​Input.borderStyle](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutBrandingDividerStyleInput#fields-borderStyle)

  INPUT OBJECT

  The input fields used to update the page, content, main and order summary dividers customizations.

* [Checkout​Branding​Main​Section.borderStyle](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutBrandingMainSection#field-CheckoutBrandingMainSection.fields.borderStyle)

  OBJECT

  The main sections customizations.

* [Checkout​Branding​Main​Section​Input.borderStyle](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutBrandingMainSectionInput#fields-borderStyle)

  INPUT OBJECT

  The input fields used to update the main sections customizations.

* [Checkout​Branding​Order​Summary​Section.borderStyle](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutBrandingOrderSummarySection#field-CheckoutBrandingOrderSummarySection.fields.borderStyle)

  OBJECT

  The order summary sections customizations.

* [Checkout​Branding​Order​Summary​Section​Input.borderStyle](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutBrandingOrderSummarySectionInput#fields-borderStyle)

  INPUT OBJECT

  The input fields used to update the order summary sections customizations.

***

## Map

### Fields with this enum

* [Checkout​Branding​Container​Divider.borderStyle](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutBrandingContainerDivider#field-CheckoutBrandingContainerDivider.fields.borderStyle)
* [Checkout​Branding​Divider​Style.borderStyle](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutBrandingDividerStyle#field-CheckoutBrandingDividerStyle.fields.borderStyle)
* [Checkout​Branding​Main​Section.borderStyle](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutBrandingMainSection#field-CheckoutBrandingMainSection.fields.borderStyle)
* [Checkout​Branding​Order​Summary​Section.borderStyle](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutBrandingOrderSummarySection#field-CheckoutBrandingOrderSummarySection.fields.borderStyle)

### Inputs with this enum

* [Checkout​Branding​Container​Divider​Input.borderStyle](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutBrandingContainerDividerInput#fields-borderStyle)
* [Checkout​Branding​Divider​Style​Input.borderStyle](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutBrandingDividerStyleInput#fields-borderStyle)
* [Checkout​Branding​Main​Section​Input.borderStyle](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutBrandingMainSectionInput#fields-borderStyle)
* [Checkout​Branding​Order​Summary​Section​Input.borderStyle](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutBrandingOrderSummarySectionInput#fields-borderStyle)

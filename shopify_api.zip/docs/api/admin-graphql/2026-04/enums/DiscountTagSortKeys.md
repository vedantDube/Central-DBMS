---
title: DiscountTagSortKeys - GraphQL Admin
description: The set of valid sort keys for the DiscountTag query.
api_version: 2026-04
source_url:
  html: 'https://shopify.dev/docs/api/admin-graphql/2026-04/enums/DiscountTagSortKeys'
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/DiscountTagSortKeys.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Discount​Tag​Sort​Keys

enum

The set of valid sort keys for the DiscountTag query.

## Valid values

* ID

  Sort by the `id` value.

* TITLE

  Sort by the `title` value.

***

## Fields

* [Query​Root.discountTags(sortKey)](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/QueryRoot#field-QueryRoot.fields.discountTags.arguments.sortKey)

  ARGUMENT

  The schema's entry-point for queries. This acts as the public, top-level API from which all queries must start.

* [discount​Tags.sortKey](https://shopify.dev/docs/api/admin-graphql/2026-04/queries/discountTags#arguments-sortKey)

  ARGUMENT

***

## Map

### Arguments with this enum

* [Query​Root.discountTags(sortKey)](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/QueryRoot#field-QueryRoot.fields.discountTags.arguments.sortKey)
* [discount​Tags.sortKey](https://shopify.dev/docs/api/admin-graphql/2026-04/queries/discountTags#arguments-sortKey)

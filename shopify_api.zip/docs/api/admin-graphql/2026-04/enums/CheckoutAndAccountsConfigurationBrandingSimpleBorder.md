---
title: CheckoutAndAccountsConfigurationBrandingSimpleBorder - GraphQL Admin
description: Possible values for the simple border.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutAndAccountsConfigurationBrandingSimpleBorder
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutAndAccountsConfigurationBrandingSimpleBorder.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Checkout​And​Accounts​Configuration​Branding​Simple​Border

enum

Possible values for the simple border.

## Valid values

* FULL

  The Full simple border.

* NONE

  The None simple border.

***

## Fields

* [Checkout​And​Accounts​Configuration​Branding​Button.border](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingButton#field-CheckoutAndAccountsConfigurationBrandingButton.fields.border)

  OBJECT

  The buttons customizations.

* [Checkout​And​Accounts​Configuration​Branding​Button​Input.border](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingButtonInput#fields-border)

  INPUT OBJECT

  The input fields for customizing the buttons.

* [Checkout​And​Accounts​Configuration​Branding​Control.border](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingControl#field-CheckoutAndAccountsConfigurationBrandingControl.fields.border)

  OBJECT

  The form controls customizations.

* [Checkout​And​Accounts​Configuration​Branding​Control​Input.border](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingControlInput#fields-border)

  INPUT OBJECT

  The input fields for customizing the form controls.

* [Checkout​And​Accounts​Configuration​Branding​Customer​Accounts​Main​Section.border](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingCustomerAccountsMainSection#field-CheckoutAndAccountsConfigurationBrandingCustomerAccountsMainSection.fields.border)

  OBJECT

  The customer accounts branding section customizations.

* [Checkout​And​Accounts​Configuration​Branding​Customer​Accounts​Main​Section​Input.border](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingCustomerAccountsMainSectionInput#fields-border)

  INPUT OBJECT

  The input fields for customizing the customer accounts branding section.

* [Checkout​And​Accounts​Configuration​Branding​Main​Section.border](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingMainSection#field-CheckoutAndAccountsConfigurationBrandingMainSection.fields.border)

  OBJECT

  The main sections customizations.

* [Checkout​And​Accounts​Configuration​Branding​Main​Section​Input.border](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingMainSectionInput#fields-border)

  INPUT OBJECT

  The input fields for customizing the main sections.

* [Checkout​And​Accounts​Configuration​Branding​Merchandise​Thumbnail.border](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingMerchandiseThumbnail#field-CheckoutAndAccountsConfigurationBrandingMerchandiseThumbnail.fields.border)

  OBJECT

  The merchandise thumbnails customizations.

* [Checkout​And​Accounts​Configuration​Branding​Merchandise​Thumbnail​Input.border](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingMerchandiseThumbnailInput#fields-border)

  INPUT OBJECT

  The input fields for customizing the merchandise thumbnails.

* [Checkout​And​Accounts​Configuration​Branding​Order​Summary​Section.border](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingOrderSummarySection#field-CheckoutAndAccountsConfigurationBrandingOrderSummarySection.fields.border)

  OBJECT

  The order summary sections customizations.

* [Checkout​And​Accounts​Configuration​Branding​Order​Summary​Section​Input.border](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingOrderSummarySectionInput#fields-border)

  INPUT OBJECT

  The input fields for customizing the order summary sections.

***

## Map

### Fields with this enum

* [Checkout​And​Accounts​Configuration​Branding​Button.border](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingButton#field-CheckoutAndAccountsConfigurationBrandingButton.fields.border)
* [Checkout​And​Accounts​Configuration​Branding​Control.border](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingControl#field-CheckoutAndAccountsConfigurationBrandingControl.fields.border)
* [Checkout​And​Accounts​Configuration​Branding​Customer​Accounts​Main​Section.border](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingCustomerAccountsMainSection#field-CheckoutAndAccountsConfigurationBrandingCustomerAccountsMainSection.fields.border)
* [Checkout​And​Accounts​Configuration​Branding​Main​Section.border](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingMainSection#field-CheckoutAndAccountsConfigurationBrandingMainSection.fields.border)
* [Checkout​And​Accounts​Configuration​Branding​Merchandise​Thumbnail.border](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingMerchandiseThumbnail#field-CheckoutAndAccountsConfigurationBrandingMerchandiseThumbnail.fields.border)
* [Checkout​And​Accounts​Configuration​Branding​Order​Summary​Section.border](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingOrderSummarySection#field-CheckoutAndAccountsConfigurationBrandingOrderSummarySection.fields.border)

### Inputs with this enum

* [Checkout​And​Accounts​Configuration​Branding​Button​Input.border](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingButtonInput#fields-border)
* [Checkout​And​Accounts​Configuration​Branding​Control​Input.border](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingControlInput#fields-border)
* [Checkout​And​Accounts​Configuration​Branding​Customer​Accounts​Main​Section​Input.border](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingCustomerAccountsMainSectionInput#fields-border)
* [Checkout​And​Accounts​Configuration​Branding​Main​Section​Input.border](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingMainSectionInput#fields-border)
* [Checkout​And​Accounts​Configuration​Branding​Merchandise​Thumbnail​Input.border](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingMerchandiseThumbnailInput#fields-border)
* [Checkout​And​Accounts​Configuration​Branding​Order​Summary​Section​Input.border](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingOrderSummarySectionInput#fields-border)

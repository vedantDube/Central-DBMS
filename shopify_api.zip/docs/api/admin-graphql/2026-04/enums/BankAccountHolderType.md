---
title: BankAccountHolderType - GraphQL Admin
description: The type of bank account holder.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/BankAccountHolderType
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/BankAccountHolderType.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Bank​Account​Holder​Type

enum

The type of bank account holder.

## Valid values

* COMPANY

  A company account holder.

* INDIVIDUAL

  An individual account holder.

***

## Fields

* [Bank​Account.accountHolderType](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/BankAccount#field-BankAccount.fields.accountHolderType)

  OBJECT

  Represents a bank account payment instrument.

***

## Map

### Fields with this enum

* [Bank​Account.accountHolderType](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/BankAccount#field-BankAccount.fields.accountHolderType)

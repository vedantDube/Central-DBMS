---
title: CheckoutAndAccountsConfigurationBrandingBorderStyle - GraphQL Admin
description: The container border style.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutAndAccountsConfigurationBrandingBorderStyle
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutAndAccountsConfigurationBrandingBorderStyle.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Checkout​And​Accounts​Configuration​Branding​Border​Style

enum

The container border style.

## Valid values

* BASE

  The Base border style.

* DASHED

  The Dashed border style.

* DOTTED

  The Dotted border style.

***

## Fields

* [Checkout​And​Accounts​Configuration​Branding​Container​Divider.borderStyle](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingContainerDivider#field-CheckoutAndAccountsConfigurationBrandingContainerDivider.fields.borderStyle)

  OBJECT

  The container's divider customizations.

* [Checkout​And​Accounts​Configuration​Branding​Container​Divider​Input.borderStyle](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingContainerDividerInput#fields-borderStyle)

  INPUT OBJECT

  The input fields for customizing a container's divider.

* [Checkout​And​Accounts​Configuration​Branding​Customer​Accounts​Main​Section.borderStyle](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingCustomerAccountsMainSection#field-CheckoutAndAccountsConfigurationBrandingCustomerAccountsMainSection.fields.borderStyle)

  OBJECT

  The customer accounts branding section customizations.

* [Checkout​And​Accounts​Configuration​Branding​Customer​Accounts​Main​Section​Input.borderStyle](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingCustomerAccountsMainSectionInput#fields-borderStyle)

  INPUT OBJECT

  The input fields for customizing the customer accounts branding section.

* [Checkout​And​Accounts​Configuration​Branding​Divider​Style.borderStyle](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingDividerStyle#field-CheckoutAndAccountsConfigurationBrandingDividerStyle.fields.borderStyle)

  OBJECT

  The customizations for the page, content, main, and order summary dividers.

* [Checkout​And​Accounts​Configuration​Branding​Divider​Style​Input.borderStyle](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingDividerStyleInput#fields-borderStyle)

  INPUT OBJECT

  The input fields for customizing the global divider.

* [Checkout​And​Accounts​Configuration​Branding​Main​Section.borderStyle](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingMainSection#field-CheckoutAndAccountsConfigurationBrandingMainSection.fields.borderStyle)

  OBJECT

  The main sections customizations.

* [Checkout​And​Accounts​Configuration​Branding​Main​Section​Input.borderStyle](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingMainSectionInput#fields-borderStyle)

  INPUT OBJECT

  The input fields for customizing the main sections.

* [Checkout​And​Accounts​Configuration​Branding​Order​Summary​Section.borderStyle](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingOrderSummarySection#field-CheckoutAndAccountsConfigurationBrandingOrderSummarySection.fields.borderStyle)

  OBJECT

  The order summary sections customizations.

* [Checkout​And​Accounts​Configuration​Branding​Order​Summary​Section​Input.borderStyle](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingOrderSummarySectionInput#fields-borderStyle)

  INPUT OBJECT

  The input fields for customizing the order summary sections.

***

## Map

### Fields with this enum

* [Checkout​And​Accounts​Configuration​Branding​Container​Divider.borderStyle](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingContainerDivider#field-CheckoutAndAccountsConfigurationBrandingContainerDivider.fields.borderStyle)
* [Checkout​And​Accounts​Configuration​Branding​Customer​Accounts​Main​Section.borderStyle](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingCustomerAccountsMainSection#field-CheckoutAndAccountsConfigurationBrandingCustomerAccountsMainSection.fields.borderStyle)
* [Checkout​And​Accounts​Configuration​Branding​Divider​Style.borderStyle](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingDividerStyle#field-CheckoutAndAccountsConfigurationBrandingDividerStyle.fields.borderStyle)
* [Checkout​And​Accounts​Configuration​Branding​Main​Section.borderStyle](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingMainSection#field-CheckoutAndAccountsConfigurationBrandingMainSection.fields.borderStyle)
* [Checkout​And​Accounts​Configuration​Branding​Order​Summary​Section.borderStyle](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingOrderSummarySection#field-CheckoutAndAccountsConfigurationBrandingOrderSummarySection.fields.borderStyle)

### Inputs with this enum

* [Checkout​And​Accounts​Configuration​Branding​Container​Divider​Input.borderStyle](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingContainerDividerInput#fields-borderStyle)
* [Checkout​And​Accounts​Configuration​Branding​Customer​Accounts​Main​Section​Input.borderStyle](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingCustomerAccountsMainSectionInput#fields-borderStyle)
* [Checkout​And​Accounts​Configuration​Branding​Divider​Style​Input.borderStyle](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingDividerStyleInput#fields-borderStyle)
* [Checkout​And​Accounts​Configuration​Branding​Main​Section​Input.borderStyle](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingMainSectionInput#fields-borderStyle)
* [Checkout​And​Accounts​Configuration​Branding​Order​Summary​Section​Input.borderStyle](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingOrderSummarySectionInput#fields-borderStyle)

---
title: CheckoutAndAccountsConfigurationBrandingVisibility - GraphQL Admin
description: Possible visibility states.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutAndAccountsConfigurationBrandingVisibility
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutAndAccountsConfigurationBrandingVisibility.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Checkout​And​Accounts​Configuration​Branding​Visibility

enum

Possible visibility states.

## Valid values

* HIDDEN

  The Hidden visibility setting.

* VISIBLE

  The Visible visibility setting.

***

## Fields

* [Checkout​And​Accounts​Configuration​Branding​Buyer​Journey.visibility](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingBuyerJourney#field-CheckoutAndAccountsConfigurationBrandingBuyerJourney.fields.visibility)

  OBJECT

  The customizations for the breadcrumbs that represent a buyer's journey to the checkout.

* [Checkout​And​Accounts​Configuration​Branding​Buyer​Journey​Input.visibility](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingBuyerJourneyInput#fields-visibility)

  INPUT OBJECT

  The input fields for updating breadcrumb customizations, which represent the buyer's journey to checkout.

* [Checkout​And​Accounts​Configuration​Branding​Cart​Link.visibility](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingCartLink#field-CheckoutAndAccountsConfigurationBrandingCartLink.fields.visibility)

  OBJECT

  The customizations that you can make to cart links at checkout.

* [Checkout​And​Accounts​Configuration​Branding​Cart​Link​Input.visibility](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingCartLinkInput#fields-visibility)

  INPUT OBJECT

  The input fields for customizing the cart link at Checkout.

* [Checkout​And​Accounts​Configuration​Branding​Container​Divider.visibility](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingContainerDivider#field-CheckoutAndAccountsConfigurationBrandingContainerDivider.fields.visibility)

  OBJECT

  The container's divider customizations.

* [Checkout​And​Accounts​Configuration​Branding​Container​Divider​Input.visibility](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingContainerDividerInput#fields-visibility)

  INPUT OBJECT

  The input fields for customizing a container's divider.

* [Checkout​And​Accounts​Configuration​Branding​Footer​Content.visibility](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingFooterContent#field-CheckoutAndAccountsConfigurationBrandingFooterContent.fields.visibility)

  OBJECT

  The footer content customizations.

* [Checkout​And​Accounts​Configuration​Branding​Footer​Content​Input.visibility](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingFooterContentInput#fields-visibility)

  INPUT OBJECT

  The input fields for customizing the footer content.

* [Checkout​And​Accounts​Configuration​Branding​Logo.visibility](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingLogo#field-CheckoutAndAccountsConfigurationBrandingLogo.fields.visibility)

  OBJECT

  The store logo customizations.

* [Checkout​And​Accounts​Configuration​Branding​Logo​Input.visibility](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingLogoInput#fields-visibility)

  INPUT OBJECT

  The input fields for customizing the logo.

***

## Map

### Fields with this enum

* [Checkout​And​Accounts​Configuration​Branding​Buyer​Journey.visibility](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingBuyerJourney#field-CheckoutAndAccountsConfigurationBrandingBuyerJourney.fields.visibility)
* [Checkout​And​Accounts​Configuration​Branding​Cart​Link.visibility](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingCartLink#field-CheckoutAndAccountsConfigurationBrandingCartLink.fields.visibility)
* [Checkout​And​Accounts​Configuration​Branding​Container​Divider.visibility](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingContainerDivider#field-CheckoutAndAccountsConfigurationBrandingContainerDivider.fields.visibility)
* [Checkout​And​Accounts​Configuration​Branding​Footer​Content.visibility](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingFooterContent#field-CheckoutAndAccountsConfigurationBrandingFooterContent.fields.visibility)
* [Checkout​And​Accounts​Configuration​Branding​Logo.visibility](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingLogo#field-CheckoutAndAccountsConfigurationBrandingLogo.fields.visibility)

### Inputs with this enum

* [Checkout​And​Accounts​Configuration​Branding​Buyer​Journey​Input.visibility](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingBuyerJourneyInput#fields-visibility)
* [Checkout​And​Accounts​Configuration​Branding​Cart​Link​Input.visibility](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingCartLinkInput#fields-visibility)
* [Checkout​And​Accounts​Configuration​Branding​Container​Divider​Input.visibility](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingContainerDividerInput#fields-visibility)
* [Checkout​And​Accounts​Configuration​Branding​Footer​Content​Input.visibility](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingFooterContentInput#fields-visibility)
* [Checkout​And​Accounts​Configuration​Branding​Logo​Input.visibility](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingLogoInput#fields-visibility)

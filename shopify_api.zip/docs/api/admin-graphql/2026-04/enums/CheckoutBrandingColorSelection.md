---
title: CheckoutBrandingColorSelection - GraphQL Admin
description: The possible colors.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutBrandingColorSelection
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutBrandingColorSelection.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Checkout​Branding​Color​Selection

enum

The possible colors.

## Valid values

* TRANSPARENT

  Transparent color selection.

***

## Fields

* [Checkout​Branding​Control.color](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutBrandingControl#field-CheckoutBrandingControl.fields.color)

  OBJECT

  The form controls customizations.

* [Checkout​Branding​Control​Input.color](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutBrandingControlInput#fields-color)

  INPUT OBJECT

  The input fields used to update the form controls customizations.

***

## Map

### Fields with this enum

* [Checkout​Branding​Control.color](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutBrandingControl#field-CheckoutBrandingControl.fields.color)

### Inputs with this enum

* [Checkout​Branding​Control​Input.color](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutBrandingControlInput#fields-color)

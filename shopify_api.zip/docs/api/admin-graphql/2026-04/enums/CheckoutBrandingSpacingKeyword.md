---
title: CheckoutBrandingSpacingKeyword - GraphQL Admin
description: The spacing between UI elements.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutBrandingSpacingKeyword
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutBrandingSpacingKeyword.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Checkout​Branding​Spacing​Keyword

enum

The spacing between UI elements.

## Valid values

* BASE

  The Base spacing.

* LARGE

  The Large spacing.

* LARGE\_​100

  The Large 100 spacing.

* LARGE\_​200

  The Large 200 spacing.

* LARGE\_​300

  The Large 300 spacing.

* LARGE\_​400

  The Large 400 spacing.

* LARGE\_​500

  The Large 500 spacing.

* NONE

  The None spacing.

* SMALL

  The Small spacing.

* SMALL\_​100

  The Small 100 spacing.

* SMALL\_​200

  The Small 200 spacing.

* SMALL\_​300

  The Small 300 spacing.

* SMALL\_​400

  The Small 400 spacing.

* SMALL\_​500

  The Small 500 spacing.

***

## Fields

* [Checkout​Branding​Choice​List​Group.spacing](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutBrandingChoiceListGroup#field-CheckoutBrandingChoiceListGroup.fields.spacing)

  OBJECT

  Controls the spacing between options in the 'group' variant of [`ChoiceList`](https://shopify.dev/docs/api/admin-graphql/latest/objects/CheckoutBrandingChoiceList) components.

  This setting adjusts the vertical spacing between choice options to improve readability and visual organization. The spacing value helps create clear separation between options, making it easier for customers to scan and select from available choices.

  Learn more about [checkout customization](https://shopify.dev/docs/api/admin-graphql/latest/objects/CheckoutBranding).

* [Checkout​Branding​Choice​List​Group​Input.spacing](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutBrandingChoiceListGroupInput#fields-spacing)

  INPUT OBJECT

  The input fields to update the settings that apply to the 'group' variant of ChoiceList.

* [Checkout​Branding​Footer.padding](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutBrandingFooter#field-CheckoutBrandingFooter.fields.padding)

  OBJECT

  A container for the footer section customizations.

* [Checkout​Branding​Footer​Input.padding](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutBrandingFooterInput#fields-padding)

  INPUT OBJECT

  The input fields when mutating the checkout footer settings.

* [Checkout​Branding​Header.padding](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutBrandingHeader#field-CheckoutBrandingHeader.fields.padding)

  OBJECT

  The header customizations.

* [Checkout​Branding​Header​Input.padding](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutBrandingHeaderInput#fields-padding)

  INPUT OBJECT

  The input fields used to update the header customizations.

* [Checkout​Branding​Main​Section.padding](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutBrandingMainSection#field-CheckoutBrandingMainSection.fields.padding)

  OBJECT

  The main sections customizations.

* [Checkout​Branding​Main​Section​Input.padding](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutBrandingMainSectionInput#fields-padding)

  INPUT OBJECT

  The input fields used to update the main sections customizations.

* [Checkout​Branding​Order​Summary​Section.padding](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutBrandingOrderSummarySection#field-CheckoutBrandingOrderSummarySection.fields.padding)

  OBJECT

  The order summary sections customizations.

* [Checkout​Branding​Order​Summary​Section​Input.padding](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutBrandingOrderSummarySectionInput#fields-padding)

  INPUT OBJECT

  The input fields used to update the order summary sections customizations.

***

## Map

### Fields with this enum

* [Checkout​Branding​Choice​List​Group.spacing](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutBrandingChoiceListGroup#field-CheckoutBrandingChoiceListGroup.fields.spacing)
* [Checkout​Branding​Footer.padding](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutBrandingFooter#field-CheckoutBrandingFooter.fields.padding)
* [Checkout​Branding​Header.padding](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutBrandingHeader#field-CheckoutBrandingHeader.fields.padding)
* [Checkout​Branding​Main​Section.padding](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutBrandingMainSection#field-CheckoutBrandingMainSection.fields.padding)
* [Checkout​Branding​Order​Summary​Section.padding](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutBrandingOrderSummarySection#field-CheckoutBrandingOrderSummarySection.fields.padding)

### Inputs with this enum

* [Checkout​Branding​Choice​List​Group​Input.spacing](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutBrandingChoiceListGroupInput#fields-spacing)
* [Checkout​Branding​Footer​Input.padding](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutBrandingFooterInput#fields-padding)
* [Checkout​Branding​Header​Input.padding](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutBrandingHeaderInput#fields-padding)
* [Checkout​Branding​Main​Section​Input.padding](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutBrandingMainSectionInput#fields-padding)
* [Checkout​Branding​Order​Summary​Section​Input.padding](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutBrandingOrderSummarySectionInput#fields-padding)

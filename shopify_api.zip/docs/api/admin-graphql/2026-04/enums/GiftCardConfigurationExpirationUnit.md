---
title: GiftCardConfigurationExpirationUnit - GraphQL Admin
description: The supported units for gift card expiration.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/GiftCardConfigurationExpirationUnit
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/GiftCardConfigurationExpirationUnit.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Gift​Card​Configuration​Expiration​Unit

enum

The supported units for gift card expiration.

## Valid values

* DAYS

  Gift cards expire in days.

* MONTHS

  Gift cards expire in months.

* YEARS

  Gift cards expire in years.

***

## Fields

* [Gift​Card​Expiration​Configuration.expirationUnit](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/GiftCardExpirationConfiguration#field-GiftCardExpirationConfiguration.fields.expirationUnit)

  OBJECT

  Represents the default expiration configuration of gift cards on the shop.

***

## Map

### Fields with this enum

* [Gift​Card​Expiration​Configuration.expirationUnit](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/GiftCardExpirationConfiguration#field-GiftCardExpirationConfiguration.fields.expirationUnit)

---
title: CustomerSmsMarketingState - GraphQL Admin
description: The valid SMS marketing states for a customer’s phone number.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CustomerSmsMarketingState
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CustomerSmsMarketingState.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Customer​Sms​Marketing​State

enum

The valid SMS marketing states for a customer’s phone number.

## Valid values

* NOT\_​SUBSCRIBED

  The customer hasn't subscribed to SMS marketing.

* PENDING

  The customer is in the process of subscribing to SMS marketing.

* REDACTED

  The customer's personal data is erased. This value is internally-set and read-only.

* SUBSCRIBED

  The customer is subscribed to SMS marketing.

* UNSUBSCRIBED

  The customer isn't currently subscribed to SMS marketing but was previously subscribed.

***

## Fields

* [Customer​Sms​Marketing​Consent​Input.marketingState](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CustomerSmsMarketingConsentInput#fields-marketingState)

  INPUT OBJECT

  The marketing consent information when the customer consented to receiving marketing material by SMS.

* [Customer​Sms​Marketing​Consent​State.marketingState](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CustomerSmsMarketingConsentState#field-CustomerSmsMarketingConsentState.fields.marketingState)

  OBJECT

  The record of when a customer consented to receive marketing material by SMS.

  The customer's consent state reflects the record with the most recent date when consent was updated.

* [Customer​Phone​Number.marketingState](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CustomerPhoneNumber#field-CustomerPhoneNumber.fields.marketingState)

  OBJECT

  Deprecated

***

## Map

### Fields with this enum

* [Customer​Sms​Marketing​Consent​State.marketingState](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CustomerSmsMarketingConsentState#field-CustomerSmsMarketingConsentState.fields.marketingState)

### Inputs with this enum

* [Customer​Sms​Marketing​Consent​Input.marketingState](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CustomerSmsMarketingConsentInput#fields-marketingState)

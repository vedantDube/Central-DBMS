---
title: InventoryShipmentReceiveLineItemReason - GraphQL Admin
description: The reason for receiving a line item on an inventory shipment.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/InventoryShipmentReceiveLineItemReason
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/InventoryShipmentReceiveLineItemReason.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Inventory​Shipment​Receive​Line​Item​Reason

enum

The reason for receiving a line item on an inventory shipment.

## Valid values

* ACCEPTED

  The line item was accepted.

* REJECTED

  The line item was rejected.

***

## Fields

* [Inventory​Shipment​Receive​Item​Input.reason](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/InventoryShipmentReceiveItemInput#fields-reason)

  INPUT OBJECT

  The input fields to receive an item on an inventory shipment.

* [inventory​Shipment​Receive.bulkReceiveAction](https://shopify.dev/docs/api/admin-graphql/2026-04/mutations/inventoryShipmentReceive#arguments-bulkReceiveAction)

  ARGUMENT

***

## Map

### Inputs with this enum

* [Inventory​Shipment​Receive​Item​Input.reason](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/InventoryShipmentReceiveItemInput#fields-reason)

### Arguments with this enum

* [inventory​Shipment​Receive.bulkReceiveAction](https://shopify.dev/docs/api/admin-graphql/2026-04/mutations/inventoryShipmentReceive#arguments-bulkReceiveAction)

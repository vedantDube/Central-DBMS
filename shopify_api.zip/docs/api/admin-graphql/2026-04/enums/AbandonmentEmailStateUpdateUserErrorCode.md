---
title: AbandonmentEmailStateUpdateUserErrorCode - GraphQL Admin
description: >-
  Possible error codes that can be returned by
  `AbandonmentEmailStateUpdateUserError`.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/AbandonmentEmailStateUpdateUserErrorCode
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/AbandonmentEmailStateUpdateUserErrorCode.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Abandonment​Email​State​Update​User​Error​Code

enum

Possible error codes that can be returned by `AbandonmentEmailStateUpdateUserError`.

## Valid values

* ABANDONMENT\_​NOT\_​FOUND

  Unable to find an Abandonment for the provided ID.

***

## Fields

* [Abandonment​Email​State​Update​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/AbandonmentEmailStateUpdateUserError#field-AbandonmentEmailStateUpdateUserError.fields.code)

  OBJECT

  An error that occurs during the execution of `AbandonmentEmailStateUpdate`.

***

## Map

### Fields with this enum

* [Abandonment​Email​State​Update​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/AbandonmentEmailStateUpdateUserError#field-AbandonmentEmailStateUpdateUserError.fields.code)

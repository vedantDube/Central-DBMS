---
title: CurrencyCode - GraphQL Admin
description: >-
  The currency codes that represent the world currencies throughout the Admin
  API. Currency codes include

  [standard ISO 4217 codes](https://en.wikipedia.org/wiki/ISO_4217), legacy
  codes, non-standard codes,

  digital currency codes.
api_version: 2026-04
source_url:
  html: 'https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CurrencyCode'
  md: 'https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CurrencyCode.md'
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Currency​Code

enum

The currency codes that represent the world currencies throughout the Admin API. Currency codes include [standard ISO 4217 codes](https://en.wikipedia.org/wiki/ISO_4217), legacy codes, non-standard codes, digital currency codes.

## Valid values

* AED

  United Arab Emirates Dirham (AED).

* AFN

  Afghan Afghani (AFN).

* ALL

  Albanian Lek (ALL).

* AMD

  Armenian Dram (AMD).

* ANG

  Netherlands Antillean Guilder.

* AOA

  Angolan Kwanza (AOA).

* ARS

  Argentine Pesos (ARS).

* AUD

  Australian Dollars (AUD).

* AWG

  Aruban Florin (AWG).

* AZN

  Azerbaijani Manat (AZN).

* BAM

  Bosnia and Herzegovina Convertible Mark (BAM).

* BBD

  Barbadian Dollar (BBD).

* BDT

  Bangladesh Taka (BDT).

* BGN

  Bulgarian Lev (BGN).

* BHD

  Bahraini Dinar (BHD).

* BIF

  Burundian Franc (BIF).

* BMD

  Bermudian Dollar (BMD).

* BND

  Brunei Dollar (BND).

* BOB

  Bolivian Boliviano (BOB).

* BRL

  Brazilian Real (BRL).

* BSD

  Bahamian Dollar (BSD).

* BTN

  Bhutanese Ngultrum (BTN).

* BWP

  Botswana Pula (BWP).

* BYN

  Belarusian Ruble (BYN).

* BZD

  Belize Dollar (BZD).

* CAD

  Canadian Dollars (CAD).

* CDF

  Congolese franc (CDF).

* CHF

  Swiss Francs (CHF).

* CLP

  Chilean Peso (CLP).

* CNY

  Chinese Yuan Renminbi (CNY).

* COP

  Colombian Peso (COP).

* CRC

  Costa Rican Colones (CRC).

* CVE

  Cape Verdean escudo (CVE).

* CZK

  Czech Koruny (CZK).

* DJF

  Djiboutian Franc (DJF).

* DKK

  Danish Kroner (DKK).

* DOP

  Dominican Peso (DOP).

* DZD

  Algerian Dinar (DZD).

* EGP

  Egyptian Pound (EGP).

* ERN

  Eritrean Nakfa (ERN).

* ETB

  Ethiopian Birr (ETB).

* EUR

  Euro (EUR).

* FJD

  Fijian Dollars (FJD).

* FKP

  Falkland Islands Pounds (FKP).

* GBP

  United Kingdom Pounds (GBP).

* GEL

  Georgian Lari (GEL).

* GHS

  Ghanaian Cedi (GHS).

* GIP

  Gibraltar Pounds (GIP).

* GMD

  Gambian Dalasi (GMD).

* GNF

  Guinean Franc (GNF).

* GTQ

  Guatemalan Quetzal (GTQ).

* GYD

  Guyanese Dollar (GYD).

* HKD

  Hong Kong Dollars (HKD).

* HNL

  Honduran Lempira (HNL).

* HRK

  Croatian Kuna (HRK).

* HTG

  Haitian Gourde (HTG).

* HUF

  Hungarian Forint (HUF).

* IDR

  Indonesian Rupiah (IDR).

* ILS

  Israeli New Shekel (NIS).

* INR

  Indian Rupees (INR).

* IQD

  Iraqi Dinar (IQD).

* IRR

  Iranian Rial (IRR).

* ISK

  Icelandic Kronur (ISK).

* JEP

  Jersey Pound.

* JMD

  Jamaican Dollars (JMD).

* JOD

  Jordanian Dinar (JOD).

* JPY

  Japanese Yen (JPY).

* KES

  Kenyan Shilling (KES).

* KGS

  Kyrgyzstani Som (KGS).

* KHR

  Cambodian Riel.

* KID

  Kiribati Dollar (KID).

* KMF

  Comorian Franc (KMF).

* KRW

  South Korean Won (KRW).

* KWD

  Kuwaiti Dinar (KWD).

* KYD

  Cayman Dollars (KYD).

* KZT

  Kazakhstani Tenge (KZT).

* LAK

  Laotian Kip (LAK).

* LBP

  Lebanese Pounds (LBP).

* LKR

  Sri Lankan Rupees (LKR).

* LRD

  Liberian Dollar (LRD).

* LSL

  Lesotho Loti (LSL).

* LTL

  Lithuanian Litai (LTL).

* LVL

  Latvian Lati (LVL).

* LYD

  Libyan Dinar (LYD).

* MAD

  Moroccan Dirham.

* MDL

  Moldovan Leu (MDL).

* MGA

  Malagasy Ariary (MGA).

* MKD

  Macedonia Denar (MKD).

* MMK

  Burmese Kyat (MMK).

* MNT

  Mongolian Tugrik.

* MOP

  Macanese Pataca (MOP).

* MRU

  Mauritanian Ouguiya (MRU).

* MUR

  Mauritian Rupee (MUR).

* MVR

  Maldivian Rufiyaa (MVR).

* MWK

  Malawian Kwacha (MWK).

* MXN

  Mexican Pesos (MXN).

* MYR

  Malaysian Ringgits (MYR).

* MZN

  Mozambican Metical.

* NAD

  Namibian Dollar.

* NGN

  Nigerian Naira (NGN).

* NIO

  Nicaraguan Córdoba (NIO).

* NOK

  Norwegian Kroner (NOK).

* NPR

  Nepalese Rupee (NPR).

* NZD

  New Zealand Dollars (NZD).

* OMR

  Omani Rial (OMR).

* PAB

  Panamian Balboa (PAB).

* PEN

  Peruvian Nuevo Sol (PEN).

* PGK

  Papua New Guinean Kina (PGK).

* PHP

  Philippine Peso (PHP).

* PKR

  Pakistani Rupee (PKR).

* PLN

  Polish Zlotych (PLN).

* PYG

  Paraguayan Guarani (PYG).

* QAR

  Qatari Rial (QAR).

* RON

  Romanian Lei (RON).

* RSD

  Serbian dinar (RSD).

* RUB

  Russian Rubles (RUB).

* RWF

  Rwandan Franc (RWF).

* SAR

  Saudi Riyal (SAR).

* SBD

  Solomon Islands Dollar (SBD).

* SCR

  Seychellois Rupee (SCR).

* SDG

  Sudanese Pound (SDG).

* SEK

  Swedish Kronor (SEK).

* SGD

  Singapore Dollars (SGD).

* SHP

  Saint Helena Pounds (SHP).

* SLL

  Sierra Leonean Leone (SLL).

* SOS

  Somali Shilling (SOS).

* SRD

  Surinamese Dollar (SRD).

* SSP

  South Sudanese Pound (SSP).

* STN

  Sao Tome And Principe Dobra (STN).

* SYP

  Syrian Pound (SYP).

* SZL

  Swazi Lilangeni (SZL).

* THB

  Thai baht (THB).

* TJS

  Tajikistani Somoni (TJS).

* TMT

  Turkmenistani Manat (TMT).

* TND

  Tunisian Dinar (TND).

* TOP

  Tongan Pa'anga (TOP).

* TRY

  Turkish Lira (TRY).

* TTD

  Trinidad and Tobago Dollars (TTD).

* TWD

  Taiwan Dollars (TWD).

* TZS

  Tanzanian Shilling (TZS).

* UAH

  Ukrainian Hryvnia (UAH).

* UGX

  Ugandan Shilling (UGX).

* USD

  United States Dollars (USD).

* USDC

  United States Dollars Coin (USDC).

* UYU

  Uruguayan Pesos (UYU).

* UZS

  Uzbekistan som (UZS).

* VED

  Venezuelan Bolivares (VED).

* VES

  Venezuelan Bolivares Soberanos (VES).

* VND

  Vietnamese đồng (VND).

* VUV

  Vanuatu Vatu (VUV).

* WST

  Samoan Tala (WST).

* XAF

  Central African CFA Franc (XAF).

* XCD

  East Caribbean Dollar (XCD).

* XOF

  West African CFA franc (XOF).

* XPF

  CFP Franc (XPF).

* XXX

  Unrecognized currency.

* YER

  Yemeni Rial (YER).

* ZAR

  South African Rand (ZAR).

* ZMW

  Zambian Kwacha (ZMW).

### Deprecated valid values

* BYR

  Deprecated

* STD

  Deprecated

* VEF

  Deprecated

***

## Fields

* [Calculated​Draft​Order.currencyCode](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CalculatedDraftOrder#field-CalculatedDraftOrder.fields.currencyCode)

  OBJECT

  Calculated pricing, taxes, and discounts for a [`DraftOrder`](https://shopify.dev/docs/api/admin-graphql/latest/objects/DraftOrder). Includes the complete financial breakdown with line items, discounts, shipping costs, tax calculations, and totals in both shop and presentment currencies.

  Available [`ShippingRate`](https://shopify.dev/docs/api/admin-graphql/latest/objects/ShippingRate) options are included when a valid shipping address and line items are present.

  ***

  **Note:** Returns alerts and warnings when issues occur during calculation, such as insufficient inventory or incompatible discounts.

  ***

* [Calculated​Draft​Order.presentmentCurrencyCode](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CalculatedDraftOrder#field-CalculatedDraftOrder.fields.presentmentCurrencyCode)

  OBJECT

  Calculated pricing, taxes, and discounts for a [`DraftOrder`](https://shopify.dev/docs/api/admin-graphql/latest/objects/DraftOrder). Includes the complete financial breakdown with line items, discounts, shipping costs, tax calculations, and totals in both shop and presentment currencies.

  Available [`ShippingRate`](https://shopify.dev/docs/api/admin-graphql/latest/objects/ShippingRate) options are included when a valid shipping address and line items are present.

  ***

  **Note:** Returns alerts and warnings when issues occur during calculation, such as insufficient inventory or incompatible discounts.

  ***

* [Company​Location.currency](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CompanyLocation#field-CompanyLocation.fields.currency)

  OBJECT

  A location or branch of a [`Company`](https://shopify.dev/docs/api/admin-graphql/latest/objects/Company) that's a customer of the shop. Company locations enable B2B customers to manage multiple branches with distinct billing and shipping addresses, tax settings, and checkout configurations.

  Each location can have its own [`Catalog`](https://shopify.dev/docs/api/admin-graphql/latest/interfaces/Catalog) objects that determine which products are published and their pricing. The [`BuyerExperienceConfiguration`](https://shopify.dev/docs/api/admin-graphql/latest/objects/BuyerExperienceConfiguration) determines checkout behavior including [`PaymentTerms`](https://shopify.dev/docs/api/admin-graphql/latest/objects/PaymentTerms), and whether orders require merchant review. B2B customers select which location they're purchasing for, which determines the applicable catalogs, pricing, [`TaxExemption`](https://shopify.dev/docs/api/admin-graphql/latest/enums/TaxExemption) values, and checkout settings for their [`Order`](https://shopify.dev/docs/api/admin-graphql/latest/objects/Order) objects.

* [Currency​Setting.currencyCode](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CurrencySetting#field-CurrencySetting.fields.currencyCode)

  OBJECT

  A setting for a presentment currency.

* [Draft​Order.currencyCode](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/DraftOrder#field-DraftOrder.fields.currencyCode)

  OBJECT

  An order that a merchant creates on behalf of a customer. Draft orders are useful for merchants that need to do the following tasks:

  * Create new orders for sales made by phone, in person, by chat, or elsewhere. When a merchant accepts payment for a draft order, an order is created.
  * Send invoices to customers to pay with a secure checkout link.
  * Use custom items to represent additional costs or products that aren't displayed in a shop's inventory.
  * Re-create orders manually from active sales channels.
  * Sell products at discount or wholesale rates.
  * Take pre-orders.

  For draft orders in multiple currencies `presentment_money` is the source of truth for what a customer is going to be charged and `shop_money` is an estimate of what the merchant might receive in their shop currency.

  **Caution:** Only use this data if it's required for your app's functionality. Shopify will restrict [access to scopes](https://shopify.dev/api/usage/access-scopes) for apps that don't have a legitimate use for the associated data.

  Draft orders created on or after April 1, 2025 will be automatically purged after one year of inactivity.

* [Draft​Order.presentmentCurrencyCode](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/DraftOrder#field-DraftOrder.fields.presentmentCurrencyCode)

  OBJECT

  An order that a merchant creates on behalf of a customer. Draft orders are useful for merchants that need to do the following tasks:

  * Create new orders for sales made by phone, in person, by chat, or elsewhere. When a merchant accepts payment for a draft order, an order is created.
  * Send invoices to customers to pay with a secure checkout link.
  * Use custom items to represent additional costs or products that aren't displayed in a shop's inventory.
  * Re-create orders manually from active sales channels.
  * Sell products at discount or wholesale rates.
  * Take pre-orders.

  For draft orders in multiple currencies `presentment_money` is the source of truth for what a customer is going to be charged and `shop_money` is an estimate of what the merchant might receive in their shop currency.

  **Caution:** Only use this data if it's required for your app's functionality. Shopify will restrict [access to scopes](https://shopify.dev/api/usage/access-scopes) for apps that don't have a legitimate use for the associated data.

  Draft orders created on or after April 1, 2025 will be automatically purged after one year of inactivity.

* [Draft​Order​Input.presentmentCurrencyCode](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/DraftOrderInput#fields-presentmentCurrencyCode)

  INPUT OBJECT

  The input fields used to create or update a draft order.

* [Market​Currency​Settings​Update​Input.baseCurrency](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/MarketCurrencySettingsUpdateInput#fields-baseCurrency)

  INPUT OBJECT

  The input fields used to update the currency settings of a market.

* [Markets​Resolved​Values.currencyCode](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/MarketsResolvedValues#field-MarketsResolvedValues.fields.currencyCode)

  OBJECT

  The resolved values based on the markets configuration for a buyer signal. Resolved values include the resolved catalogs, web presences, currency, and price inclusivity.

* [Money​Input.currencyCode](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/MoneyInput#fields-currencyCode)

  INPUT OBJECT

  The input fields for a monetary value with currency.

* [Money​V2.currencyCode](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/MoneyV2#field-MoneyV2.fields.currencyCode)

  OBJECT

  A precise monetary value and its associated currency. Combines a decimal amount with a three-letter currency code to express prices, costs, and other financial values throughout the API. For example, 12.99 USD.

* [Order.currencyCode](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/Order#field-Order.fields.currencyCode)

  OBJECT

  The `Order` object represents a customer's request to purchase one or more products from a store. Use the `Order` object to handle the complete purchase lifecycle from checkout to fulfillment.

  Use the `Order` object when you need to:

  * Display order details on customer account pages or admin dashboards.
  * Create orders for phone sales, wholesale customers, or subscription services.
  * Update order information like shipping addresses, notes, or fulfillment status.
  * Process returns, exchanges, and partial refunds.
  * Generate invoices, receipts, and shipping labels.

  The `Order` object serves as the central hub connecting customer information, product details, payment processing, and fulfillment data within the GraphQL Admin API schema.

  ***

  **Note:** Only the last 60 days\&#39; worth of orders from a store are accessible from the \<code>Order\</code> object by default. If you want to access older records, then you need to \<a href="https://shopify.dev/docs/api/usage/access-scopes#orders-permissions">request access to all orders\</a>. If your app is granted access, then you can add the \<code>\<span class="PreventFireFoxApplyingGapToWBR">read\<wbr/>\_all\<wbr/>\_orders\</span>\</code>, \<code>\<span class="PreventFireFoxApplyingGapToWBR">read\<wbr/>\_orders\</span>\</code>, and \<code>\<span class="PreventFireFoxApplyingGapToWBR">write\<wbr/>\_orders\</span>\</code> scopes.

  ***

  ***

  **Caution:** Only use orders data if it\&#39;s required for your app\&#39;s functionality. Shopify will restrict \<a href="https://shopify.dev/docs/api/usage/access-scopes#requesting-specific-permissions">access to scopes\</a> for apps that don\&#39;t have a legitimate use for the associated data.

  ***

  Learn more about [building apps for orders and fulfillment](https://shopify.dev/docs/apps/build/orders-fulfillment).

* [Order.presentmentCurrencyCode](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/Order#field-Order.fields.presentmentCurrencyCode)

  OBJECT

  The `Order` object represents a customer's request to purchase one or more products from a store. Use the `Order` object to handle the complete purchase lifecycle from checkout to fulfillment.

  Use the `Order` object when you need to:

  * Display order details on customer account pages or admin dashboards.
  * Create orders for phone sales, wholesale customers, or subscription services.
  * Update order information like shipping addresses, notes, or fulfillment status.
  * Process returns, exchanges, and partial refunds.
  * Generate invoices, receipts, and shipping labels.

  The `Order` object serves as the central hub connecting customer information, product details, payment processing, and fulfillment data within the GraphQL Admin API schema.

  ***

  **Note:** Only the last 60 days\&#39; worth of orders from a store are accessible from the \<code>Order\</code> object by default. If you want to access older records, then you need to \<a href="https://shopify.dev/docs/api/usage/access-scopes#orders-permissions">request access to all orders\</a>. If your app is granted access, then you can add the \<code>\<span class="PreventFireFoxApplyingGapToWBR">read\<wbr/>\_all\<wbr/>\_orders\</span>\</code>, \<code>\<span class="PreventFireFoxApplyingGapToWBR">read\<wbr/>\_orders\</span>\</code>, and \<code>\<span class="PreventFireFoxApplyingGapToWBR">write\<wbr/>\_orders\</span>\</code> scopes.

  ***

  ***

  **Caution:** Only use orders data if it\&#39;s required for your app\&#39;s functionality. Shopify will restrict \<a href="https://shopify.dev/docs/api/usage/access-scopes#requesting-specific-permissions">access to scopes\</a> for apps that don\&#39;t have a legitimate use for the associated data.

  ***

  Learn more about [building apps for orders and fulfillment](https://shopify.dev/docs/apps/build/orders-fulfillment).

* [Order​Capture​Input.currency](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/OrderCaptureInput#fields-currency)

  INPUT OBJECT

  The input fields for the authorized transaction to capture and the total amount to capture from it.

* [Order​Create​Order​Input.currency](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/OrderCreateOrderInput#fields-currency)

  INPUT OBJECT

  The input fields for creating an order.

* [Order​Create​Order​Input.presentmentCurrency](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/OrderCreateOrderInput#fields-presentmentCurrency)

  INPUT OBJECT

  The input fields for creating an order.

* [Order​Transaction.settlementCurrency](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/OrderTransaction#field-OrderTransaction.fields.settlementCurrency)

  OBJECT

  The `OrderTransaction` object represents a payment transaction that's associated with an order. An order transaction is a specific action or event that happens within the context of an order, such as a customer paying for a purchase or receiving a refund, or other payment-related activity.

  Use the `OrderTransaction` object to capture the complete lifecycle of a payment, from initial authorization to final settlement, including refunds and currency exchanges. Common use cases for using the `OrderTransaction` object include:

  * Processing new payments for orders
  * Managing payment authorizations and captures
  * Processing refunds for returned items
  * Tracking payment status and errors
  * Managing multi-currency transactions
  * Handling payment gateway integrations

  Each `OrderTransaction` object has a [`kind`](https://shopify.dev/docs/api/admin-graphql/latest/enums/OrderTransactionKind) that defines the type of transaction and a [`status`](https://shopify.dev/docs/api/admin-graphql/latest/enums/OrderTransactionStatus) that indicates the current state of the transaction. The object stores detailed information about payment methods, gateway processing, and settlement details.

  Learn more about [payment processing](https://help.shopify.com/manual/payments) and [payment gateway integrations](https://www.shopify.com/ca/payment-gateways).

* [Price​List.currency](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/PriceList#field-PriceList.fields.currency)

  OBJECT

  A list that defines pricing for [product variants](https://shopify.dev/docs/api/admin-graphql/latest/objects/ProductVariant). Price lists override default product prices with either fixed prices or percentage-based adjustments.

  Each price list associates with a [`Catalog`](https://shopify.dev/docs/api/admin-graphql/latest/interfaces/Catalog) to determine which customers see the pricing. The catalog's context rules control when the price list applies, such as for specific markets, company locations, or apps.

  Learn how to [support different pricing models](https://shopify.dev/docs/apps/build/markets/build-catalog).

* [Price​List​Create​Input.currency](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/PriceListCreateInput#fields-currency)

  INPUT OBJECT

  The input fields to create a price list.

* [Price​List​Update​Input.currency](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/PriceListUpdateInput#fields-currency)

  INPUT OBJECT

  The input fields used to update a price list.

* [Product​Variant.presentmentPrices(presentmentCurrencies)](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/ProductVariant#field-ProductVariant.fields.presentmentPrices.arguments.presentmentCurrencies)

  ARGUMENT

  The `ProductVariant` object represents a version of a [product](https://shopify.dev/docs/api/admin-graphql/latest/objects/Product) that comes in more than one [option](https://shopify.dev/docs/api/admin-graphql/latest/objects/ProductOption), such as size or color. For example, if a merchant sells t-shirts with options for size and color, then a small, blue t-shirt would be one product variant and a large, blue t-shirt would be another.

  Use the `ProductVariant` object to manage the full lifecycle and configuration of a product's variants. Common use cases for using the `ProductVariant` object include:

  * Tracking inventory for each variant
  * Setting unique prices for each variant
  * Assigning barcodes and SKUs to connect variants to fulfillment services
  * Attaching variant-specific images and media
  * Setting delivery and tax requirements
  * Supporting product bundles, subscriptions, and selling plans

  A `ProductVariant` is associated with a parent [`Product`](https://shopify.dev/docs/api/admin-graphql/latest/objects/Product) object. `ProductVariant` serves as the central link between a product's merchandising configuration, inventory, pricing, fulfillment, and sales channels within the GraphQL Admin API schema. Each variant can reference other GraphQL types such as:

  * [`InventoryItem`](https://shopify.dev/docs/api/admin-graphql/latest/objects/InventoryItem): Used for inventory tracking
  * [`Image`](https://shopify.dev/docs/api/admin-graphql/latest/objects/Image): Used for variant-specific images
  * [`SellingPlanGroup`](https://shopify.dev/docs/api/admin-graphql/latest/objects/SellingPlanGroup): Used for subscriptions and selling plans

  Learn more about [Shopify's product model](https://shopify.dev/docs/apps/build/graphql/migrate/new-product-model/product-model-components).

* [Refund​Input.currency](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/RefundInput#fields-currency)

  INPUT OBJECT

  The input fields to create a refund.

* [Shop.currencyCode](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/Shop#field-Shop.fields.currencyCode)

  OBJECT

  The central configuration and settings hub for a Shopify store. Access business information, operational preferences, feature availability, and store-wide settings that control how the shop operates.

  Includes core business details like the shop name, contact emails, billing address, and currency settings. The shop configuration determines customer account requirements, available sales channels, enabled features, payment settings, and policy documents. Also provides access to shop-level resources such as staff members, fulfillment services, navigation settings, and storefront access tokens.

* [Shop.enabledPresentmentCurrencies](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/Shop#field-Shop.fields.enabledPresentmentCurrencies)

  OBJECT

  The central configuration and settings hub for a Shopify store. Access business information, operational preferences, feature availability, and store-wide settings that control how the shop operates.

  Includes core business details like the shop name, contact emails, billing address, and currency settings. The shop configuration determines customer account requirements, available sales channels, enabled features, payment settings, and policy documents. Also provides access to shop-level resources such as staff members, fulfillment services, navigation settings, and storefront access tokens.

* [Shop​Billing​Preferences.currency](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/ShopBillingPreferences#field-ShopBillingPreferences.fields.currency)

  OBJECT

  Billing preferences for the shop.

* [Shop​Pay​Payment​Request.presentmentCurrency](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/ShopPayPaymentRequest#field-ShopPayPaymentRequest.fields.presentmentCurrency)

  OBJECT

  Represents a Shop Pay payment request.

* [Shopify​Payments​Account.defaultCurrency](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/ShopifyPaymentsAccount#field-ShopifyPaymentsAccount.fields.defaultCurrency)

  OBJECT

  Financial account information for merchants using Shopify Payments. Tracks current balances across all supported currencies, payout schedules, and [`ShopifyPaymentsBalanceTransaction`](https://shopify.dev/docs/api/admin-graphql/latest/objects/ShopifyPaymentsBalanceTransaction) records.

  The account includes configuration details such as [`ShopifyPaymentsBankAccount`](https://shopify.dev/docs/api/admin-graphql/latest/objects/ShopifyPaymentsBankAccount) objects for receiving [`ShopifyPaymentsPayout`](https://shopify.dev/docs/api/admin-graphql/latest/objects/ShopifyPaymentsPayout) transfers, statement descriptors that appear on customer credit card statements, and the [`ShopifyPaymentsPayoutSchedule`](https://shopify.dev/docs/api/admin-graphql/latest/objects/ShopifyPaymentsPayoutSchedule) that determines when funds transfer to your bank. Access balance transactions to review individual charges, refunds, and adjustments that affect your account balance. Query payouts to track money movement between your Shopify Payments balance and bank accounts.

* [Shopify​Payments​Bank​Account.currency](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/ShopifyPaymentsBankAccount#field-ShopifyPaymentsBankAccount.fields.currency)

  OBJECT

  A bank account that can receive payouts.

* [Subscription​Billing​Cycle​Edited​Contract.currencyCode](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/SubscriptionBillingCycleEditedContract#field-SubscriptionBillingCycleEditedContract.fields.currencyCode)

  OBJECT

  Represents a subscription contract with billing cycles.

* [Subscription​Contract.currencyCode](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/SubscriptionContract#field-SubscriptionContract.fields.currencyCode)

  OBJECT

  A subscription contract that defines recurring purchases for a customer. Each contract specifies what products to deliver, when to bill and ship them, and at what price.

  The contract includes [`SubscriptionBillingPolicy`](https://shopify.dev/docs/api/admin-graphql/latest/objects/SubscriptionBillingPolicy) and [`SubscriptionDeliveryPolicy`](https://shopify.dev/docs/api/admin-graphql/latest/objects/SubscriptionDeliveryPolicy) that control the frequency of charges and fulfillments. [`SubscriptionLine`](https://shopify.dev/docs/api/admin-graphql/latest/objects/SubscriptionLine) items define the products, quantities, and pricing for each recurring [`Order`](https://shopify.dev/docs/api/admin-graphql/latest/objects/Order). The contract tracks [`SubscriptionBillingAttempt`](https://shopify.dev/docs/api/admin-graphql/latest/objects/SubscriptionBillingAttempt) records, payment status, and generated orders throughout its lifecycle. [`App`](https://shopify.dev/docs/api/admin-graphql/latest/objects/App) instances manage contracts through various status transitions including active, paused, failed, cancelled, or expired states.

  Learn more about [building subscription contracts](https://shopify.dev/docs/apps/build/purchase-options/subscriptions/contracts/build-a-subscription-contract) and [updating subscription contracts](https://shopify.dev/docs/apps/build/purchase-options/subscriptions/contracts/update-a-subscription-contract).

* [Subscription​Contract​Atomic​Create​Input.currencyCode](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/SubscriptionContractAtomicCreateInput#fields-currencyCode)

  INPUT OBJECT

  The input fields required to create a Subscription Contract.

* [Subscription​Contract​Base.currencyCode](https://shopify.dev/docs/api/admin-graphql/2026-04/interfaces/SubscriptionContractBase#fields-currencyCode)

  INTERFACE

  Represents subscription contract common fields.

* [Subscription​Contract​Create​Input.currencyCode](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/SubscriptionContractCreateInput#fields-currencyCode)

  INPUT OBJECT

  The input fields required to create a Subscription Contract.

* [Subscription​Draft.currencyCode](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/SubscriptionDraft#field-SubscriptionDraft.fields.currencyCode)

  OBJECT

  The `SubscriptionDraft` object represents a draft version of a [subscription contract](https://shopify.dev/docs/api/admin-graphql/latest/objects/SubscriptionContract) before it's committed. It serves as a staging area for making changes to an existing subscription or creating a new one. The draft allows you to preview and modify various aspects of a subscription before applying the changes.

  Use the `SubscriptionDraft` object to:

  * Add, remove, or modify subscription lines and their quantities
  * Manage discounts (add, remove, or update manual and code-based discounts)
  * Configure delivery options and shipping methods
  * Set up billing and delivery policies
  * Manage customer payment methods
  * Add custom attributes and notes to generated orders
  * Configure billing cycles and next billing dates
  * Preview the projected state of the subscription

  Each `SubscriptionDraft` object maintains a projected state that shows how the subscription will look after the changes are committed. This allows you to preview the impact of your modifications before applying them. The draft can be associated with an existing subscription contract (for modifications) or used to create a new subscription.

  The draft remains in a draft state until it's committed, at which point the changes are applied to the subscription contract and the draft is no longer accessible.

  Learn more about [how subscription contracts work](https://shopify.dev/docs/apps/build/purchase-options/subscriptions/contracts) and how to [build](https://shopify.dev/docs/apps/build/purchase-options/subscriptions/contracts/build-a-subscription-contract), [update](https://shopify.dev/docs/apps/build/purchase-options/subscriptions/contracts/update-a-subscription-contract), and [combine](https://shopify.dev/docs/apps/build/purchase-options/subscriptions/contracts/combine-subscription-contracts) subscription contracts.

* [Query​Root.cashManagementShopSummary(currencyCode)](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/QueryRoot#field-QueryRoot.fields.cashManagementShopSummary.arguments.currencyCode)

  ARGUMENT

  The schema's entry-point for queries. This acts as the public, top-level API from which all queries must start.

* [shopify​Payments​Payout​Alternate​Currency​Create.currency](https://shopify.dev/docs/api/admin-graphql/2026-04/mutations/shopifyPaymentsPayoutAlternateCurrencyCreate#arguments-currency)

  ARGUMENT

* [cash​Management​Shop​Summary.currencyCode](https://shopify.dev/docs/api/admin-graphql/2026-04/queries/cashManagementShopSummary#arguments-currencyCode)

  ARGUMENT

***

## Map

### Fields with this enum

* [Calculated​Draft​Order.currencyCode](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CalculatedDraftOrder#field-CalculatedDraftOrder.fields.currencyCode)
* [Calculated​Draft​Order.presentmentCurrencyCode](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CalculatedDraftOrder#field-CalculatedDraftOrder.fields.presentmentCurrencyCode)
* [Company​Location.currency](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CompanyLocation#field-CompanyLocation.fields.currency)
* [Currency​Setting.currencyCode](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CurrencySetting#field-CurrencySetting.fields.currencyCode)
* [Draft​Order.currencyCode](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/DraftOrder#field-DraftOrder.fields.currencyCode)
* [Draft​Order.presentmentCurrencyCode](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/DraftOrder#field-DraftOrder.fields.presentmentCurrencyCode)
* [Markets​Resolved​Values.currencyCode](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/MarketsResolvedValues#field-MarketsResolvedValues.fields.currencyCode)
* [Money​V2.currencyCode](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/MoneyV2#field-MoneyV2.fields.currencyCode)
* [Order.currencyCode](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/Order#field-Order.fields.currencyCode)
* [Order.presentmentCurrencyCode](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/Order#field-Order.fields.presentmentCurrencyCode)
* [Order​Transaction.settlementCurrency](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/OrderTransaction#field-OrderTransaction.fields.settlementCurrency)
* [Price​List.currency](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/PriceList#field-PriceList.fields.currency)
* [Shop.currencyCode](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/Shop#field-Shop.fields.currencyCode)
* [Shop.enabledPresentmentCurrencies](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/Shop#field-Shop.fields.enabledPresentmentCurrencies)
* [Shop​Billing​Preferences.currency](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/ShopBillingPreferences#field-ShopBillingPreferences.fields.currency)
* [Shop​Pay​Payment​Request.presentmentCurrency](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/ShopPayPaymentRequest#field-ShopPayPaymentRequest.fields.presentmentCurrency)
* [Shopify​Payments​Account.defaultCurrency](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/ShopifyPaymentsAccount#field-ShopifyPaymentsAccount.fields.defaultCurrency)
* [Shopify​Payments​Bank​Account.currency](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/ShopifyPaymentsBankAccount#field-ShopifyPaymentsBankAccount.fields.currency)
* [Subscription​Billing​Cycle​Edited​Contract.currencyCode](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/SubscriptionBillingCycleEditedContract#field-SubscriptionBillingCycleEditedContract.fields.currencyCode)
* [Subscription​Contract.currencyCode](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/SubscriptionContract#field-SubscriptionContract.fields.currencyCode)
* [Subscription​Draft.currencyCode](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/SubscriptionDraft#field-SubscriptionDraft.fields.currencyCode)

### Inputs with this enum

* [Draft​Order​Input.presentmentCurrencyCode](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/DraftOrderInput#fields-presentmentCurrencyCode)
* [Market​Currency​Settings​Update​Input.baseCurrency](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/MarketCurrencySettingsUpdateInput#fields-baseCurrency)
* [Money​Input.currencyCode](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/MoneyInput#fields-currencyCode)
* [Order​Capture​Input.currency](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/OrderCaptureInput#fields-currency)
* [Order​Create​Order​Input.currency](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/OrderCreateOrderInput#fields-currency)
* [Order​Create​Order​Input.presentmentCurrency](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/OrderCreateOrderInput#fields-presentmentCurrency)
* [Price​List​Create​Input.currency](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/PriceListCreateInput#fields-currency)
* [Price​List​Update​Input.currency](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/PriceListUpdateInput#fields-currency)
* [Refund​Input.currency](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/RefundInput#fields-currency)
* [Subscription​Contract​Atomic​Create​Input.currencyCode](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/SubscriptionContractAtomicCreateInput#fields-currencyCode)
* [Subscription​Contract​Create​Input.currencyCode](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/SubscriptionContractCreateInput#fields-currencyCode)

### Arguments with this enum

* [Product​Variant.presentmentPrices(presentmentCurrencies)](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/ProductVariant#field-ProductVariant.fields.presentmentPrices.arguments.presentmentCurrencies)
* [Query​Root.cashManagementShopSummary(currencyCode)](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/QueryRoot#field-QueryRoot.fields.cashManagementShopSummary.arguments.currencyCode)
* [shopify​Payments​Payout​Alternate​Currency​Create.currency](https://shopify.dev/docs/api/admin-graphql/2026-04/mutations/shopifyPaymentsPayoutAlternateCurrencyCreate#arguments-currency)
* [cash​Management​Shop​Summary.currencyCode](https://shopify.dev/docs/api/admin-graphql/2026-04/queries/cashManagementShopSummary#arguments-currencyCode)

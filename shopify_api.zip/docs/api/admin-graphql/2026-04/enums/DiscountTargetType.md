---
title: DiscountTargetType - GraphQL Admin
description: >-
  The type of line (line item or shipping line) on an order that the
  subscription discount is applicable towards.
api_version: 2026-04
source_url:
  html: 'https://shopify.dev/docs/api/admin-graphql/2026-04/enums/DiscountTargetType'
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/DiscountTargetType.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Discount​Target​Type

enum

The type of line (line item or shipping line) on an order that the subscription discount is applicable towards.

## Valid values

* LINE\_​ITEM

  The discount applies onto line items.

* SHIPPING\_​LINE

  The discount applies onto shipping lines.

***

## Fields

* [Subscription​Manual​Discount.targetType](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/SubscriptionManualDiscount#field-SubscriptionManualDiscount.fields.targetType)

  OBJECT

  Custom subscription discount.

***

## Map

### Fields with this enum

* [Subscription​Manual​Discount.targetType](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/SubscriptionManualDiscount#field-SubscriptionManualDiscount.fields.targetType)

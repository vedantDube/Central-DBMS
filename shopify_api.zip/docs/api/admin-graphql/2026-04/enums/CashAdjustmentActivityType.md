---
title: CashAdjustmentActivityType - GraphQL Admin
description: The type of adjustment activity.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CashAdjustmentActivityType
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CashAdjustmentActivityType.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Cash​Adjustment​Activity​Type

enum

The type of adjustment activity.

## Valid values

* ADJUSTMENT

  A manual cash adjustment.

* CASH\_​PAYOUT

  A cash payout, such as a gift card cash out.

* CLOSING\_​ADJUSTMENT

  A closing adjustment.

***

## Fields

* [Cash​Adjustment​Activity.type](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CashAdjustmentActivity#field-CashAdjustmentActivity.fields.type)

  OBJECT

  A cash adjustment activity.

***

## Map

### Fields with this enum

* [Cash​Adjustment​Activity.type](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CashAdjustmentActivity#field-CashAdjustmentActivity.fields.type)

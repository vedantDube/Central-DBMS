---
title: FulfillmentOrderMoveFulfillmentOrderMoveUserErrorCode - GraphQL Admin
description: >-
  Possible error codes that can be returned by
  `FulfillmentOrderMoveFulfillmentOrderMoveUserError`.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/FulfillmentOrderMoveFulfillmentOrderMoveUserErrorCode
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/FulfillmentOrderMoveFulfillmentOrderMoveUserErrorCode.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Fulfillment​Order​Move​Fulfillment​Order​Move​User​Error​Code

enum

Possible error codes that can be returned by `FulfillmentOrderMoveFulfillmentOrderMoveUserError`.

## Valid values

* CANNOT\_​MOVE\_​FULFILLMENT\_​ORDER\_​WITH\_​REPORTED\_​PROGRESS

  Cannot move a fulfillment order that has progress reported.

***

## Fields

* [Fulfillment​Order​Move​Fulfillment​Order​Move​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/FulfillmentOrderMoveFulfillmentOrderMoveUserError#field-FulfillmentOrderMoveFulfillmentOrderMoveUserError.fields.code)

  OBJECT

  Represents a user error that occurs while moving a fulfillment order.

***

## Map

### Fields with this enum

* [Fulfillment​Order​Move​Fulfillment​Order​Move​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/FulfillmentOrderMoveFulfillmentOrderMoveUserError#field-FulfillmentOrderMoveFulfillmentOrderMoveUserError.fields.code)

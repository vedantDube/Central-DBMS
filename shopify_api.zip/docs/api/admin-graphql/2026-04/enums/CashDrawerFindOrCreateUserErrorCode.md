---
title: CashDrawerFindOrCreateUserErrorCode - GraphQL Admin
description: >-
  Possible error codes that can be returned by
  `CashDrawerFindOrCreateUserError`.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CashDrawerFindOrCreateUserErrorCode
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CashDrawerFindOrCreateUserErrorCode.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Cash​Drawer​Find​Or​Create​User​Error​Code

enum

Possible error codes that can be returned by `CashDrawerFindOrCreateUserError`.

## Valid values

* CASH\_​DRAWER\_​ASSIGNMENT\_​ALREADY\_​EXISTS

  The cash drawer assignment already exists.

* INTERNAL\_​ERROR

  Unexpected internal error happened.

* LOCATION\_​NOT\_​FOUND

  The location was not found.

* NOT\_​SAVED

  Failed to find or create cash drawer.

* POINT\_​OF\_​SALE\_​DEVICE\_​NOT\_​FOUND

  The point of sale device was not found.

***

## Fields

* [Cash​Drawer​Find​Or​Create​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CashDrawerFindOrCreateUserError#field-CashDrawerFindOrCreateUserError.fields.code)

  OBJECT

  An error that occurs during the execution of `CashDrawerFindOrCreate`.

***

## Map

### Fields with this enum

* [Cash​Drawer​Find​Or​Create​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CashDrawerFindOrCreateUserError#field-CashDrawerFindOrCreateUserError.fields.code)

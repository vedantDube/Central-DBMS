---
title: CustomerSmsMarketingConsentErrorCode - GraphQL Admin
description: >-
  Possible error codes that can be returned by
  `CustomerSmsMarketingConsentError`.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CustomerSmsMarketingConsentErrorCode
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CustomerSmsMarketingConsentErrorCode.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Customer​Sms​Marketing​Consent​Error​Code

enum

Possible error codes that can be returned by `CustomerSmsMarketingConsentError`.

## Valid values

* INCLUSION

  The input value isn't included in the list.

* INTERNAL\_​ERROR

  Unexpected internal error happened.

* INVALID

  The input value is invalid.

* MISSING\_​ARGUMENT

  Missing a required argument.

***

## Fields

* [Customer​Sms​Marketing​Consent​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CustomerSmsMarketingConsentError#field-CustomerSmsMarketingConsentError.fields.code)

  OBJECT

  An error that occurs during execution of an SMS marketing consent mutation.

***

## Map

### Fields with this enum

* [Customer​Sms​Marketing​Consent​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CustomerSmsMarketingConsentError#field-CustomerSmsMarketingConsentError.fields.code)

---
title: CustomerAccountNativePagePageType - GraphQL Admin
description: The type of customer account native page.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CustomerAccountNativePagePageType
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CustomerAccountNativePagePageType.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Customer​Account​Native​Page​Page​Type

enum

The type of customer account native page.

## Valid values

* NATIVE\_​ORDERS

  An orders page type.

* NATIVE\_​PROFILE

  A profile page type.

* NATIVE\_​SETTINGS

  A settings page type.

* UNKNOWN

  An unknown page type. Represents new page types that may be added in future versions.

***

## Fields

* [Customer​Account​Native​Page.pageType](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CustomerAccountNativePage#field-CustomerAccountNativePage.fields.pageType)

  OBJECT

  A native page for the customer account navigation menu.

***

## Map

### Fields with this enum

* [Customer​Account​Native​Page.pageType](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CustomerAccountNativePage#field-CustomerAccountNativePage.fields.pageType)

---
title: ChannelUpdateUserErrorCode - GraphQL Admin
description: Possible error codes that can be returned by `ChannelUpdateUserError`.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/ChannelUpdateUserErrorCode
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/ChannelUpdateUserErrorCode.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Channel​Update​User​Error​Code

enum

Possible error codes that can be returned by `ChannelUpdateUserError`.

## Valid values

* INVALID

  The input value is invalid.

* NOT\_​FOUND

  The record with the ID used as the input value couldn't be found.

***

## Fields

* [Channel​Update​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/ChannelUpdateUserError#field-ChannelUpdateUserError.fields.code)

  OBJECT

  An error that occurs during the execution of `ChannelUpdate`.

***

## Map

### Fields with this enum

* [Channel​Update​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/ChannelUpdateUserError#field-ChannelUpdateUserError.fields.code)

---
title: DeliveryPromiseParticipantOwnerType - GraphQL Admin
description: The type of object that the participant is attached to.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/DeliveryPromiseParticipantOwnerType
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/DeliveryPromiseParticipantOwnerType.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Delivery​Promise​Participant​Owner​Type

enum

The type of object that the participant is attached to.

## Valid values

* PRODUCTVARIANT

  A product variant.

***

## Fields

* [Delivery​Promise​Participant.ownerType](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/DeliveryPromiseParticipant#field-DeliveryPromiseParticipant.fields.ownerType)

  OBJECT

  Returns enabled delivery promise participants.

***

## Map

### Fields with this enum

* [Delivery​Promise​Participant.ownerType](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/DeliveryPromiseParticipant#field-DeliveryPromiseParticipant.fields.ownerType)

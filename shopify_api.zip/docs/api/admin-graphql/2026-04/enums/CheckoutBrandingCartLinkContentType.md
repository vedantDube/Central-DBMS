---
title: CheckoutBrandingCartLinkContentType - GraphQL Admin
description: Possible values for the cart link content type for the header.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutBrandingCartLinkContentType
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutBrandingCartLinkContentType.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Checkout​Branding​Cart​Link​Content​Type

enum

Possible values for the cart link content type for the header.

## Valid values

* ICON

  The checkout header content type icon value.

* IMAGE

  The checkout header content type image value.

* TEXT

  The checkout header content type text value.

***

## Fields

* [Checkout​Branding​Header​Cart​Link.contentType](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutBrandingHeaderCartLink#field-CheckoutBrandingHeaderCartLink.fields.contentType)

  OBJECT

  The header cart link customizations.

* [Checkout​Branding​Header​Cart​Link​Input.contentType](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutBrandingHeaderCartLinkInput#fields-contentType)

  INPUT OBJECT

  The input fields for header cart link customizations.

***

## Map

### Fields with this enum

* [Checkout​Branding​Header​Cart​Link.contentType](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutBrandingHeaderCartLink#field-CheckoutBrandingHeaderCartLink.fields.contentType)

### Inputs with this enum

* [Checkout​Branding​Header​Cart​Link​Input.contentType](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutBrandingHeaderCartLinkInput#fields-contentType)

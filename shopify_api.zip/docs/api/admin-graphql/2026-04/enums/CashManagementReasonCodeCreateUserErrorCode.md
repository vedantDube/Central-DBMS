---
title: CashManagementReasonCodeCreateUserErrorCode - GraphQL Admin
description: >-
  Possible error codes that can be returned by
  `CashManagementReasonCodeCreateUserError`.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CashManagementReasonCodeCreateUserErrorCode
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CashManagementReasonCodeCreateUserErrorCode.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Cash​Management​Reason​Code​Create​User​Error​Code

enum

Possible error codes that can be returned by `CashManagementReasonCodeCreateUserError`.

## Valid values

* BLANK

  The input value is blank.

* CODE\_​ALREADY\_​EXISTS

  The reason code already exists.

* NOT\_​SAVED

  Failed to create cash management reason code.

***

## Fields

* [Cash​Management​Reason​Code​Create​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CashManagementReasonCodeCreateUserError#field-CashManagementReasonCodeCreateUserError.fields.code)

  OBJECT

  An error that occurs during the execution of `CashManagementReasonCodeCreate`.

***

## Map

### Fields with this enum

* [Cash​Management​Reason​Code​Create​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CashManagementReasonCodeCreateUserError#field-CashManagementReasonCodeCreateUserError.fields.code)

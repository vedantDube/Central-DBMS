---
title: CartTransformCreateUserErrorCode - GraphQL Admin
description: Possible error codes that can be returned by `CartTransformCreateUserError`.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CartTransformCreateUserErrorCode
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CartTransformCreateUserErrorCode.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Cart​Transform​Create​User​Error​Code

enum

Possible error codes that can be returned by `CartTransformCreateUserError`.

## Valid values

* CUSTOM\_​APP\_​FUNCTION\_​NOT\_​ELIGIBLE

  Shop must be on a Shopify Plus plan to activate functions from a custom app.

* FUNCTION\_​ALREADY\_​REGISTERED

  A cart transform function already exists for the provided function\_id.

* FUNCTION\_​DOES\_​NOT\_​IMPLEMENT

  Function does not implement the required interface for this cart\_transform function.

* FUNCTION\_​NOT\_​FOUND

  No Shopify Function found for provided function\_id.

* INPUT\_​INVALID

  Failed to create cart transform due to invalid input.

* INVALID\_​METAFIELDS

  Could not create or update metafields.

* MAXIMUM\_​CART\_​TRANSFORMS

  The maximum number of cart transforms per shop has been reached.

* MISSING\_​FUNCTION\_​IDENTIFIER

  Either function\_id or function\_handle must be provided.

* MULTIPLE\_​FUNCTION\_​IDENTIFIERS

  Only one of function\_id or function\_handle can be provided, not both.

***

## Fields

* [Cart​Transform​Create​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CartTransformCreateUserError#field-CartTransformCreateUserError.fields.code)

  OBJECT

  An error that occurs during the execution of `CartTransformCreate`.

***

## Map

### Fields with this enum

* [Cart​Transform​Create​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CartTransformCreateUserError#field-CartTransformCreateUserError.fields.code)

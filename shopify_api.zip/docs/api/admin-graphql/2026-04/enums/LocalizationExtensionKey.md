---
title: LocalizationExtensionKey - GraphQL Admin
description: The key of a localization extension.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/LocalizationExtensionKey
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/LocalizationExtensionKey.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Localization​Extension​Key

enum

The key of a localization extension.

## Valid values

* SHIPPING\_​CREDENTIAL\_​BR

  Extension key 'shipping\_credential\_br' for country BR.

* SHIPPING\_​CREDENTIAL\_​CL

  Extension key 'shipping\_credential\_cl' for country CL.

* SHIPPING\_​CREDENTIAL\_​CN

  Extension key 'shipping\_credential\_cn' for country CN.

* SHIPPING\_​CREDENTIAL\_​CO

  Extension key 'shipping\_credential\_co' for country CO.

* SHIPPING\_​CREDENTIAL\_​CR

  Extension key 'shipping\_credential\_cr' for country CR.

* SHIPPING\_​CREDENTIAL\_​EC

  Extension key 'shipping\_credential\_ec' for country EC.

* SHIPPING\_​CREDENTIAL\_​ES

  Extension key 'shipping\_credential\_es' for country ES.

* SHIPPING\_​CREDENTIAL\_​GT

  Extension key 'shipping\_credential\_gt' for country GT.

* SHIPPING\_​CREDENTIAL\_​ID

  Extension key 'shipping\_credential\_id' for country ID.

* SHIPPING\_​CREDENTIAL\_​KR

  Extension key 'shipping\_credential\_kr' for country KR.

* SHIPPING\_​CREDENTIAL\_​MX

  Extension key 'shipping\_credential\_mx' for country MX.

* SHIPPING\_​CREDENTIAL\_​MY

  Extension key 'shipping\_credential\_my' for country MY.

* SHIPPING\_​CREDENTIAL\_​PE

  Extension key 'shipping\_credential\_pe' for country PE.

* SHIPPING\_​CREDENTIAL\_​PT

  Extension key 'shipping\_credential\_pt' for country PT.

* SHIPPING\_​CREDENTIAL\_​PY

  Extension key 'shipping\_credential\_py' for country PY.

* SHIPPING\_​CREDENTIAL\_​TR

  Extension key 'shipping\_credential\_tr' for country TR.

* SHIPPING\_​CREDENTIAL\_​TW

  Extension key 'shipping\_credential\_tw' for country TW.

* SHIPPING\_​CREDENTIAL\_​TYPE\_​CO

  Extension key 'shipping\_credential\_type\_co' for country CO.

* TAX\_​CREDENTIAL\_​BR

  Extension key 'tax\_credential\_br' for country BR.

* TAX\_​CREDENTIAL\_​CL

  Extension key 'tax\_credential\_cl' for country CL.

* TAX\_​CREDENTIAL\_​CO

  Extension key 'tax\_credential\_co' for country CO.

* TAX\_​CREDENTIAL\_​CR

  Extension key 'tax\_credential\_cr' for country CR.

* TAX\_​CREDENTIAL\_​EC

  Extension key 'tax\_credential\_ec' for country EC.

* TAX\_​CREDENTIAL\_​ES

  Extension key 'tax\_credential\_es' for country ES.

* TAX\_​CREDENTIAL\_​GT

  Extension key 'tax\_credential\_gt' for country GT.

* TAX\_​CREDENTIAL\_​ID

  Extension key 'tax\_credential\_id' for country ID.

* TAX\_​CREDENTIAL\_​IT

  Extension key 'tax\_credential\_it' for country IT.

* TAX\_​CREDENTIAL\_​MX

  Extension key 'tax\_credential\_mx' for country MX.

* TAX\_​CREDENTIAL\_​MY

  Extension key 'tax\_credential\_my' for country MY.

* TAX\_​CREDENTIAL\_​PE

  Extension key 'tax\_credential\_pe' for country PE.

* TAX\_​CREDENTIAL\_​PT

  Extension key 'tax\_credential\_pt' for country PT.

* TAX\_​CREDENTIAL\_​PY

  Extension key 'tax\_credential\_py' for country PY.

* TAX\_​CREDENTIAL\_​TR

  Extension key 'tax\_credential\_tr' for country TR.

* TAX\_​CREDENTIAL\_​TYPE\_​CO

  Extension key 'tax\_credential\_type\_co' for country CO.

* TAX\_​CREDENTIAL\_​TYPE\_​MX

  Extension key 'tax\_credential\_type\_mx' for country MX.

* TAX\_​CREDENTIAL\_​USE\_​MX

  Extension key 'tax\_credential\_use\_mx' for country MX.

* TAX\_​EMAIL\_​IT

  Extension key 'tax\_email\_it' for country IT.

***

## Fields

* [Localization​Extension.key](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/LocalizationExtension#field-LocalizationExtension.fields.key)

  OBJECT

  Represents the value captured by a localization extension. Localization extensions are additional fields required by certain countries on international orders. For example, some countries require additional fields for customs information or tax identification numbers.

* [Localization​Extension​Input.key](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/LocalizationExtensionInput#fields-key)

  INPUT OBJECT

  The input fields for a LocalizationExtensionInput.

***

## Map

### Fields with this enum

* [Localization​Extension.key](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/LocalizationExtension#field-LocalizationExtension.fields.key)

### Inputs with this enum

* [Localization​Extension​Input.key](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/LocalizationExtensionInput#fields-key)

---
title: CommentStatus - GraphQL Admin
description: The status of a comment.
api_version: 2026-04
source_url:
  html: 'https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CommentStatus'
  md: 'https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CommentStatus.md'
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Comment​Status

enum

The status of a comment.

## Valid values

* PENDING

  The comment is pending approval.

* PUBLISHED

  The comment is published.

* REMOVED

  The comment has been removed.

* SPAM

  The comment is marked as spam.

* UNAPPROVED

  The comment is unapproved.

***

## Fields

* [Comment.status](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/Comment#field-Comment.fields.status)

  OBJECT

  A comment on an article.

***

## Map

### Fields with this enum

* [Comment.status](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/Comment#field-Comment.fields.status)

---
title: CarrierServiceUpdateUserErrorCode - GraphQL Admin
description: Possible error codes that can be returned by `CarrierServiceUpdateUserError`.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CarrierServiceUpdateUserErrorCode
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CarrierServiceUpdateUserErrorCode.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Carrier​Service​Update​User​Error​Code

enum

Possible error codes that can be returned by `CarrierServiceUpdateUserError`.

## Valid values

* CARRIER\_​SERVICE\_​UPDATE\_​FAILED

  Carrier service update failed.

***

## Fields

* [Carrier​Service​Update​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CarrierServiceUpdateUserError#field-CarrierServiceUpdateUserError.fields.code)

  OBJECT

  An error that occurs during the execution of `CarrierServiceUpdate`.

***

## Map

### Fields with this enum

* [Carrier​Service​Update​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CarrierServiceUpdateUserError#field-CarrierServiceUpdateUserError.fields.code)

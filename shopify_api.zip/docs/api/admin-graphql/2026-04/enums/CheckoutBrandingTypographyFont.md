---
title: CheckoutBrandingTypographyFont - GraphQL Admin
description: The font selection.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutBrandingTypographyFont
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutBrandingTypographyFont.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Checkout​Branding​Typography​Font

enum

The font selection.

## Valid values

* PRIMARY

  The primary font.

* SECONDARY

  The secondary font.

***

## Fields

* [Checkout​Branding​Typography​Style.font](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutBrandingTypographyStyle#field-CheckoutBrandingTypographyStyle.fields.font)

  OBJECT

  The typography customizations.

* [Checkout​Branding​Typography​Style​Input.font](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutBrandingTypographyStyleInput#fields-font)

  INPUT OBJECT

  The input fields used to update the typography customizations.

***

## Map

### Fields with this enum

* [Checkout​Branding​Typography​Style.font](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutBrandingTypographyStyle#field-CheckoutBrandingTypographyStyle.fields.font)

### Inputs with this enum

* [Checkout​Branding​Typography​Style​Input.font](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutBrandingTypographyStyleInput#fields-font)

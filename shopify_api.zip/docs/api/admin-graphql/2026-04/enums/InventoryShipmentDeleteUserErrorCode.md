---
title: InventoryShipmentDeleteUserErrorCode - GraphQL Admin
description: >-
  Possible error codes that can be returned by
  `InventoryShipmentDeleteUserError`.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/InventoryShipmentDeleteUserErrorCode
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/InventoryShipmentDeleteUserErrorCode.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Inventory​Shipment​Delete​User​Error​Code

enum

Possible error codes that can be returned by `InventoryShipmentDeleteUserError`.

## Valid values

* INVALID\_​SHIPMENT\_​STATUS

  Current shipment status does not support this operation.

* SHIPMENT\_​NOT\_​FOUND

  The shipment was not found.

***

## Fields

* [Inventory​Shipment​Delete​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/InventoryShipmentDeleteUserError#field-InventoryShipmentDeleteUserError.fields.code)

  OBJECT

  An error that occurs during the execution of `InventoryShipmentDelete`.

***

## Map

### Fields with this enum

* [Inventory​Shipment​Delete​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/InventoryShipmentDeleteUserError#field-InventoryShipmentDeleteUserError.fields.code)

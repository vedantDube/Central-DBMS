---
title: DeletionEventSortKeys - GraphQL Admin
description: The set of valid sort keys for the DeletionEvent query.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/DeletionEventSortKeys
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/DeletionEventSortKeys.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Deletion​Event​Sort​Keys

enum

The set of valid sort keys for the DeletionEvent query.

## Valid values

* CREATED\_​AT

  Sort by the `created_at` value.

* ID

  Sort by the `id` value.

***

## Fields

* [Query​Root.deletionEvents(sortKey)](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/QueryRoot#field-QueryRoot.fields.deletionEvents.arguments.sortKey)

  ARGUMENT

  The schema's entry-point for queries. This acts as the public, top-level API from which all queries must start.

* [deletion​Events.sortKey](https://shopify.dev/docs/api/admin-graphql/2026-04/queries/deletionEvents#arguments-sortKey)

  ARGUMENT

***

## Map

### Arguments with this enum

* [Query​Root.deletionEvents(sortKey)](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/QueryRoot#field-QueryRoot.fields.deletionEvents.arguments.sortKey)
* [deletion​Events.sortKey](https://shopify.dev/docs/api/admin-graphql/2026-04/queries/deletionEvents#arguments-sortKey)

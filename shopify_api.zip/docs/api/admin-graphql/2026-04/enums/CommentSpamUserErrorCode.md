---
title: CommentSpamUserErrorCode - GraphQL Admin
description: Possible error codes that can be returned by `CommentSpamUserError`.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CommentSpamUserErrorCode
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CommentSpamUserErrorCode.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Comment​Spam​User​Error​Code

enum

Possible error codes that can be returned by `CommentSpamUserError`.

## Valid values

* NOT\_​FOUND

  The record with the ID used as the input value couldn't be found.

***

## Fields

* [Comment​Spam​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CommentSpamUserError#field-CommentSpamUserError.fields.code)

  OBJECT

  An error that occurs during the execution of `CommentSpam`.

***

## Map

### Fields with this enum

* [Comment​Spam​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CommentSpamUserError#field-CommentSpamUserError.fields.code)

---
title: CheckoutAndAccountsConfigurationBrandingTypographyWeight - GraphQL Admin
description: Possible values for the font weight.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutAndAccountsConfigurationBrandingTypographyWeight
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutAndAccountsConfigurationBrandingTypographyWeight.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Checkout​And​Accounts​Configuration​Branding​Typography​Weight

enum

Possible values for the font weight.

## Valid values

* BASE

  The base weight.

* BOLD

  The bold weight.

***

## Fields

* [Checkout​And​Accounts​Configuration​Branding​Typography​Style.weight](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingTypographyStyle#field-CheckoutAndAccountsConfigurationBrandingTypographyStyle.fields.weight)

  OBJECT

  The typography customizations.

* [Checkout​And​Accounts​Configuration​Branding​Typography​Style​Input.weight](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingTypographyStyleInput#fields-weight)

  INPUT OBJECT

  The input fields for customizing the typography.

***

## Map

### Fields with this enum

* [Checkout​And​Accounts​Configuration​Branding​Typography​Style.weight](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingTypographyStyle#field-CheckoutAndAccountsConfigurationBrandingTypographyStyle.fields.weight)

### Inputs with this enum

* [Checkout​And​Accounts​Configuration​Branding​Typography​Style​Input.weight](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingTypographyStyleInput#fields-weight)

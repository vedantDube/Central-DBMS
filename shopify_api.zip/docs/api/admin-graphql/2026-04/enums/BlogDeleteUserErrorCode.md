---
title: BlogDeleteUserErrorCode - GraphQL Admin
description: Possible error codes that can be returned by `BlogDeleteUserError`.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/BlogDeleteUserErrorCode
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/BlogDeleteUserErrorCode.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Blog​Delete​User​Error​Code

enum

Possible error codes that can be returned by `BlogDeleteUserError`.

## Valid values

* NOT\_​FOUND

  The record with the ID used as the input value couldn't be found.

***

## Fields

* [Blog​Delete​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/BlogDeleteUserError#field-BlogDeleteUserError.fields.code)

  OBJECT

  An error that occurs during the execution of `BlogDelete`.

***

## Map

### Fields with this enum

* [Blog​Delete​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/BlogDeleteUserError#field-BlogDeleteUserError.fields.code)

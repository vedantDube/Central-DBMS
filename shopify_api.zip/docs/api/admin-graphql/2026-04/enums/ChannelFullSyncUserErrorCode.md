---
title: ChannelFullSyncUserErrorCode - GraphQL Admin
description: Possible error codes that can be returned by `ChannelFullSyncUserError`.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/ChannelFullSyncUserErrorCode
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/ChannelFullSyncUserErrorCode.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Channel​Full​Sync​User​Error​Code

enum

Possible error codes that can be returned by `ChannelFullSyncUserError`.

## Valid values

* INVALID

  The input value is invalid.

* NOT\_​FOUND

  The record with the ID used as the input value couldn't be found.

***

## Fields

* [Channel​Full​Sync​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/ChannelFullSyncUserError#field-ChannelFullSyncUserError.fields.code)

  OBJECT

  An error that occurs during the execution of `ChannelFullSync`.

***

## Map

### Fields with this enum

* [Channel​Full​Sync​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/ChannelFullSyncUserError#field-ChannelFullSyncUserError.fields.code)

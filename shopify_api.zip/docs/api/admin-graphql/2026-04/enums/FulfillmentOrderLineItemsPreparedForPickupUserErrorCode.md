---
title: FulfillmentOrderLineItemsPreparedForPickupUserErrorCode - GraphQL Admin
description: >-
  Possible error codes that can be returned by
  `FulfillmentOrderLineItemsPreparedForPickupUserError`.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/FulfillmentOrderLineItemsPreparedForPickupUserErrorCode
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/FulfillmentOrderLineItemsPreparedForPickupUserErrorCode.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Fulfillment​Order​Line​Items​Prepared​For​Pickup​User​Error​Code

enum

Possible error codes that can be returned by `FulfillmentOrderLineItemsPreparedForPickupUserError`.

## Valid values

* FULFILLMENT\_​ORDER\_​INVALID

  Invalid fulfillment order ID provided.

* NO\_​LINE\_​ITEMS\_​TO\_​PREPARE\_​FOR\_​FULFILLMENT\_​ORDER

  The fulfillment order does not have any line items that can be prepared.

* UNABLE\_​TO\_​PREPARE\_​QUANTITY

  Unable to prepare quantity.

***

## Fields

* [Fulfillment​Order​Line​Items​Prepared​For​Pickup​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/FulfillmentOrderLineItemsPreparedForPickupUserError#field-FulfillmentOrderLineItemsPreparedForPickupUserError.fields.code)

  OBJECT

  An error that occurs during the execution of `FulfillmentOrderLineItemsPreparedForPickup`.

***

## Map

### Fields with this enum

* [Fulfillment​Order​Line​Items​Prepared​For​Pickup​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/FulfillmentOrderLineItemsPreparedForPickupUserError#field-FulfillmentOrderLineItemsPreparedForPickupUserError.fields.code)

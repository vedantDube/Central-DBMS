---
title: CashCountActivityType - GraphQL Admin
description: The type of count activity.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CashCountActivityType
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CashCountActivityType.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Cash​Count​Activity​Type

enum

The type of count activity.

## Valid values

* CLOSING

  A count performed at the closing of a session.

* MID\_​SESSION

  A count performed during a session.

* OPENING

  A count performed at the opening of a session.

***

## Fields

* [Cash​Count​Activity.type](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CashCountActivity#field-CashCountActivity.fields.type)

  OBJECT

  A cash count activity.

***

## Map

### Fields with this enum

* [Cash​Count​Activity.type](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CashCountActivity#field-CashCountActivity.fields.type)

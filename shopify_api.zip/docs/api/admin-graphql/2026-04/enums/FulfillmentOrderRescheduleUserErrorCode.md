---
title: FulfillmentOrderRescheduleUserErrorCode - GraphQL Admin
description: >-
  Possible error codes that can be returned by
  `FulfillmentOrderRescheduleUserError`.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/FulfillmentOrderRescheduleUserErrorCode
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/FulfillmentOrderRescheduleUserErrorCode.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Fulfillment​Order​Reschedule​User​Error​Code

enum

Possible error codes that can be returned by `FulfillmentOrderRescheduleUserError`.

## Valid values

* FULFILLMENT\_​ORDER\_​NOT\_​FOUND

  Fulfillment order could not be found.

***

## Fields

* [Fulfillment​Order​Reschedule​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/FulfillmentOrderRescheduleUserError#field-FulfillmentOrderRescheduleUserError.fields.code)

  OBJECT

  An error that occurs during the execution of `FulfillmentOrderReschedule`.

***

## Map

### Fields with this enum

* [Fulfillment​Order​Reschedule​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/FulfillmentOrderRescheduleUserError#field-FulfillmentOrderRescheduleUserError.fields.code)

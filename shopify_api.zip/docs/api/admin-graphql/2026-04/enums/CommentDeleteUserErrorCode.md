---
title: CommentDeleteUserErrorCode - GraphQL Admin
description: Possible error codes that can be returned by `CommentDeleteUserError`.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CommentDeleteUserErrorCode
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CommentDeleteUserErrorCode.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Comment​Delete​User​Error​Code

enum

Possible error codes that can be returned by `CommentDeleteUserError`.

## Valid values

* NOT\_​FOUND

  The record with the ID used as the input value couldn't be found.

***

## Fields

* [Comment​Delete​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CommentDeleteUserError#field-CommentDeleteUserError.fields.code)

  OBJECT

  An error that occurs during the execution of `CommentDelete`.

***

## Map

### Fields with this enum

* [Comment​Delete​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CommentDeleteUserError#field-CommentDeleteUserError.fields.code)

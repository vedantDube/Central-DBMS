---
title: CheckoutAndAccountsConfigurationBrandingTypographyFont - GraphQL Admin
description: The font selection.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutAndAccountsConfigurationBrandingTypographyFont
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutAndAccountsConfigurationBrandingTypographyFont.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Checkout​And​Accounts​Configuration​Branding​Typography​Font

enum

The font selection.

## Valid values

* PRIMARY

  The primary font.

* SECONDARY

  The secondary font.

***

## Fields

* [Checkout​And​Accounts​Configuration​Branding​Typography​Style.font](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingTypographyStyle#field-CheckoutAndAccountsConfigurationBrandingTypographyStyle.fields.font)

  OBJECT

  The typography customizations.

* [Checkout​And​Accounts​Configuration​Branding​Typography​Style​Input.font](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingTypographyStyleInput#fields-font)

  INPUT OBJECT

  The input fields for customizing the typography.

***

## Map

### Fields with this enum

* [Checkout​And​Accounts​Configuration​Branding​Typography​Style.font](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingTypographyStyle#field-CheckoutAndAccountsConfigurationBrandingTypographyStyle.fields.font)

### Inputs with this enum

* [Checkout​And​Accounts​Configuration​Branding​Typography​Style​Input.font](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingTypographyStyleInput#fields-font)

---
title: FulfillmentServiceType - GraphQL Admin
description: The type of a fulfillment service.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/FulfillmentServiceType
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/FulfillmentServiceType.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Fulfillment​Service​Type

enum

The type of a fulfillment service.

## Valid values

* GIFT\_​CARD

  Fulfillment by gift card.

* MANUAL

  Manual fulfillment by the merchant.

* THIRD\_​PARTY

  Fullfillment by a third-party fulfillment service.

***

## Fields

* [Fulfillment​Service.type](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/FulfillmentService#field-FulfillmentService.fields.type)

  OBJECT

  A **Fulfillment Service** is a third party warehouse that prepares and ships orders on behalf of the store owner. Fulfillment services charge a fee to package and ship items and update product inventory levels. Some well known fulfillment services with Shopify integrations include: Amazon, Shipwire, and Rakuten. When an app registers a new `FulfillmentService` on a store, Shopify automatically creates a `Location` that's associated to the fulfillment service. To learn more about fulfillment services, refer to [Manage fulfillments as a fulfillment service app](https://shopify.dev/apps/fulfillment/fulfillment-service-apps) guide.

  ## Mutations

  You can work with the `FulfillmentService` object with the [fulfillmentServiceCreate](https://shopify.dev/api/admin-graphql/latest/mutations/fulfillmentServiceCreate), [fulfillmentServiceUpdate](https://shopify.dev/api/admin-graphql/latest/mutations/fulfillmentServiceUpdate), and [fulfillmentServiceDelete](https://shopify.dev/api/admin-graphql/latest/mutations/fulfillmentServiceDelete) mutations.

  ## Hosted endpoints

  Fulfillment service providers integrate with Shopify by providing Shopify with a set of hosted endpoints that Shopify can query on certain conditions. These endpoints must have a common prefix, and this prefix should be supplied in the `callbackUrl` parameter in the [fulfillmentServiceCreate](https://shopify.dev/api/admin-graphql/latest/mutations/fulfillmentServiceCreate) mutation.

  * Shopify sends POST requests to the `<callbackUrl>/fulfillment_order_notification` endpoint to notify the fulfillment service about fulfillment requests and fulfillment cancellation requests.

  For more information, refer to [Receive fulfillment requests and cancellations](https://shopify.dev/apps/fulfillment/fulfillment-service-apps/manage-fulfillments#step-2-receive-fulfillment-requests-and-cancellations).

  * Shopify sends GET requests to the `<callbackUrl>/fetch_tracking_numbers` endpoint to retrieve tracking numbers for orders if `trackingSupport` is set to `true`.

  For more information, refer to [Enable tracking support](https://shopify.dev/apps/fulfillment/fulfillment-service-apps/manage-fulfillments#step-8-enable-tracking-support-optional).

  Fulfillment services can also update tracking information using the [fulfillmentTrackingInfoUpdate](https://shopify.dev/api/admin-graphql/latest/mutations/fulfillmentTrackingInfoUpdate) mutation, rather than waiting for Shopify to ask for tracking numbers.

  * Shopify sends GET requests to the `<callbackUrl>/fetch_stock` endpoint to retrieve on hand inventory levels for the fulfillment service location if `inventoryManagement` is set to `true`.

  For more information, refer to [Sharing inventory levels with Shopify](https://shopify.dev/apps/build/orders-fulfillment/fulfillment-service-apps/build-for-fulfillment-services#step-10-optional-share-inventory-levels-with-shopify).

  To make sure you have everything set up correctly, you can test the `callbackUrl`-prefixed endpoints in your development store.

  ## Resources and webhooks

  There are a variety of objects and webhooks that enable a fulfillment service to work. To exchange fulfillment information with Shopify, fulfillment services use the [FulfillmentOrder](https://shopify.dev/api/admin-graphql/latest/objects/FulfillmentOrder), [Fulfillment](https://shopify.dev/api/admin-graphql/latest/objects/Fulfillment) and [Order](https://shopify.dev/api/admin-graphql/latest/objects/Order) objects and related mutations. To act on fulfillment process events that happen on the Shopify side, besides awaiting calls to `callbackUrl`-prefixed endpoints, fulfillment services can subscribe to the [fulfillment order](https://shopify.dev/apps/fulfillment/fulfillment-service-apps/manage-fulfillments#webhooks) and [order](https://shopify.dev/api/admin-rest/latest/resources/webhook) webhooks.

***

## Map

### Fields with this enum

* [Fulfillment​Service.type](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/FulfillmentService#field-FulfillmentService.fields.type)

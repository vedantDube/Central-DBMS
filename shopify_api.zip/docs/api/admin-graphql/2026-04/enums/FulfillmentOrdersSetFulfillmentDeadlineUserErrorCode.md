---
title: FulfillmentOrdersSetFulfillmentDeadlineUserErrorCode - GraphQL Admin
description: >-
  Possible error codes that can be returned by
  `FulfillmentOrdersSetFulfillmentDeadlineUserError`.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/FulfillmentOrdersSetFulfillmentDeadlineUserErrorCode
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/FulfillmentOrdersSetFulfillmentDeadlineUserErrorCode.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Fulfillment​Orders​Set​Fulfillment​Deadline​User​Error​Code

enum

Possible error codes that can be returned by `FulfillmentOrdersSetFulfillmentDeadlineUserError`.

## Valid values

* FULFILLMENT\_​ORDERS\_​NOT\_​FOUND

  The fulfillment orders could not be found.

***

## Fields

* [Fulfillment​Orders​Set​Fulfillment​Deadline​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/FulfillmentOrdersSetFulfillmentDeadlineUserError#field-FulfillmentOrdersSetFulfillmentDeadlineUserError.fields.code)

  OBJECT

  An error that occurs during the execution of `FulfillmentOrdersSetFulfillmentDeadline`.

***

## Map

### Fields with this enum

* [Fulfillment​Orders​Set​Fulfillment​Deadline​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/FulfillmentOrdersSetFulfillmentDeadlineUserError#field-FulfillmentOrdersSetFulfillmentDeadlineUserError.fields.code)

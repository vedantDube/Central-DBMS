---
title: CheckoutAndAccountsConfigurationBrandingSharedCornerRadius - GraphQL Admin
description: >-
  Possible choices to override corner radius customizations on all applicable

  objects. Note that this selection can only be used to set the override to
  `NONE` (0px).
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutAndAccountsConfigurationBrandingSharedCornerRadius
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutAndAccountsConfigurationBrandingSharedCornerRadius.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Checkout​And​Accounts​Configuration​Branding​Shared​Corner​Radius

enum

Possible choices to override corner radius customizations on all applicable objects. Note that this selection can only be used to set the override to `NONE` (0px).

## Valid values

* NONE

  Set the shared corner radius override to 0px (square corners).

***

## Fields

* [Checkout​And​Accounts​Configuration​Branding​Shared.cornerRadius](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingShared#field-CheckoutAndAccountsConfigurationBrandingShared.fields.cornerRadius)

  OBJECT

  The shared customizations.

* [Checkout​And​Accounts​Configuration​Branding​Shared​Input.cornerRadius](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingSharedInput#fields-cornerRadius)

  INPUT OBJECT

  The input fields for customizing the shared settings.

***

## Map

### Fields with this enum

* [Checkout​And​Accounts​Configuration​Branding​Shared.cornerRadius](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingShared#field-CheckoutAndAccountsConfigurationBrandingShared.fields.cornerRadius)

### Inputs with this enum

* [Checkout​And​Accounts​Configuration​Branding​Shared​Input.cornerRadius](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingSharedInput#fields-cornerRadius)

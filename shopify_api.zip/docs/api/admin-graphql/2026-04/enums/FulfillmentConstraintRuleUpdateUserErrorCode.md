---
title: FulfillmentConstraintRuleUpdateUserErrorCode - GraphQL Admin
description: >-
  Possible error codes that can be returned by
  `FulfillmentConstraintRuleUpdateUserError`.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/FulfillmentConstraintRuleUpdateUserErrorCode
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/FulfillmentConstraintRuleUpdateUserErrorCode.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Fulfillment​Constraint​Rule​Update​User​Error​Code

enum

Possible error codes that can be returned by `FulfillmentConstraintRuleUpdateUserError`.

## Valid values

* NOT\_​FOUND

  Could not find fulfillment constraint rule for provided id.

* UNAUTHORIZED\_​APP\_​SCOPE

  Unauthorized app scope.

***

## Fields

* [Fulfillment​Constraint​Rule​Update​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/FulfillmentConstraintRuleUpdateUserError#field-FulfillmentConstraintRuleUpdateUserError.fields.code)

  OBJECT

  An error that occurs during the execution of `FulfillmentConstraintRuleUpdate`.

***

## Map

### Fields with this enum

* [Fulfillment​Constraint​Rule​Update​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/FulfillmentConstraintRuleUpdateUserError#field-FulfillmentConstraintRuleUpdateUserError.fields.code)

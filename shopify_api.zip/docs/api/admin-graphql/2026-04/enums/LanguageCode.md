---
title: LanguageCode - GraphQL Admin
description: Language codes supported by Shopify.
api_version: 2026-04
source_url:
  html: 'https://shopify.dev/docs/api/admin-graphql/2026-04/enums/LanguageCode'
  md: 'https://shopify.dev/docs/api/admin-graphql/2026-04/enums/LanguageCode.md'
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Language​Code

enum

Language codes supported by Shopify.

## Valid values

* AF

  Afrikaans.

* AK

  Akan.

* AM

  Amharic.

* AR

  Arabic.

* AS

  Assamese.

* AZ

  Azerbaijani.

* BE

  Belarusian.

* BG

  Bulgarian.

* BM

  Bambara.

* BN

  Bangla.

* BO

  Tibetan.

* BR

  Breton.

* BS

  Bosnian.

* CA

  Catalan.

* CE

  Chechen.

* CKB

  Central Kurdish.

* CS

  Czech.

* CU

  Church Slavic.

* CY

  Welsh.

* DA

  Danish.

* DE

  German.

* DZ

  Dzongkha.

* EE

  Ewe.

* EL

  Greek.

* EN

  English.

* EO

  Esperanto.

* ES

  Spanish.

* ET

  Estonian.

* EU

  Basque.

* FA

  Persian.

* FF

  Fulah.

* FI

  Finnish.

* FIL

  Filipino.

* FO

  Faroese.

* FR

  French.

* FY

  Western Frisian.

* GA

  Irish.

* GD

  Scottish Gaelic.

* GL

  Galician.

* GU

  Gujarati.

* GV

  Manx.

* HA

  Hausa.

* HE

  Hebrew.

* HI

  Hindi.

* HR

  Croatian.

* HU

  Hungarian.

* HY

  Armenian.

* IA

  Interlingua.

* ID

  Indonesian.

* IG

  Igbo.

* II

  Sichuan Yi.

* IS

  Icelandic.

* IT

  Italian.

* JA

  Japanese.

* JV

  Javanese.

* KA

  Georgian.

* KI

  Kikuyu.

* KK

  Kazakh.

* KL

  Kalaallisut.

* KM

  Khmer.

* KN

  Kannada.

* KO

  Korean.

* KS

  Kashmiri.

* KU

  Kurdish.

* KW

  Cornish.

* KY

  Kyrgyz.

* LB

  Luxembourgish.

* LG

  Ganda.

* LN

  Lingala.

* LO

  Lao.

* LT

  Lithuanian.

* LU

  Luba-Katanga.

* LV

  Latvian.

* MG

  Malagasy.

* MI

  Māori.

* MK

  Macedonian.

* ML

  Malayalam.

* MN

  Mongolian.

* MR

  Marathi.

* MS

  Malay.

* MT

  Maltese.

* MY

  Burmese.

* NB

  Norwegian (Bokmål).

* ND

  North Ndebele.

* NE

  Nepali.

* NL

  Dutch.

* NN

  Norwegian Nynorsk.

* NO

  Norwegian.

* OM

  Oromo.

* OR

  Odia.

* OS

  Ossetic.

* PA

  Punjabi.

* PL

  Polish.

* PS

  Pashto.

* PT

  Portuguese.

* PT\_​BR

  Portuguese (Brazil).

* PT\_​PT

  Portuguese (Portugal).

* QU

  Quechua.

* RM

  Romansh.

* RN

  Rundi.

* RO

  Romanian.

* RU

  Russian.

* RW

  Kinyarwanda.

* SA

  Sanskrit.

* SC

  Sardinian.

* SD

  Sindhi.

* SE

  Northern Sami.

* SG

  Sango.

* SI

  Sinhala.

* SK

  Slovak.

* SL

  Slovenian.

* SN

  Shona.

* SO

  Somali.

* SQ

  Albanian.

* SR

  Serbian.

* SU

  Sundanese.

* SV

  Swedish.

* SW

  Swahili.

* TA

  Tamil.

* TE

  Telugu.

* TG

  Tajik.

* TH

  Thai.

* TI

  Tigrinya.

* TK

  Turkmen.

* TO

  Tongan.

* TR

  Turkish.

* TT

  Tatar.

* UG

  Uyghur.

* UK

  Ukrainian.

* UR

  Urdu.

* UZ

  Uzbek.

* VI

  Vietnamese.

* VO

  Volapük.

* WO

  Wolof.

* XH

  Xhosa.

* YI

  Yiddish.

* YO

  Yoruba.

* ZH

  Chinese.

* ZH\_​CN

  Chinese (Simplified).

* ZH\_​TW

  Chinese (Traditional).

* ZU

  Zulu.

***

## Fields

* [Full​Sync​Trace​Info.language](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/FullSyncTraceInfo#field-FullSyncTraceInfo.fields.language)

  OBJECT

  Trace information for a single country-language product feed sync triggered by [`channelFullSync`](https://shopify.dev/docs/api/admin-graphql/latest/mutations/channelFullSync).

* [Product​Feed.language](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/ProductFeed#field-ProductFeed.fields.language)

  OBJECT

  A product feed.

* [Product​Feed​Input.language](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/ProductFeedInput#fields-language)

  INPUT OBJECT

  The input fields required to create a product feed.

* [channel​Full​Sync.language](https://shopify.dev/docs/api/admin-graphql/2026-04/mutations/channelFullSync#arguments-language)

  ARGUMENT

***

## Map

### Fields with this enum

* [Full​Sync​Trace​Info.language](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/FullSyncTraceInfo#field-FullSyncTraceInfo.fields.language)
* [Product​Feed.language](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/ProductFeed#field-ProductFeed.fields.language)

### Inputs with this enum

* [Product​Feed​Input.language](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/ProductFeedInput#fields-language)

### Arguments with this enum

* [channel​Full​Sync.language](https://shopify.dev/docs/api/admin-graphql/2026-04/mutations/channelFullSync#arguments-language)

---
title: CheckoutBrandingMerchandiseThumbnailBadgeBackground - GraphQL Admin
description: The merchandise thumbnail badge background.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutBrandingMerchandiseThumbnailBadgeBackground
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutBrandingMerchandiseThumbnailBadgeBackground.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Checkout​Branding​Merchandise​Thumbnail​Badge​Background

enum

The merchandise thumbnail badge background.

## Valid values

* ACCENT

  The Accent background.

* BASE

  The Base background.

***

## Fields

* [Checkout​Branding​Merchandise​Thumbnail​Badge.background](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutBrandingMerchandiseThumbnailBadge#field-CheckoutBrandingMerchandiseThumbnailBadge.fields.background)

  OBJECT

  The merchandise thumbnail badges customizations.

* [Checkout​Branding​Merchandise​Thumbnail​Badge​Input.background](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutBrandingMerchandiseThumbnailBadgeInput#fields-background)

  INPUT OBJECT

  The input fields used to update the merchandise thumbnail badges customizations.

***

## Map

### Fields with this enum

* [Checkout​Branding​Merchandise​Thumbnail​Badge.background](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutBrandingMerchandiseThumbnailBadge#field-CheckoutBrandingMerchandiseThumbnailBadge.fields.background)

### Inputs with this enum

* [Checkout​Branding​Merchandise​Thumbnail​Badge​Input.background](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutBrandingMerchandiseThumbnailBadgeInput#fields-background)

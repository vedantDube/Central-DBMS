---
title: CustomerSavedSearchSortKeys - GraphQL Admin
description: The set of valid sort keys for the CustomerSavedSearch query.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CustomerSavedSearchSortKeys
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CustomerSavedSearchSortKeys.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Customer​Saved​Search​Sort​Keys

enum

The set of valid sort keys for the CustomerSavedSearch query.

## Valid values

* ID

  Sort by the `id` value.

* NAME

  Sort by the `name` value.

***

## Fields

* [Query​Root.customerSavedSearches(sortKey)](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/QueryRoot#field-QueryRoot.fields.customerSavedSearches.arguments.sortKey)

  ARGUMENT

  The schema's entry-point for queries. This acts as the public, top-level API from which all queries must start.

* [customer​Saved​Searches.sortKey](https://shopify.dev/docs/api/admin-graphql/2026-04/queries/customerSavedSearches#arguments-sortKey)

  ARGUMENT

***

## Map

### Arguments with this enum

* [Query​Root.customerSavedSearches(sortKey)](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/QueryRoot#field-QueryRoot.fields.customerSavedSearches.arguments.sortKey)
* [customer​Saved​Searches.sortKey](https://shopify.dev/docs/api/admin-graphql/2026-04/queries/customerSavedSearches#arguments-sortKey)

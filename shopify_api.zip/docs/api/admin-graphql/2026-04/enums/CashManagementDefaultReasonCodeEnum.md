---
title: CashManagementDefaultReasonCodeEnum - GraphQL Admin
description: Default reason codes for cash management.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CashManagementDefaultReasonCodeEnum
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CashManagementDefaultReasonCodeEnum.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Cash​Management​Default​Reason​Code​Enum

enum

Default reason codes for cash management.

## Valid values

* AUTO\_​END\_​SESSION\_​LOCATION\_​CHANGE

  Point of sale device payment session was automatically closed because the device switched to a different location.

* AUTO\_​END\_​SESSION\_​LOGOUT

  Point of sale device payment session was automatically closed because a staff member logged out.

* AUTO\_​START\_​SESSION\_​CHECKOUT

  Point of sale device payment session was automatically opened by a cash payment at checkout.

* CASH\_​COUNT

  Cash count.

* CASH\_​PAYOUT

  Cash payout.

* CASH\_​PICKUP

  Cash pickup.

* CHANGE\_​CORRECTION

  Change correction.

* OTHER

  Other.

* PETTY\_​CASH

  Petty cash.

* TIP\_​PAYOUT

  Tip payout.

***

## Fields

* [Cash​Management​Default​Reason​Code.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CashManagementDefaultReasonCode#field-CashManagementDefaultReasonCode.fields.code)

  OBJECT

  Default reason code.

***

## Map

### Fields with this enum

* [Cash​Management​Default​Reason​Code.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CashManagementDefaultReasonCode#field-CashManagementDefaultReasonCode.fields.code)

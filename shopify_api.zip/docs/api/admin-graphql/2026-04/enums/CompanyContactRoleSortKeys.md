---
title: CompanyContactRoleSortKeys - GraphQL Admin
description: The set of valid sort keys for the CompanyContactRole query.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CompanyContactRoleSortKeys
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CompanyContactRoleSortKeys.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Company​Contact​Role​Sort​Keys

enum

The set of valid sort keys for the CompanyContactRole query.

## Valid values

* CREATED\_​AT

  Sort by the `created_at` value.

* ID

  Sort by the `id` value.

* UPDATED\_​AT

  Sort by the `updated_at` value.

***

## Fields

* [Company.contactRoles(sortKey)](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/Company#field-Company.fields.contactRoles.arguments.sortKey)

  ARGUMENT

  A business entity that purchases from the shop as part of B2B commerce. Companies organize multiple locations and contacts who can place orders on behalf of the organization. [`CompanyLocation`](https://shopify.dev/docs/api/admin-graphql/latest/objects/CompanyLocation) objects can have custom pricing through [`Catalog`](https://shopify.dev/docs/api/admin-graphql/latest/interfaces/Catalog) and [`PriceList`](https://shopify.dev/docs/api/admin-graphql/latest/objects/PriceList) configurations.

***

## Map

### Arguments with this enum

* [Company.contactRoles(sortKey)](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/Company#field-Company.fields.contactRoles.arguments.sortKey)

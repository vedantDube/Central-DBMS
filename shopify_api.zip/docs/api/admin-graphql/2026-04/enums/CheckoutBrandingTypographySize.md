---
title: CheckoutBrandingTypographySize - GraphQL Admin
description: >-
  Possible choices for the font size.


  Note that the value in pixels of these settings can be customized with the

  [typography
  size](https://shopify.dev/docs/api/admin-graphql/latest/input-objects/CheckoutBrandingFontSizeInput)

  object. Refer to the [typography
  tutorial](https://shopify.dev/docs/apps/checkout/styling/customize-typography)

  for more information.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutBrandingTypographySize
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutBrandingTypographySize.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Checkout​Branding​Typography​Size

enum

Possible choices for the font size.

Note that the value in pixels of these settings can be customized with the [typography size](https://shopify.dev/docs/api/admin-graphql/latest/input-objects/CheckoutBrandingFontSizeInput) object. Refer to the [typography tutorial](https://shopify.dev/docs/apps/checkout/styling/customize-typography) for more information.

## Valid values

* BASE

  The base font size. Example: 14px.

* EXTRA\_​EXTRA\_​LARGE

  The extra extra large font size. Example: 24px.

* EXTRA\_​LARGE

  The extra large font size. Example: 21px.

* EXTRA\_​SMALL

  The extra small font size. Example: 10px.

* LARGE

  The large font size. Example: 19px.

* MEDIUM

  The medium font size. Example: 16px.

* SMALL

  The small font size. Example: 12px.

***

## Fields

* [Checkout​Branding​Typography​Style.size](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutBrandingTypographyStyle#field-CheckoutBrandingTypographyStyle.fields.size)

  OBJECT

  The typography customizations.

* [Checkout​Branding​Typography​Style​Input.size](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutBrandingTypographyStyleInput#fields-size)

  INPUT OBJECT

  The input fields used to update the typography customizations.

***

## Map

### Fields with this enum

* [Checkout​Branding​Typography​Style.size](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutBrandingTypographyStyle#field-CheckoutBrandingTypographyStyle.fields.size)

### Inputs with this enum

* [Checkout​Branding​Typography​Style​Input.size](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutBrandingTypographyStyleInput#fields-size)

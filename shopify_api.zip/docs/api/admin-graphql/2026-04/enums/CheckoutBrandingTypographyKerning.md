---
title: CheckoutBrandingTypographyKerning - GraphQL Admin
description: Possible values for the typography kerning.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutBrandingTypographyKerning
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutBrandingTypographyKerning.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Checkout​Branding​Typography​Kerning

enum

Possible values for the typography kerning.

## Valid values

* BASE

  Base or default kerning.

* EXTRA\_​LOOSE

  Extra loose kerning, leaving even more space in between characters.

* LOOSE

  Loose kerning, leaving more space than the default in between characters.

***

## Fields

* [Checkout​Branding​Typography​Style.kerning](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutBrandingTypographyStyle#field-CheckoutBrandingTypographyStyle.fields.kerning)

  OBJECT

  The typography customizations.

* [Checkout​Branding​Typography​Style​Global.kerning](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutBrandingTypographyStyleGlobal#field-CheckoutBrandingTypographyStyleGlobal.fields.kerning)

  OBJECT

  The global typography customizations.

* [Checkout​Branding​Typography​Style​Global​Input.kerning](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutBrandingTypographyStyleGlobalInput#fields-kerning)

  INPUT OBJECT

  The input fields used to update the global typography customizations.

* [Checkout​Branding​Typography​Style​Input.kerning](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutBrandingTypographyStyleInput#fields-kerning)

  INPUT OBJECT

  The input fields used to update the typography customizations.

***

## Map

### Fields with this enum

* [Checkout​Branding​Typography​Style.kerning](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutBrandingTypographyStyle#field-CheckoutBrandingTypographyStyle.fields.kerning)
* [Checkout​Branding​Typography​Style​Global.kerning](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutBrandingTypographyStyleGlobal#field-CheckoutBrandingTypographyStyleGlobal.fields.kerning)

### Inputs with this enum

* [Checkout​Branding​Typography​Style​Global​Input.kerning](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutBrandingTypographyStyleGlobalInput#fields-kerning)
* [Checkout​Branding​Typography​Style​Input.kerning](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutBrandingTypographyStyleInput#fields-kerning)

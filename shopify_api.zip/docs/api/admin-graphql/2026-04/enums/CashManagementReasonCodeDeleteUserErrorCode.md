---
title: CashManagementReasonCodeDeleteUserErrorCode - GraphQL Admin
description: >-
  Possible error codes that can be returned by
  `CashManagementReasonCodeDeleteUserError`.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CashManagementReasonCodeDeleteUserErrorCode
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CashManagementReasonCodeDeleteUserErrorCode.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Cash​Management​Reason​Code​Delete​User​Error​Code

enum

Possible error codes that can be returned by `CashManagementReasonCodeDeleteUserError`.

## Valid values

* DATABASE\_​ERROR

  Database error occurred.

* NOT\_​DELETABLE

  SYSTEM type reason codes are not deletable.

* NOT\_​FOUND

  Reason code not found.

***

## Fields

* [Cash​Management​Reason​Code​Delete​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CashManagementReasonCodeDeleteUserError#field-CashManagementReasonCodeDeleteUserError.fields.code)

  OBJECT

  An error that occurs during the execution of `CashManagementReasonCodeDelete`.

***

## Map

### Fields with this enum

* [Cash​Management​Reason​Code​Delete​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CashManagementReasonCodeDeleteUserError#field-CashManagementReasonCodeDeleteUserError.fields.code)

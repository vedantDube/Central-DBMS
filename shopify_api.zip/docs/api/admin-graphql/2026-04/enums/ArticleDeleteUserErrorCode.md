---
title: ArticleDeleteUserErrorCode - GraphQL Admin
description: Possible error codes that can be returned by `ArticleDeleteUserError`.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/ArticleDeleteUserErrorCode
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/ArticleDeleteUserErrorCode.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Article​Delete​User​Error​Code

enum

Possible error codes that can be returned by `ArticleDeleteUserError`.

## Valid values

* NOT\_​FOUND

  The record with the ID used as the input value couldn't be found.

***

## Fields

* [Article​Delete​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/ArticleDeleteUserError#field-ArticleDeleteUserError.fields.code)

  OBJECT

  An error that occurs during the execution of `ArticleDelete`.

***

## Map

### Fields with this enum

* [Article​Delete​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/ArticleDeleteUserError#field-ArticleDeleteUserError.fields.code)

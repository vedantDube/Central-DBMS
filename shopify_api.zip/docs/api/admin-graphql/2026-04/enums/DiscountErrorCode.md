---
title: DiscountErrorCode - GraphQL Admin
description: Possible error codes that can be returned by `DiscountUserError`.
api_version: 2026-04
source_url:
  html: 'https://shopify.dev/docs/api/admin-graphql/2026-04/enums/DiscountErrorCode'
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/DiscountErrorCode.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Discount​Error​Code

enum

Possible error codes that can be returned by `DiscountUserError`.

## Valid values

* ACTIVE\_​PERIOD\_​OVERLAP

  The active period overlaps with other automatic discounts. At any given time, only 25 automatic discounts can be active.

* APPLIES\_​ON\_​NOTHING

  A discount cannot have both appliesOnOneTimePurchase and appliesOnSubscription set to false.

* BLANK

  The input value is blank.

* CONFLICT

  The attribute selection contains conflicting settings.

* DUPLICATE

  The input value is already present.

* END\_​DATE\_​BEFORE\_​START\_​DATE

  The end date should be after the start date.

* EQUAL\_​TO

  The input value should be equal to the value allowed.

* EXCEEDED\_​MAX

  The value exceeded the maximum allowed value.

* GREATER\_​THAN

  The input value should be greater than the minimum allowed value.

* GREATER\_​THAN\_​OR\_​EQUAL\_​TO

  The input value should be greater than or equal to the minimum value allowed.

* IMPLICIT\_​DUPLICATE

  The value is already present through another selection.

* INCLUSION

  The input value isn't included in the list.

* INTERNAL\_​ERROR

  Unexpected internal error happened.

* INVALID

  The input value is invalid.

* INVALID\_​COMBINES\_​WITH\_​FOR\_​DISCOUNT\_​CLASS

  The `combinesWith` settings are invalid for the discount class.

* INVALID\_​DISCOUNT\_​CLASS\_​FOR\_​PRICE\_​RULE

  The discountClass is invalid for the price rule.

* INVALID\_​PRODUCT\_​DISCOUNTS\_​FALSE\_​WITH\_​EXISTING\_​TAGS\_​ON\_​SAME\_​CART\_​LINE

  The `productDiscounts` field can't be set to false when `productDiscountsWithTagsOnSameCartLine` tags exist on the discount.

* INVALID\_​PRODUCT\_​DISCOUNTS\_​WITH\_​TAGS\_​ON\_​SAME\_​CART\_​LINE\_​FOR\_​DISCOUNT\_​CLASS

  The `productDiscountsWithTagsOnSameCartLine` field is only valid for discounts with the PRODUCT discount class.

* INVALID\_​PRODUCT\_​DISCOUNTS\_​WITH\_​TAGS\_​ON\_​SAME\_​CART\_​LINE\_​WITHOUT\_​PRODUCT\_​DISCOUNTS

  The `productDiscountsWithTagsOnSameCartLine` field can only be specified when `productDiscounts` is true.

* INVALID\_​TAG\_​LENGTH

  The tag title exceeds the maximum length of 255 characters.

* LESS\_​THAN

  The input value should be less than the maximum value allowed.

* LESS\_​THAN\_​OR\_​EQUAL\_​TO

  The input value should be less than or equal to the maximum value allowed.

* MAX\_​APP\_​DISCOUNTS

  The active period overlaps with too many other app-provided discounts. There's a limit on the number of app discounts that can be active at any given time.

* MINIMUM\_​SUBTOTAL\_​AND\_​QUANTITY\_​RANGE\_​BOTH\_​PRESENT

  Specify a minimum subtotal or a quantity, but not both.

* MISSING\_​ARGUMENT

  Missing a required argument.

* MISSING\_​FUNCTION\_​IDENTIFIER

  Either function ID or function handle must be provided.

* MULTIPLE\_​FUNCTION\_​IDENTIFIERS

  Only one of function ID or function handle is allowed.

* MULTIPLE\_​RECURRING\_​CYCLE\_​LIMIT\_​FOR\_​NON\_​SUBSCRIPTION\_​ITEMS

  Recurring cycle limit must be 1 when discount does not apply to subscription items.

* PRESENT

  The input value needs to be blank.

* PRODUCT\_​DISCOUNTS\_​WITH\_​TAGS\_​ON\_​SAME\_​CART\_​LINE\_​NOT\_​ENTITLED

  The shop's plan does not allow setting `productDiscountsWithTagsOnSameCartLine`.

* RECURRING\_​CYCLE\_​LIMIT\_​NOT\_​A\_​VALID\_​INTEGER

  Recurring cycle limit must be a valid integer greater than or equal to 0.

* TAKEN

  The input value is already taken.

* TOO\_​LONG

  The input value is too long.

* TOO\_​MANY\_​ARGUMENTS

  Too many arguments provided.

* TOO\_​MANY\_​PRODUCT\_​DISCOUNTS\_​WITH\_​TAGS\_​ON\_​SAME\_​CART\_​LINE

  The number of tags in `productDiscountsWithTagsOnSameCartLine` exceeds the maximum of 10.

* TOO\_​MANY\_​TAGS

  The number of tags exceeds the maximum of 5.

* TOO\_​SHORT

  The input value is too short.

* VALUE\_​OUTSIDE\_​RANGE

  The value is outside of the allowed range.

***

## Fields

* [Discount​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/DiscountUserError#field-DiscountUserError.fields.code)

  OBJECT

  An error that occurs during the execution of a discount mutation.

***

## Map

### Fields with this enum

* [Discount​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/DiscountUserError#field-DiscountUserError.fields.code)

---
title: Audience - GraphQL Admin
description: The intended audience for the order status page.
api_version: 2026-04
source_url:
  html: 'https://shopify.dev/docs/api/admin-graphql/2026-04/enums/Audience'
  md: 'https://shopify.dev/docs/api/admin-graphql/2026-04/enums/Audience.md'
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Audience

enum

The intended audience for the order status page.

## Valid values

* CUSTOMERVIEW

  Intended for customer notifications.

* MERCHANTVIEW

  Intended for merchant wanting to preview the order status page. Should be used immediately after querying.

***

## Fields

* [Order.statusPageUrl(audience)](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/Order#field-Order.fields.statusPageUrl.arguments.audience)

  ARGUMENT

  The `Order` object represents a customer's request to purchase one or more products from a store. Use the `Order` object to handle the complete purchase lifecycle from checkout to fulfillment.

  Use the `Order` object when you need to:

  * Display order details on customer account pages or admin dashboards.
  * Create orders for phone sales, wholesale customers, or subscription services.
  * Update order information like shipping addresses, notes, or fulfillment status.
  * Process returns, exchanges, and partial refunds.
  * Generate invoices, receipts, and shipping labels.

  The `Order` object serves as the central hub connecting customer information, product details, payment processing, and fulfillment data within the GraphQL Admin API schema.

  ***

  **Note:** Only the last 60 days\&#39; worth of orders from a store are accessible from the \<code>Order\</code> object by default. If you want to access older records, then you need to \<a href="https://shopify.dev/docs/api/usage/access-scopes#orders-permissions">request access to all orders\</a>. If your app is granted access, then you can add the \<code>\<span class="PreventFireFoxApplyingGapToWBR">read\<wbr/>\_all\<wbr/>\_orders\</span>\</code>, \<code>\<span class="PreventFireFoxApplyingGapToWBR">read\<wbr/>\_orders\</span>\</code>, and \<code>\<span class="PreventFireFoxApplyingGapToWBR">write\<wbr/>\_orders\</span>\</code> scopes.

  ***

  ***

  **Caution:** Only use orders data if it\&#39;s required for your app\&#39;s functionality. Shopify will restrict \<a href="https://shopify.dev/docs/api/usage/access-scopes#requesting-specific-permissions">access to scopes\</a> for apps that don\&#39;t have a legitimate use for the associated data.

  ***

  Learn more about [building apps for orders and fulfillment](https://shopify.dev/docs/apps/build/orders-fulfillment).

***

## Map

### Arguments with this enum

* [Order.statusPageUrl(audience)](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/Order#field-Order.fields.statusPageUrl.arguments.audience)

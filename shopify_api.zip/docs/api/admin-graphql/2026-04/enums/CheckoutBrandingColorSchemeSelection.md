---
title: CheckoutBrandingColorSchemeSelection - GraphQL Admin
description: The possible color schemes.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutBrandingColorSchemeSelection
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutBrandingColorSchemeSelection.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Checkout​Branding​Color​Scheme​Selection

enum

The possible color schemes.

## Valid values

* COLOR\_​SCHEME1

  The COLOR\_SCHEME1 color scheme selection.

* COLOR\_​SCHEME2

  The COLOR\_SCHEME2 color scheme selection.

* COLOR\_​SCHEME3

  The COLOR\_SCHEME3 color scheme selection.

* COLOR\_​SCHEME4

  The COLOR\_SCHEME4 color scheme selection.

* COLOR\_​SCHEME5

  The COLOR\_SCHEME5 color scheme selection.

* COLOR\_​SCHEME6

  The COLOR\_SCHEME6 color scheme selection.

* TRANSPARENT

  The TRANSPARENT color scheme selection.

***

## Fields

* [Checkout​Branding​Footer.colorScheme](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutBrandingFooter#field-CheckoutBrandingFooter.fields.colorScheme)

  OBJECT

  A container for the footer section customizations.

* [Checkout​Branding​Footer​Input.colorScheme](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutBrandingFooterInput#fields-colorScheme)

  INPUT OBJECT

  The input fields when mutating the checkout footer settings.

* [Checkout​Branding​Header.colorScheme](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutBrandingHeader#field-CheckoutBrandingHeader.fields.colorScheme)

  OBJECT

  The header customizations.

* [Checkout​Branding​Header​Input.colorScheme](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutBrandingHeaderInput#fields-colorScheme)

  INPUT OBJECT

  The input fields used to update the header customizations.

* [Checkout​Branding​Main.colorScheme](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutBrandingMain#field-CheckoutBrandingMain.fields.colorScheme)

  OBJECT

  The main container customizations.

* [Checkout​Branding​Main​Input.colorScheme](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutBrandingMainInput#fields-colorScheme)

  INPUT OBJECT

  The input fields used to update the main container customizations.

* [Checkout​Branding​Main​Section.colorScheme](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutBrandingMainSection#field-CheckoutBrandingMainSection.fields.colorScheme)

  OBJECT

  The main sections customizations.

* [Checkout​Branding​Main​Section​Input.colorScheme](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutBrandingMainSectionInput#fields-colorScheme)

  INPUT OBJECT

  The input fields used to update the main sections customizations.

* [Checkout​Branding​Order​Summary.colorScheme](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutBrandingOrderSummary#field-CheckoutBrandingOrderSummary.fields.colorScheme)

  OBJECT

  The order summary customizations.

* [Checkout​Branding​Order​Summary​Input.colorScheme](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutBrandingOrderSummaryInput#fields-colorScheme)

  INPUT OBJECT

  The input fields used to update the order summary container customizations.

* [Checkout​Branding​Order​Summary​Section.colorScheme](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutBrandingOrderSummarySection#field-CheckoutBrandingOrderSummarySection.fields.colorScheme)

  OBJECT

  The order summary sections customizations.

* [Checkout​Branding​Order​Summary​Section​Input.colorScheme](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutBrandingOrderSummarySectionInput#fields-colorScheme)

  INPUT OBJECT

  The input fields used to update the order summary sections customizations.

***

## Map

### Fields with this enum

* [Checkout​Branding​Footer.colorScheme](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutBrandingFooter#field-CheckoutBrandingFooter.fields.colorScheme)
* [Checkout​Branding​Header.colorScheme](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutBrandingHeader#field-CheckoutBrandingHeader.fields.colorScheme)
* [Checkout​Branding​Main.colorScheme](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutBrandingMain#field-CheckoutBrandingMain.fields.colorScheme)
* [Checkout​Branding​Main​Section.colorScheme](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutBrandingMainSection#field-CheckoutBrandingMainSection.fields.colorScheme)
* [Checkout​Branding​Order​Summary.colorScheme](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutBrandingOrderSummary#field-CheckoutBrandingOrderSummary.fields.colorScheme)
* [Checkout​Branding​Order​Summary​Section.colorScheme](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutBrandingOrderSummarySection#field-CheckoutBrandingOrderSummarySection.fields.colorScheme)

### Inputs with this enum

* [Checkout​Branding​Footer​Input.colorScheme](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutBrandingFooterInput#fields-colorScheme)
* [Checkout​Branding​Header​Input.colorScheme](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutBrandingHeaderInput#fields-colorScheme)
* [Checkout​Branding​Main​Input.colorScheme](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutBrandingMainInput#fields-colorScheme)
* [Checkout​Branding​Main​Section​Input.colorScheme](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutBrandingMainSectionInput#fields-colorScheme)
* [Checkout​Branding​Order​Summary​Input.colorScheme](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutBrandingOrderSummaryInput#fields-colorScheme)
* [Checkout​Branding​Order​Summary​Section​Input.colorScheme](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutBrandingOrderSummarySectionInput#fields-colorScheme)

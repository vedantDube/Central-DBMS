---
title: FulfillmentConstraintRuleDeleteUserErrorCode - GraphQL Admin
description: >-
  Possible error codes that can be returned by
  `FulfillmentConstraintRuleDeleteUserError`.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/FulfillmentConstraintRuleDeleteUserErrorCode
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/FulfillmentConstraintRuleDeleteUserErrorCode.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Fulfillment​Constraint​Rule​Delete​User​Error​Code

enum

Possible error codes that can be returned by `FulfillmentConstraintRuleDeleteUserError`.

## Valid values

* NOT\_​FOUND

  Could not find fulfillment constraint rule for provided id.

* UNAUTHORIZED\_​APP\_​SCOPE

  Unauthorized app scope.

***

## Fields

* [Fulfillment​Constraint​Rule​Delete​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/FulfillmentConstraintRuleDeleteUserError#field-FulfillmentConstraintRuleDeleteUserError.fields.code)

  OBJECT

  An error that occurs during the execution of `FulfillmentConstraintRuleDelete`.

***

## Map

### Fields with this enum

* [Fulfillment​Constraint​Rule​Delete​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/FulfillmentConstraintRuleDeleteUserError#field-FulfillmentConstraintRuleDeleteUserError.fields.code)

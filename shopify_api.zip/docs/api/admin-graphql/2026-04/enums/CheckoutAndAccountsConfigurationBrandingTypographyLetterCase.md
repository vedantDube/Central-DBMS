---
title: CheckoutAndAccountsConfigurationBrandingTypographyLetterCase - GraphQL Admin
description: Possible values for the typography letter case.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutAndAccountsConfigurationBrandingTypographyLetterCase
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutAndAccountsConfigurationBrandingTypographyLetterCase.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Checkout​And​Accounts​Configuration​Branding​Typography​Letter​Case

enum

Possible values for the typography letter case.

## Valid values

* LOWER

  All letters are is lower case.

* NONE

  No letter casing applied.

* TITLE

  Capitalize the first letter of each word.

* UPPER

  All letters are uppercase.

***

## Fields

* [Checkout​And​Accounts​Configuration​Branding​Shared​Typography​Style.letterCase](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingSharedTypographyStyle#field-CheckoutAndAccountsConfigurationBrandingSharedTypographyStyle.fields.letterCase)

  OBJECT

  The shared typography customizations.

* [Checkout​And​Accounts​Configuration​Branding​Shared​Typography​Style​Input.letterCase](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingSharedTypographyStyleInput#fields-letterCase)

  INPUT OBJECT

  The input fields for customizing the shared typography.

* [Checkout​And​Accounts​Configuration​Branding​Typography​Style.letterCase](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingTypographyStyle#field-CheckoutAndAccountsConfigurationBrandingTypographyStyle.fields.letterCase)

  OBJECT

  The typography customizations.

* [Checkout​And​Accounts​Configuration​Branding​Typography​Style​Input.letterCase](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingTypographyStyleInput#fields-letterCase)

  INPUT OBJECT

  The input fields for customizing the typography.

***

## Map

### Fields with this enum

* [Checkout​And​Accounts​Configuration​Branding​Shared​Typography​Style.letterCase](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingSharedTypographyStyle#field-CheckoutAndAccountsConfigurationBrandingSharedTypographyStyle.fields.letterCase)
* [Checkout​And​Accounts​Configuration​Branding​Typography​Style.letterCase](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingTypographyStyle#field-CheckoutAndAccountsConfigurationBrandingTypographyStyle.fields.letterCase)

### Inputs with this enum

* [Checkout​And​Accounts​Configuration​Branding​Shared​Typography​Style​Input.letterCase](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingSharedTypographyStyleInput#fields-letterCase)
* [Checkout​And​Accounts​Configuration​Branding​Typography​Style​Input.letterCase](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingTypographyStyleInput#fields-letterCase)

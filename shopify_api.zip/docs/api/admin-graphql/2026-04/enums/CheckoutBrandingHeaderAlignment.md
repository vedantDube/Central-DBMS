---
title: CheckoutBrandingHeaderAlignment - GraphQL Admin
description: The possible header alignments.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutBrandingHeaderAlignment
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutBrandingHeaderAlignment.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Checkout​Branding​Header​Alignment

enum

The possible header alignments.

## Valid values

* CENTER

  Center alignment.

* END

  End alignment.

* START

  Start alignment.

***

## Fields

* [Checkout​Branding​Header.alignment](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutBrandingHeader#field-CheckoutBrandingHeader.fields.alignment)

  OBJECT

  The header customizations.

* [Checkout​Branding​Header​Input.alignment](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutBrandingHeaderInput#fields-alignment)

  INPUT OBJECT

  The input fields used to update the header customizations.

***

## Map

### Fields with this enum

* [Checkout​Branding​Header.alignment](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutBrandingHeader#field-CheckoutBrandingHeader.fields.alignment)

### Inputs with this enum

* [Checkout​Branding​Header​Input.alignment](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutBrandingHeaderInput#fields-alignment)

---
title: CheckoutAndAccountsConfigurationBrandingTypographyKerning - GraphQL Admin
description: Possible values for the typography kerning.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutAndAccountsConfigurationBrandingTypographyKerning
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutAndAccountsConfigurationBrandingTypographyKerning.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Checkout​And​Accounts​Configuration​Branding​Typography​Kerning

enum

Possible values for the typography kerning.

## Valid values

* BASE

  Base or default kerning.

* EXTRA\_​LOOSE

  Extra loose kerning, leaving even more space in between characters.

* LOOSE

  Loose kerning, leaving more space than the default in between characters.

***

## Fields

* [Checkout​And​Accounts​Configuration​Branding​Shared​Typography​Style.kerning](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingSharedTypographyStyle#field-CheckoutAndAccountsConfigurationBrandingSharedTypographyStyle.fields.kerning)

  OBJECT

  The shared typography customizations.

* [Checkout​And​Accounts​Configuration​Branding​Shared​Typography​Style​Input.kerning](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingSharedTypographyStyleInput#fields-kerning)

  INPUT OBJECT

  The input fields for customizing the shared typography.

* [Checkout​And​Accounts​Configuration​Branding​Typography​Style.kerning](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingTypographyStyle#field-CheckoutAndAccountsConfigurationBrandingTypographyStyle.fields.kerning)

  OBJECT

  The typography customizations.

* [Checkout​And​Accounts​Configuration​Branding​Typography​Style​Input.kerning](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingTypographyStyleInput#fields-kerning)

  INPUT OBJECT

  The input fields for customizing the typography.

***

## Map

### Fields with this enum

* [Checkout​And​Accounts​Configuration​Branding​Shared​Typography​Style.kerning](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingSharedTypographyStyle#field-CheckoutAndAccountsConfigurationBrandingSharedTypographyStyle.fields.kerning)
* [Checkout​And​Accounts​Configuration​Branding​Typography​Style.kerning](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingTypographyStyle#field-CheckoutAndAccountsConfigurationBrandingTypographyStyle.fields.kerning)

### Inputs with this enum

* [Checkout​And​Accounts​Configuration​Branding​Shared​Typography​Style​Input.kerning](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingSharedTypographyStyleInput#fields-kerning)
* [Checkout​And​Accounts​Configuration​Branding​Typography​Style​Input.kerning](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingTypographyStyleInput#fields-kerning)

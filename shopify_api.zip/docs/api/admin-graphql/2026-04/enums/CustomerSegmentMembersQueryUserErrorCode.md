---
title: CustomerSegmentMembersQueryUserErrorCode - GraphQL Admin
description: >-
  Possible error codes that can be returned by
  `CustomerSegmentMembersQueryUserError`.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CustomerSegmentMembersQueryUserErrorCode
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CustomerSegmentMembersQueryUserErrorCode.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Customer​Segment​Members​Query​User​Error​Code

enum

Possible error codes that can be returned by `CustomerSegmentMembersQueryUserError`.

## Valid values

* INVALID

  The input value is invalid.

***

## Fields

* [Customer​Segment​Members​Query​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CustomerSegmentMembersQueryUserError#field-CustomerSegmentMembersQueryUserError.fields.code)

  OBJECT

  Represents a customer segment members query custom error.

***

## Map

### Fields with this enum

* [Customer​Segment​Members​Query​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CustomerSegmentMembersQueryUserError#field-CustomerSegmentMembersQueryUserError.fields.code)

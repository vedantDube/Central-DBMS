---
title: CashTransactionActivityType - GraphQL Admin
description: The type of transaction activity.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CashTransactionActivityType
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CashTransactionActivityType.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Cash​Transaction​Activity​Type

enum

The type of transaction activity.

## Valid values

* CHANGE

  Change given to a customer.

* REFUND

  A cash refund.

* SALE

  A cash sale.

***

## Fields

* [Cash​Transaction​Activity.type](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CashTransactionActivity#field-CashTransactionActivity.fields.type)

  OBJECT

  A cash transaction activity.

***

## Map

### Fields with this enum

* [Cash​Transaction​Activity.type](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CashTransactionActivity#field-CashTransactionActivity.fields.type)

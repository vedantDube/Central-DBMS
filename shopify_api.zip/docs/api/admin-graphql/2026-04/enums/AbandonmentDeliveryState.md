---
title: AbandonmentDeliveryState - GraphQL Admin
description: Specifies the delivery state of a marketing activity.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/AbandonmentDeliveryState
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/AbandonmentDeliveryState.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Abandonment​Delivery​State

enum

Specifies the delivery state of a marketing activity.

## Valid values

* NOT\_​SENT

  The marketing activity action has not yet been sent.

* SCHEDULED

  The marketing activity action has been scheduled for later delivery.

* SENT

  The marketing activity action has been sent.

***

## Fields

* [abandonment​Update​Activities​Delivery​Statuses.deliveryStatus](https://shopify.dev/docs/api/admin-graphql/2026-04/mutations/abandonmentUpdateActivitiesDeliveryStatuses#arguments-deliveryStatus)

  ARGUMENT

***

## Map

### Arguments with this enum

* [abandonment​Update​Activities​Delivery​Statuses.deliveryStatus](https://shopify.dev/docs/api/admin-graphql/2026-04/mutations/abandonmentUpdateActivitiesDeliveryStatuses#arguments-deliveryStatus)

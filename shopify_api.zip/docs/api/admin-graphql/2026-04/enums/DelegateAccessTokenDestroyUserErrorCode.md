---
title: DelegateAccessTokenDestroyUserErrorCode - GraphQL Admin
description: >-
  Possible error codes that can be returned by
  `DelegateAccessTokenDestroyUserError`.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/DelegateAccessTokenDestroyUserErrorCode
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/DelegateAccessTokenDestroyUserErrorCode.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Delegate​Access​Token​Destroy​User​Error​Code

enum

Possible error codes that can be returned by `DelegateAccessTokenDestroyUserError`.

## Valid values

* ACCESS\_​DENIED

  Access denied.

* ACCESS\_​TOKEN\_​NOT\_​FOUND

  Access token not found.

* CAN\_​ONLY\_​DELETE\_​DELEGATE\_​TOKENS

  Cannot delete parent access token.

* PERSISTENCE\_​FAILED

  Persistence failed.

***

## Fields

* [Delegate​Access​Token​Destroy​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/DelegateAccessTokenDestroyUserError#field-DelegateAccessTokenDestroyUserError.fields.code)

  OBJECT

  An error that occurs during the execution of `DelegateAccessTokenDestroy`.

***

## Map

### Fields with this enum

* [Delegate​Access​Token​Destroy​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/DelegateAccessTokenDestroyUserError#field-DelegateAccessTokenDestroyUserError.fields.code)

---
title: FulfillmentOrderCancelErrorCode - GraphQL Admin
description: Possible error codes that can be returned by `FulfillmentOrderCancelError`.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/FulfillmentOrderCancelErrorCode
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/FulfillmentOrderCancelErrorCode.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Fulfillment​Order​Cancel​Error​Code

enum

Possible error codes that can be returned by `FulfillmentOrderCancelError`.

## Valid values

* FULFILLMENT\_​ORDER\_​HAS\_​MANUALLY\_​REPORTED\_​PROGRESS

  Cannot cancel fulfillment order with reported progress. Mark as unfulfilled first.

***

## Fields

* [Fulfillment​Order​Cancel​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/FulfillmentOrderCancelError#field-FulfillmentOrderCancelError.fields.code)

  OBJECT

  Represents an error that occurs while cancelling a fulfillment order.

***

## Map

### Fields with this enum

* [Fulfillment​Order​Cancel​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/FulfillmentOrderCancelError#field-FulfillmentOrderCancelError.fields.code)

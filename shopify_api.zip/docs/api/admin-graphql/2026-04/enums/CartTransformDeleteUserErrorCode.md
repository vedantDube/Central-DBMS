---
title: CartTransformDeleteUserErrorCode - GraphQL Admin
description: Possible error codes that can be returned by `CartTransformDeleteUserError`.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CartTransformDeleteUserErrorCode
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CartTransformDeleteUserErrorCode.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Cart​Transform​Delete​User​Error​Code

enum

Possible error codes that can be returned by `CartTransformDeleteUserError`.

## Valid values

* NOT\_​FOUND

  Could not find cart transform for provided id.

* UNAUTHORIZED\_​APP\_​SCOPE

  Unauthorized app scope.

***

## Fields

* [Cart​Transform​Delete​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CartTransformDeleteUserError#field-CartTransformDeleteUserError.fields.code)

  OBJECT

  An error that occurs during the execution of `CartTransformDelete`.

***

## Map

### Fields with this enum

* [Cart​Transform​Delete​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CartTransformDeleteUserError#field-CartTransformDeleteUserError.fields.code)

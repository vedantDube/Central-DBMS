---
title: CollectionAddProductsV2UserErrorCode - GraphQL Admin
description: >-
  Possible error codes that can be returned by
  `CollectionAddProductsV2UserError`.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CollectionAddProductsV2UserErrorCode
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CollectionAddProductsV2UserErrorCode.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Collection​Add​Products​V2User​Error​Code

enum

Possible error codes that can be returned by `CollectionAddProductsV2UserError`.

## Valid values

* CANT\_​ADD\_​TO\_​SMART\_​COLLECTION

  Can't manually add products to a smart collection.

* COLLECTION\_​DOES\_​NOT\_​EXIST

  Collection doesn't exist.

***

## Fields

* [Collection​Add​Products​V2User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CollectionAddProductsV2UserError#field-CollectionAddProductsV2UserError.fields.code)

  OBJECT

  An error that occurs during the execution of `CollectionAddProductsV2`.

***

## Map

### Fields with this enum

* [Collection​Add​Products​V2User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CollectionAddProductsV2UserError#field-CollectionAddProductsV2UserError.fields.code)

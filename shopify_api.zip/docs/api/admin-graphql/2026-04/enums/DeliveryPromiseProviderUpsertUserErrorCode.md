---
title: DeliveryPromiseProviderUpsertUserErrorCode - GraphQL Admin
description: >-
  Possible error codes that can be returned by
  `DeliveryPromiseProviderUpsertUserError`.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/DeliveryPromiseProviderUpsertUserErrorCode
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/DeliveryPromiseProviderUpsertUserErrorCode.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Delivery​Promise​Provider​Upsert​User​Error​Code

enum

Possible error codes that can be returned by `DeliveryPromiseProviderUpsertUserError`.

## Valid values

* INVALID\_​TIME\_​ZONE

  The time zone is invalid.

* MUST\_​BELONG\_​TO\_​APP

  The location doesn't belong to the app.

* NOT\_​FOUND

  The record with the ID used as the input value couldn't be found.

* TOO\_​LONG

  The input value is too long.

***

## Fields

* [Delivery​Promise​Provider​Upsert​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/DeliveryPromiseProviderUpsertUserError#field-DeliveryPromiseProviderUpsertUserError.fields.code)

  OBJECT

  An error that occurs during the execution of `DeliveryPromiseProviderUpsert`.

***

## Map

### Fields with this enum

* [Delivery​Promise​Provider​Upsert​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/DeliveryPromiseProviderUpsertUserError#field-DeliveryPromiseProviderUpsertUserError.fields.code)

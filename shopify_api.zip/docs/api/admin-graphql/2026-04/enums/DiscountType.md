---
title: DiscountType - GraphQL Admin
description: The type of the subscription discount.
api_version: 2026-04
source_url:
  html: 'https://shopify.dev/docs/api/admin-graphql/2026-04/enums/DiscountType'
  md: 'https://shopify.dev/docs/api/admin-graphql/2026-04/enums/DiscountType.md'
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Discount​Type

enum

The type of the subscription discount.

## Valid values

* AUTOMATIC\_​DISCOUNT

  Automatic discount type.

* CODE\_​DISCOUNT

  Code discount type.

* MANUAL

  Manual discount type.

***

## Fields

* [Subscription​Manual​Discount.type](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/SubscriptionManualDiscount#field-SubscriptionManualDiscount.fields.type)

  OBJECT

  Custom subscription discount.

***

## Map

### Fields with this enum

* [Subscription​Manual​Discount.type](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/SubscriptionManualDiscount#field-SubscriptionManualDiscount.fields.type)

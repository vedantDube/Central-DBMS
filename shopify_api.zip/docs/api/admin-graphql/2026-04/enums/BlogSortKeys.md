---
title: BlogSortKeys - GraphQL Admin
description: The set of valid sort keys for the Blog query.
api_version: 2026-04
source_url:
  html: 'https://shopify.dev/docs/api/admin-graphql/2026-04/enums/BlogSortKeys'
  md: 'https://shopify.dev/docs/api/admin-graphql/2026-04/enums/BlogSortKeys.md'
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Blog​Sort​Keys

enum

The set of valid sort keys for the Blog query.

## Valid values

* HANDLE

  Sort by the `handle` value.

* ID

  Sort by the `id` value.

* TITLE

  Sort by the `title` value.

***

## Fields

* [Query​Root.blogs(sortKey)](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/QueryRoot#field-QueryRoot.fields.blogs.arguments.sortKey)

  ARGUMENT

  The schema's entry-point for queries. This acts as the public, top-level API from which all queries must start.

* [blogs.sortKey](https://shopify.dev/docs/api/admin-graphql/2026-04/queries/blogs#arguments-sortKey)

  ARGUMENT

***

## Map

### Arguments with this enum

* [Query​Root.blogs(sortKey)](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/QueryRoot#field-QueryRoot.fields.blogs.arguments.sortKey)
* [blogs.sortKey](https://shopify.dev/docs/api/admin-graphql/2026-04/queries/blogs#arguments-sortKey)

---
title: DayOfTheWeek - GraphQL Admin
description: Days of the week from Monday to Sunday.
api_version: 2026-04
source_url:
  html: 'https://shopify.dev/docs/api/admin-graphql/2026-04/enums/DayOfTheWeek'
  md: 'https://shopify.dev/docs/api/admin-graphql/2026-04/enums/DayOfTheWeek.md'
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Day​Of​The​Week

enum

Days of the week from Monday to Sunday.

## Valid values

* FRIDAY

  Friday.

* MONDAY

  Monday.

* SATURDAY

  Saturday.

* SUNDAY

  Sunday.

* THURSDAY

  Thursday.

* TUESDAY

  Tuesday.

* WEDNESDAY

  Wednesday.

***

## Fields

* [Shopify​Payments​Payout​Schedule.weeklyAnchor](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/ShopifyPaymentsPayoutSchedule#field-ShopifyPaymentsPayoutSchedule.fields.weeklyAnchor)

  OBJECT

  The payment schedule for a payments account.

***

## Map

### Fields with this enum

* [Shopify​Payments​Payout​Schedule.weeklyAnchor](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/ShopifyPaymentsPayoutSchedule#field-ShopifyPaymentsPayoutSchedule.fields.weeklyAnchor)

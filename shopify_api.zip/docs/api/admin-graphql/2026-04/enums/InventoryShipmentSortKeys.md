---
title: InventoryShipmentSortKeys - GraphQL Admin
description: The set of valid sort keys for the InventoryShipment query.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/InventoryShipmentSortKeys
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/InventoryShipmentSortKeys.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Inventory​Shipment​Sort​Keys

enum

The set of valid sort keys for the InventoryShipment query.

## Valid values

* ID

  Sort by the `id` value.

* STATUS

  Sort by the `status` value.

***

## Fields

* [Query​Root.inventoryShipments(sortKey)](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/QueryRoot#field-QueryRoot.fields.inventoryShipments.arguments.sortKey)

  ARGUMENT

  The schema's entry-point for queries. This acts as the public, top-level API from which all queries must start.

* [inventory​Shipments.sortKey](https://shopify.dev/docs/api/admin-graphql/2026-04/queries/inventoryShipments#arguments-sortKey)

  ARGUMENT

***

## Map

### Arguments with this enum

* [Query​Root.inventoryShipments(sortKey)](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/QueryRoot#field-QueryRoot.fields.inventoryShipments.arguments.sortKey)
* [inventory​Shipments.sortKey](https://shopify.dev/docs/api/admin-graphql/2026-04/queries/inventoryShipments#arguments-sortKey)

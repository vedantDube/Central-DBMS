---
title: DistanceUnit - GraphQL Admin
description: Units of measurement for distance.
api_version: 2026-04
source_url:
  html: 'https://shopify.dev/docs/api/admin-graphql/2026-04/enums/DistanceUnit'
  md: 'https://shopify.dev/docs/api/admin-graphql/2026-04/enums/DistanceUnit.md'
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Distance​Unit

enum

Units of measurement for distance.

## Valid values

* KILOMETERS

  Metric system unit of distance.

* MILES

  Imperial system unit of distance.

***

## Fields

* [Distance.unit](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/Distance#field-Distance.fields.unit)

  OBJECT

  A distance, which includes a numeric value and a unit of measurement.

***

## Map

### Fields with this enum

* [Distance.unit](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/Distance#field-Distance.fields.unit)

---
title: CommentApproveUserErrorCode - GraphQL Admin
description: Possible error codes that can be returned by `CommentApproveUserError`.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CommentApproveUserErrorCode
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CommentApproveUserErrorCode.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Comment​Approve​User​Error​Code

enum

Possible error codes that can be returned by `CommentApproveUserError`.

## Valid values

* NOT\_​FOUND

  The record with the ID used as the input value couldn't be found.

***

## Fields

* [Comment​Approve​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CommentApproveUserError#field-CommentApproveUserError.fields.code)

  OBJECT

  An error that occurs during the execution of `CommentApprove`.

***

## Map

### Fields with this enum

* [Comment​Approve​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CommentApproveUserError#field-CommentApproveUserError.fields.code)

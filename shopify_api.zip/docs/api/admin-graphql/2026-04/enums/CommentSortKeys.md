---
title: CommentSortKeys - GraphQL Admin
description: The set of valid sort keys for the Comment query.
api_version: 2026-04
source_url:
  html: 'https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CommentSortKeys'
  md: 'https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CommentSortKeys.md'
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Comment​Sort​Keys

enum

The set of valid sort keys for the Comment query.

## Valid values

* CREATED\_​AT

  Sort by the `created_at` value.

* ID

  Sort by the `id` value.

***

## Fields

* [Query​Root.comments(sortKey)](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/QueryRoot#field-QueryRoot.fields.comments.arguments.sortKey)

  ARGUMENT

  The schema's entry-point for queries. This acts as the public, top-level API from which all queries must start.

* [comments.sortKey](https://shopify.dev/docs/api/admin-graphql/2026-04/queries/comments#arguments-sortKey)

  ARGUMENT

***

## Map

### Arguments with this enum

* [Query​Root.comments(sortKey)](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/QueryRoot#field-QueryRoot.fields.comments.arguments.sortKey)
* [comments.sortKey](https://shopify.dev/docs/api/admin-graphql/2026-04/queries/comments#arguments-sortKey)

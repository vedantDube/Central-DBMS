---
title: ColumnDataType - GraphQL Admin
description: The data type of a column.
api_version: 2026-04
source_url:
  html: 'https://shopify.dev/docs/api/admin-graphql/2026-04/enums/ColumnDataType'
  md: 'https://shopify.dev/docs/api/admin-graphql/2026-04/enums/ColumnDataType.md'
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Column​Data​Type

enum

The data type of a column.

## Valid values

* ARRAY

  Represents an array of values.

* BOOLEAN

  Represents a boolean value.

* COLOR

  Represents a hex color value.

* CUMULATIVE

  Represents a cumulative value.

* DAY\_​DURATION

  Represents a duration in days.

* DAY\_​OF\_​WEEK

  Represents a day of week value.

* DAY\_​TIMESTAMP

  Represents a day-level timestamp value.

* DECIMAL

  Represents a decimal value.

* ENTITY

  Represents an entity reference value.

* FLOAT

  Represents a floating point value.

* GEO\_​COORDINATE

  Represents a geographic coordinate value.

* HOUR\_​DURATION

  Represents a duration in hours.

* HOUR\_​OF\_​DAY

  Represents an hour of day value.

* HOUR\_​TIMESTAMP

  Represents a hour-level timestamp value.

* IDENTITY

  Represents an identity value.

* INTEGER

  Represents an integer value.

* MILLISECOND\_​DURATION

  Represents a duration in milliseconds.

* MINUTE\_​DURATION

  Represents a duration in minutes.

* MINUTE\_​TIMESTAMP

  Represents a minute-level timestamp value.

* MONEY

  Represents a monetary value.

* MONTH\_​OF\_​YEAR

  Represents a month of year value.

* MONTH\_​TIMESTAMP

  Represents a month-level timestamp value.

* MULTIPLIER

  Represents a multiplier value.

* PERCENT

  Represents a percentage value.

* QUARTER\_​TIMESTAMP

  Represents a quarter-level timestamp value.

* RATING

  Represents a rating value.

* SECOND\_​DURATION

  Represents a duration in seconds.

* SECOND\_​TIMESTAMP

  Represents a second-level timestamp value.

* STRING

  Represents a string value.

* STRING\_​IDENTITY

  Represents a string identity value.

* TIMESTAMP

  Represents a timestamp value in seconds.

* UNITLESS\_​SCALAR

  Represents a unitless scalar value.

* UNSPECIFIED

  Represents an unspecified data type.

* WEEK\_​OF\_​YEAR

  Represents a week of year value.

* WEEK\_​TIMESTAMP

  Represents a week-level timestamp value.

* YEAR\_​TIMESTAMP

  Represents a year-level timestamp value.

***

## Fields

* [Shopifyql​Table​Data​Column.dataType](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/ShopifyqlTableDataColumn#field-ShopifyqlTableDataColumn.fields.dataType)

  OBJECT

  Represents a column in a ShopifyQL query response.

* [Shopifyql​Table​Data​Column.subType](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/ShopifyqlTableDataColumn#field-ShopifyqlTableDataColumn.fields.subType)

  OBJECT

  Represents a column in a ShopifyQL query response.

***

## Map

### Fields with this enum

* [Shopifyql​Table​Data​Column.dataType](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/ShopifyqlTableDataColumn#field-ShopifyqlTableDataColumn.fields.dataType)
* [Shopifyql​Table​Data​Column.subType](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/ShopifyqlTableDataColumn#field-ShopifyqlTableDataColumn.fields.subType)

---
title: CheckoutBrandingBackgroundStyle - GraphQL Admin
description: Possible values for the background style.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutBrandingBackgroundStyle
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutBrandingBackgroundStyle.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Checkout​Branding​Background​Style

enum

Possible values for the background style.

## Valid values

* NONE

  The None background style.

* SOLID

  The Solid background style.

***

## Fields

* [Checkout​Branding​Button.background](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutBrandingButton#field-CheckoutBrandingButton.fields.background)

  OBJECT

  The buttons customizations.

* [Checkout​Branding​Button​Input.background](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutBrandingButtonInput#fields-background)

  INPUT OBJECT

  The input fields used to update the buttons customizations.

***

## Map

### Fields with this enum

* [Checkout​Branding​Button.background](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutBrandingButton#field-CheckoutBrandingButton.fields.background)

### Inputs with this enum

* [Checkout​Branding​Button​Input.background](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutBrandingButtonInput#fields-background)

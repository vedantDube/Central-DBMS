---
title: BlogUpdateUserErrorCode - GraphQL Admin
description: Possible error codes that can be returned by `BlogUpdateUserError`.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/BlogUpdateUserErrorCode
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/BlogUpdateUserErrorCode.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Blog​Update​User​Error​Code

enum

Possible error codes that can be returned by `BlogUpdateUserError`.

## Valid values

* BLANK

  The input value is blank.

* INCLUSION

  The input value isn't included in the list.

* INVALID

  The input value is invalid.

* NOT\_​FOUND

  The record with the ID used as the input value couldn't be found.

* TOO\_​LONG

  The input value is too long.

***

## Fields

* [Blog​Update​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/BlogUpdateUserError#field-BlogUpdateUserError.fields.code)

  OBJECT

  An error that occurs during the execution of `BlogUpdate`.

***

## Map

### Fields with this enum

* [Blog​Update​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/BlogUpdateUserError#field-BlogUpdateUserError.fields.code)

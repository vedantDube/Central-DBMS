---
title: ArticleTagSort - GraphQL Admin
description: Possible sort of tags.
api_version: 2026-04
source_url:
  html: 'https://shopify.dev/docs/api/admin-graphql/2026-04/enums/ArticleTagSort'
  md: 'https://shopify.dev/docs/api/admin-graphql/2026-04/enums/ArticleTagSort.md'
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Article​Tag​Sort

enum

Possible sort of tags.

## Valid values

* ALPHABETICAL

  Sort alphabetically..

* POPULAR

  Sort by popularity, starting with the most popular tag.

***

## Fields

* [Query​Root.articleTags(sort)](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/QueryRoot#field-QueryRoot.fields.articleTags.arguments.sort)

  ARGUMENT

  The schema's entry-point for queries. This acts as the public, top-level API from which all queries must start.

* [article​Tags.sort](https://shopify.dev/docs/api/admin-graphql/2026-04/queries/articleTags#arguments-sort)

  ARGUMENT

***

## Map

### Arguments with this enum

* [Query​Root.articleTags(sort)](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/QueryRoot#field-QueryRoot.fields.articleTags.arguments.sort)
* [article​Tags.sort](https://shopify.dev/docs/api/admin-graphql/2026-04/queries/articleTags#arguments-sort)

---
title: AppInstallationSortKeys - GraphQL Admin
description: The set of valid sort keys for the AppInstallation query.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/AppInstallationSortKeys
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/AppInstallationSortKeys.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# App​Installation​Sort​Keys

enum

The set of valid sort keys for the AppInstallation query.

## Valid values

* APP\_​TITLE

  Sort by the `app_title` value.

* ID

  Sort by the `id` value.

* INSTALLED\_​AT

  Sort by the `installed_at` value.

***

## Fields

* [Query​Root.appInstallations(sortKey)](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/QueryRoot#field-QueryRoot.fields.appInstallations.arguments.sortKey)

  ARGUMENT

  The schema's entry-point for queries. This acts as the public, top-level API from which all queries must start.

* [app​Installations.sortKey](https://shopify.dev/docs/api/admin-graphql/2026-04/queries/appInstallations#arguments-sortKey)

  ARGUMENT

***

## Map

### Arguments with this enum

* [Query​Root.appInstallations(sortKey)](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/QueryRoot#field-QueryRoot.fields.appInstallations.arguments.sortKey)
* [app​Installations.sortKey](https://shopify.dev/docs/api/admin-graphql/2026-04/queries/appInstallations#arguments-sortKey)

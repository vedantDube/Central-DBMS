---
title: GiftCardSendNotificationToCustomerUserErrorCode - GraphQL Admin
description: >-
  Possible error codes that can be returned by
  `GiftCardSendNotificationToCustomerUserError`.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/GiftCardSendNotificationToCustomerUserErrorCode
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/GiftCardSendNotificationToCustomerUserErrorCode.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Gift​Card​Send​Notification​To​Customer​User​Error​Code

enum

Possible error codes that can be returned by `GiftCardSendNotificationToCustomerUserError`.

## Valid values

* CUSTOMER\_​NOT\_​FOUND

  The customer could not be found.

* GIFT\_​CARD\_​NOT\_​FOUND

  The gift card could not be found.

* INVALID

  The input value is invalid.

***

## Fields

* [Gift​Card​Send​Notification​To​Customer​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/GiftCardSendNotificationToCustomerUserError#field-GiftCardSendNotificationToCustomerUserError.fields.code)

  OBJECT

  An error that occurs during the execution of `GiftCardSendNotificationToCustomer`.

***

## Map

### Fields with this enum

* [Gift​Card​Send​Notification​To​Customer​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/GiftCardSendNotificationToCustomerUserError#field-GiftCardSendNotificationToCustomerUserError.fields.code)

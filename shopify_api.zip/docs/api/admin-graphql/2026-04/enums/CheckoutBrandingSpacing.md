---
title: CheckoutBrandingSpacing - GraphQL Admin
description: Possible values for the spacing.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutBrandingSpacing
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutBrandingSpacing.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Checkout​Branding​Spacing

enum

Possible values for the spacing.

## Valid values

* BASE

  The Base spacing.

* EXTRA\_​LOOSE

  The Extra Loose spacing.

* EXTRA\_​TIGHT

  The Extra Tight spacing.

* LOOSE

  The Loose spacing.

* NONE

  The None spacing.

* TIGHT

  The Tight spacing.

***

## Fields

* [Checkout​Branding​Button.blockPadding](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutBrandingButton#field-CheckoutBrandingButton.fields.blockPadding)

  OBJECT

  The buttons customizations.

* [Checkout​Branding​Button.inlinePadding](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutBrandingButton#field-CheckoutBrandingButton.fields.inlinePadding)

  OBJECT

  The buttons customizations.

* [Checkout​Branding​Button​Input.blockPadding](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutBrandingButtonInput#fields-blockPadding)

  INPUT OBJECT

  The input fields used to update the buttons customizations.

* [Checkout​Branding​Button​Input.inlinePadding](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutBrandingButtonInput#fields-inlinePadding)

  INPUT OBJECT

  The input fields used to update the buttons customizations.

***

## Map

### Fields with this enum

* [Checkout​Branding​Button.blockPadding](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutBrandingButton#field-CheckoutBrandingButton.fields.blockPadding)
* [Checkout​Branding​Button.inlinePadding](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutBrandingButton#field-CheckoutBrandingButton.fields.inlinePadding)

### Inputs with this enum

* [Checkout​Branding​Button​Input.blockPadding](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutBrandingButtonInput#fields-blockPadding)
* [Checkout​Branding​Button​Input.inlinePadding](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutBrandingButtonInput#fields-inlinePadding)

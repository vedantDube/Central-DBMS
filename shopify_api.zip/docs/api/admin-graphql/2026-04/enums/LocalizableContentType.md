---
title: LocalizableContentType - GraphQL Admin
description: |-
  Specifies the type of the underlying localizable content. This can be used to
  conditionally render different UI elements such as input fields.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/LocalizableContentType
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/LocalizableContentType.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Localizable​Content​Type

enum

Specifies the type of the underlying localizable content. This can be used to conditionally render different UI elements such as input fields.

## Valid values

* FILE\_​REFERENCE

  A file reference.

* HTML

  An HTML.

* INLINE\_​RICH\_​TEXT

  An inline rich text.

* JSON

  A JSON.

* JSON\_​STRING

  A JSON string.

* LINK

  A link.

* LIST\_​FILE\_​REFERENCE

  A list of file references.

* LIST\_​LINK

  A list of links.

* LIST\_​MULTI\_​LINE\_​TEXT\_​FIELD

  A list of multi-line texts.

* LIST\_​SINGLE\_​LINE\_​TEXT\_​FIELD

  A list of single-line texts.

* LIST\_​URL

  A list of URLs.

* MULTI\_​LINE\_​TEXT\_​FIELD

  A multi-line text.

* RICH\_​TEXT\_​FIELD

  A rich text.

* SINGLE\_​LINE\_​TEXT\_​FIELD

  A single-line text.

* STRING

  A string.

* URI

  A URI.

* URL

  A URL.

***

## Fields

* [Translatable​Content.type](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/TranslatableContent#field-TranslatableContent.fields.type)

  OBJECT

  Translatable content of a resource's field.

***

## Map

### Fields with this enum

* [Translatable​Content.type](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/TranslatableContent#field-TranslatableContent.fields.type)

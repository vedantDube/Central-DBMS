---
title: CheckoutAndAccountsConfigurationBrandingTypographySize - GraphQL Admin
description: Possible choices for the font size.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutAndAccountsConfigurationBrandingTypographySize
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutAndAccountsConfigurationBrandingTypographySize.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Checkout​And​Accounts​Configuration​Branding​Typography​Size

enum

Possible choices for the font size.

## Valid values

* BASE

  The Base font size. Example: 14px.

* EXTRA\_​EXTRA\_​LARGE

  The Extra extra large font size. Example: 24px.

* EXTRA\_​LARGE

  The Extra large font size. Example: 21px.

* EXTRA\_​SMALL

  The Extra small font size. Example: 10px.

* LARGE

  The Large font size. Example: 19px.

* MEDIUM

  The Medium font size. Example: 16px.

* SMALL

  The Small font size. Example: 12px.

***

## Fields

* [Checkout​And​Accounts​Configuration​Branding​Typography​Style.size](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingTypographyStyle#field-CheckoutAndAccountsConfigurationBrandingTypographyStyle.fields.size)

  OBJECT

  The typography customizations.

* [Checkout​And​Accounts​Configuration​Branding​Typography​Style​Input.size](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingTypographyStyleInput#fields-size)

  INPUT OBJECT

  The input fields for customizing the typography.

***

## Map

### Fields with this enum

* [Checkout​And​Accounts​Configuration​Branding​Typography​Style.size](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingTypographyStyle#field-CheckoutAndAccountsConfigurationBrandingTypographyStyle.fields.size)

### Inputs with this enum

* [Checkout​And​Accounts​Configuration​Branding​Typography​Style​Input.size](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingTypographyStyleInput#fields-size)

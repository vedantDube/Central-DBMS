---
title: CheckoutAndAccountsConfigurationBrandingCornerRadius - GraphQL Admin
description: |-
  The options for customizing the corner radius of checkout-related objects.
  Examples include the primary button, the name text fields and the sections
  within the main area (if they have borders).
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutAndAccountsConfigurationBrandingCornerRadius
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutAndAccountsConfigurationBrandingCornerRadius.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Checkout​And​Accounts​Configuration​Branding​Corner​Radius

enum

The options for customizing the corner radius of checkout-related objects. Examples include the primary button, the name text fields and the sections within the main area (if they have borders).

## Valid values

* BASE

  The corner radius with a pixel value defined by designTokens.cornerRadius.base.

* LARGE

  The corner radius with a pixel value defined by designTokens.cornerRadius.large.

* NONE

  The 0px corner radius (square corners).

* SMALL

  The corner radius with a pixel value defined by designTokens.cornerRadius.small.

***

## Fields

* [Checkout​And​Accounts​Configuration​Branding​Button.cornerRadius](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingButton#field-CheckoutAndAccountsConfigurationBrandingButton.fields.cornerRadius)

  OBJECT

  The buttons customizations.

* [Checkout​And​Accounts​Configuration​Branding​Button​Input.cornerRadius](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingButtonInput#fields-cornerRadius)

  INPUT OBJECT

  The input fields for customizing the buttons.

* [Checkout​And​Accounts​Configuration​Branding​Checkbox.cornerRadius](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingCheckbox#field-CheckoutAndAccountsConfigurationBrandingCheckbox.fields.cornerRadius)

  OBJECT

  The checkboxes customizations.

* [Checkout​And​Accounts​Configuration​Branding​Checkbox​Input.cornerRadius](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingCheckboxInput#fields-cornerRadius)

  INPUT OBJECT

  The input fields for customizing the checkboxes.

* [Checkout​And​Accounts​Configuration​Branding​Control.cornerRadius](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingControl#field-CheckoutAndAccountsConfigurationBrandingControl.fields.cornerRadius)

  OBJECT

  The form controls customizations.

* [Checkout​And​Accounts​Configuration​Branding​Control​Input.cornerRadius](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingControlInput#fields-cornerRadius)

  INPUT OBJECT

  The input fields for customizing the form controls.

* [Checkout​And​Accounts​Configuration​Branding​Customer​Accounts​Main​Section.cornerRadius](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingCustomerAccountsMainSection#field-CheckoutAndAccountsConfigurationBrandingCustomerAccountsMainSection.fields.cornerRadius)

  OBJECT

  The customer accounts branding section customizations.

* [Checkout​And​Accounts​Configuration​Branding​Customer​Accounts​Main​Section​Input.cornerRadius](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingCustomerAccountsMainSectionInput#fields-cornerRadius)

  INPUT OBJECT

  The input fields for customizing the customer accounts branding section.

* [Checkout​And​Accounts​Configuration​Branding​Express​Checkout​Button.cornerRadius](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingExpressCheckoutButton#field-CheckoutAndAccountsConfigurationBrandingExpressCheckoutButton.fields.cornerRadius)

  OBJECT

  The Express Checkout button customizations.

* [Checkout​And​Accounts​Configuration​Branding​Express​Checkout​Button​Input.cornerRadius](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingExpressCheckoutButtonInput#fields-cornerRadius)

  INPUT OBJECT

  The input fields for customizing the express checkout button.

* [Checkout​And​Accounts​Configuration​Branding​Main​Section.cornerRadius](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingMainSection#field-CheckoutAndAccountsConfigurationBrandingMainSection.fields.cornerRadius)

  OBJECT

  The main sections customizations.

* [Checkout​And​Accounts​Configuration​Branding​Main​Section​Input.cornerRadius](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingMainSectionInput#fields-cornerRadius)

  INPUT OBJECT

  The input fields for customizing the main sections.

* [Checkout​And​Accounts​Configuration​Branding​Merchandise​Thumbnail.cornerRadius](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingMerchandiseThumbnail#field-CheckoutAndAccountsConfigurationBrandingMerchandiseThumbnail.fields.cornerRadius)

  OBJECT

  The merchandise thumbnails customizations.

* [Checkout​And​Accounts​Configuration​Branding​Merchandise​Thumbnail​Input.cornerRadius](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingMerchandiseThumbnailInput#fields-cornerRadius)

  INPUT OBJECT

  The input fields for customizing the merchandise thumbnails.

* [Checkout​And​Accounts​Configuration​Branding​Order​Summary​Section.cornerRadius](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingOrderSummarySection#field-CheckoutAndAccountsConfigurationBrandingOrderSummarySection.fields.cornerRadius)

  OBJECT

  The order summary sections customizations.

* [Checkout​And​Accounts​Configuration​Branding​Order​Summary​Section​Input.cornerRadius](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingOrderSummarySectionInput#fields-cornerRadius)

  INPUT OBJECT

  The input fields for customizing the order summary sections.

***

## Map

### Fields with this enum

* [Checkout​And​Accounts​Configuration​Branding​Button.cornerRadius](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingButton#field-CheckoutAndAccountsConfigurationBrandingButton.fields.cornerRadius)
* [Checkout​And​Accounts​Configuration​Branding​Checkbox.cornerRadius](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingCheckbox#field-CheckoutAndAccountsConfigurationBrandingCheckbox.fields.cornerRadius)
* [Checkout​And​Accounts​Configuration​Branding​Control.cornerRadius](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingControl#field-CheckoutAndAccountsConfigurationBrandingControl.fields.cornerRadius)
* [Checkout​And​Accounts​Configuration​Branding​Customer​Accounts​Main​Section.cornerRadius](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingCustomerAccountsMainSection#field-CheckoutAndAccountsConfigurationBrandingCustomerAccountsMainSection.fields.cornerRadius)
* [Checkout​And​Accounts​Configuration​Branding​Express​Checkout​Button.cornerRadius](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingExpressCheckoutButton#field-CheckoutAndAccountsConfigurationBrandingExpressCheckoutButton.fields.cornerRadius)
* [Checkout​And​Accounts​Configuration​Branding​Main​Section.cornerRadius](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingMainSection#field-CheckoutAndAccountsConfigurationBrandingMainSection.fields.cornerRadius)
* [Checkout​And​Accounts​Configuration​Branding​Merchandise​Thumbnail.cornerRadius](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingMerchandiseThumbnail#field-CheckoutAndAccountsConfigurationBrandingMerchandiseThumbnail.fields.cornerRadius)
* [Checkout​And​Accounts​Configuration​Branding​Order​Summary​Section.cornerRadius](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingOrderSummarySection#field-CheckoutAndAccountsConfigurationBrandingOrderSummarySection.fields.cornerRadius)

### Inputs with this enum

* [Checkout​And​Accounts​Configuration​Branding​Button​Input.cornerRadius](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingButtonInput#fields-cornerRadius)
* [Checkout​And​Accounts​Configuration​Branding​Checkbox​Input.cornerRadius](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingCheckboxInput#fields-cornerRadius)
* [Checkout​And​Accounts​Configuration​Branding​Control​Input.cornerRadius](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingControlInput#fields-cornerRadius)
* [Checkout​And​Accounts​Configuration​Branding​Customer​Accounts​Main​Section​Input.cornerRadius](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingCustomerAccountsMainSectionInput#fields-cornerRadius)
* [Checkout​And​Accounts​Configuration​Branding​Express​Checkout​Button​Input.cornerRadius](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingExpressCheckoutButtonInput#fields-cornerRadius)
* [Checkout​And​Accounts​Configuration​Branding​Main​Section​Input.cornerRadius](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingMainSectionInput#fields-cornerRadius)
* [Checkout​And​Accounts​Configuration​Branding​Merchandise​Thumbnail​Input.cornerRadius](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingMerchandiseThumbnailInput#fields-cornerRadius)
* [Checkout​And​Accounts​Configuration​Branding​Order​Summary​Section​Input.cornerRadius](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingOrderSummarySectionInput#fields-cornerRadius)

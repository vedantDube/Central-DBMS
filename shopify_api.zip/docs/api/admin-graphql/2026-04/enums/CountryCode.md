---
title: CountryCode - GraphQL Admin
description: >-
  The code designating a country/region, which generally follows ISO 3166-1
  alpha-2 guidelines.

  If a territory doesn't have a country code value in the `CountryCode` enum,
  then it might be considered a subdivision

  of another country. For example, the territories associated with Spain are
  represented by the country code `ES`,

  and the territories associated with the United States of America are
  represented by the country code `US`.
api_version: 2026-04
source_url:
  html: 'https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CountryCode'
  md: 'https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CountryCode.md'
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Country​Code

enum

The code designating a country/region, which generally follows ISO 3166-1 alpha-2 guidelines. If a territory doesn't have a country code value in the `CountryCode` enum, then it might be considered a subdivision of another country. For example, the territories associated with Spain are represented by the country code `ES`, and the territories associated with the United States of America are represented by the country code `US`.

## Valid values

* AC

  Ascension Island.

* AD

  Andorra.

* AE

  United Arab Emirates.

* AF

  Afghanistan.

* AG

  Antigua & Barbuda.

* AI

  Anguilla.

* AL

  Albania.

* AM

  Armenia.

* AN

  Netherlands Antilles.

* AO

  Angola.

* AR

  Argentina.

* AT

  Austria.

* AU

  Australia.

* AW

  Aruba.

* AX

  Åland Islands.

* AZ

  Azerbaijan.

* BA

  Bosnia & Herzegovina.

* BB

  Barbados.

* BD

  Bangladesh.

* BE

  Belgium.

* BF

  Burkina Faso.

* BG

  Bulgaria.

* BH

  Bahrain.

* BI

  Burundi.

* BJ

  Benin.

* BL

  St. Barthélemy.

* BM

  Bermuda.

* BN

  Brunei.

* BO

  Bolivia.

* BQ

  Caribbean Netherlands.

* BR

  Brazil.

* BS

  Bahamas.

* BT

  Bhutan.

* BV

  Bouvet Island.

* BW

  Botswana.

* BY

  Belarus.

* BZ

  Belize.

* CA

  Canada.

* CC

  Cocos (Keeling) Islands.

* CD

  Congo - Kinshasa.

* CF

  Central African Republic.

* CG

  Congo - Brazzaville.

* CH

  Switzerland.

* CI

  Côte d’Ivoire.

* CK

  Cook Islands.

* CL

  Chile.

* CM

  Cameroon.

* CN

  China.

* CO

  Colombia.

* CR

  Costa Rica.

* CU

  Cuba.

* CV

  Cape Verde.

* CW

  Curaçao.

* CX

  Christmas Island.

* CY

  Cyprus.

* CZ

  Czechia.

* DE

  Germany.

* DJ

  Djibouti.

* DK

  Denmark.

* DM

  Dominica.

* DO

  Dominican Republic.

* DZ

  Algeria.

* EC

  Ecuador.

* EE

  Estonia.

* EG

  Egypt.

* EH

  Western Sahara.

* ER

  Eritrea.

* ES

  Spain.

* ET

  Ethiopia.

* FI

  Finland.

* FJ

  Fiji.

* FK

  Falkland Islands.

* FO

  Faroe Islands.

* FR

  France.

* GA

  Gabon.

* GB

  United Kingdom.

* GD

  Grenada.

* GE

  Georgia.

* GF

  French Guiana.

* GG

  Guernsey.

* GH

  Ghana.

* GI

  Gibraltar.

* GL

  Greenland.

* GM

  Gambia.

* GN

  Guinea.

* GP

  Guadeloupe.

* GQ

  Equatorial Guinea.

* GR

  Greece.

* GS

  South Georgia & South Sandwich Islands.

* GT

  Guatemala.

* GW

  Guinea-Bissau.

* GY

  Guyana.

* HK

  Hong Kong SAR.

* HM

  Heard & McDonald Islands.

* HN

  Honduras.

* HR

  Croatia.

* HT

  Haiti.

* HU

  Hungary.

* ID

  Indonesia.

* IE

  Ireland.

* IL

  Israel.

* IM

  Isle of Man.

* IN

  India.

* IO

  British Indian Ocean Territory.

* IQ

  Iraq.

* IR

  Iran.

* IS

  Iceland.

* IT

  Italy.

* JE

  Jersey.

* JM

  Jamaica.

* JO

  Jordan.

* JP

  Japan.

* KE

  Kenya.

* KG

  Kyrgyzstan.

* KH

  Cambodia.

* KI

  Kiribati.

* KM

  Comoros.

* KN

  St. Kitts & Nevis.

* KP

  North Korea.

* KR

  South Korea.

* KW

  Kuwait.

* KY

  Cayman Islands.

* KZ

  Kazakhstan.

* LA

  Laos.

* LB

  Lebanon.

* LC

  St. Lucia.

* LI

  Liechtenstein.

* LK

  Sri Lanka.

* LR

  Liberia.

* LS

  Lesotho.

* LT

  Lithuania.

* LU

  Luxembourg.

* LV

  Latvia.

* LY

  Libya.

* MA

  Morocco.

* MC

  Monaco.

* MD

  Moldova.

* ME

  Montenegro.

* MF

  St. Martin.

* MG

  Madagascar.

* MK

  North Macedonia.

* ML

  Mali.

* MM

  Myanmar (Burma).

* MN

  Mongolia.

* MO

  Macao SAR.

* MQ

  Martinique.

* MR

  Mauritania.

* MS

  Montserrat.

* MT

  Malta.

* MU

  Mauritius.

* MV

  Maldives.

* MW

  Malawi.

* MX

  Mexico.

* MY

  Malaysia.

* MZ

  Mozambique.

* NA

  Namibia.

* NC

  New Caledonia.

* NE

  Niger.

* NF

  Norfolk Island.

* NG

  Nigeria.

* NI

  Nicaragua.

* NL

  Netherlands.

* NO

  Norway.

* NP

  Nepal.

* NR

  Nauru.

* NU

  Niue.

* NZ

  New Zealand.

* OM

  Oman.

* PA

  Panama.

* PE

  Peru.

* PF

  French Polynesia.

* PG

  Papua New Guinea.

* PH

  Philippines.

* PK

  Pakistan.

* PL

  Poland.

* PM

  St. Pierre & Miquelon.

* PN

  Pitcairn Islands.

* PS

  Palestinian Territories.

* PT

  Portugal.

* PY

  Paraguay.

* QA

  Qatar.

* RE

  Réunion.

* RO

  Romania.

* RS

  Serbia.

* RU

  Russia.

* RW

  Rwanda.

* SA

  Saudi Arabia.

* SB

  Solomon Islands.

* SC

  Seychelles.

* SD

  Sudan.

* SE

  Sweden.

* SG

  Singapore.

* SH

  St. Helena.

* SI

  Slovenia.

* SJ

  Svalbard & Jan Mayen.

* SK

  Slovakia.

* SL

  Sierra Leone.

* SM

  San Marino.

* SN

  Senegal.

* SO

  Somalia.

* SR

  Suriname.

* SS

  South Sudan.

* ST

  São Tomé & Príncipe.

* SV

  El Salvador.

* SX

  Sint Maarten.

* SY

  Syria.

* SZ

  Eswatini.

* TA

  Tristan da Cunha.

* TC

  Turks & Caicos Islands.

* TD

  Chad.

* TF

  French Southern Territories.

* TG

  Togo.

* TH

  Thailand.

* TJ

  Tajikistan.

* TK

  Tokelau.

* TL

  Timor-Leste.

* TM

  Turkmenistan.

* TN

  Tunisia.

* TO

  Tonga.

* TR

  Türkiye.

* TT

  Trinidad & Tobago.

* TV

  Tuvalu.

* TW

  Taiwan.

* TZ

  Tanzania.

* UA

  Ukraine.

* UG

  Uganda.

* UM

  U.S. Outlying Islands.

* US

  United States.

* UY

  Uruguay.

* UZ

  Uzbekistan.

* VA

  Vatican City.

* VC

  St. Vincent & Grenadines.

* VE

  Venezuela.

* VG

  British Virgin Islands.

* VN

  Vietnam.

* VU

  Vanuatu.

* WF

  Wallis & Futuna.

* WS

  Samoa.

* XK

  Kosovo.

* YE

  Yemen.

* YT

  Mayotte.

* ZA

  South Africa.

* ZM

  Zambia.

* ZW

  Zimbabwe.

* ZZ

  Unknown Region.

***

## Fields

* [Backup​Region​Update​Input.countryCode](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/BackupRegionUpdateInput#fields-countryCode)

  INPUT OBJECT

  The input fields for updating a backup region with exactly one required option.

* [Business​Entity​Address.countryCode](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/BusinessEntityAddress#field-BusinessEntityAddress.fields.countryCode)

  OBJECT

  Represents the address of a merchant's Business Entity.

* [Buyer​Signal​Input.countryCode](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/BuyerSignalInput#fields-countryCode)

  INPUT OBJECT

  The input fields for a buyer signal.

* [Company​Address.countryCode](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CompanyAddress#field-CompanyAddress.fields.countryCode)

  OBJECT

  Represents a billing or shipping address for a company location.

* [Company​Address​Input.countryCode](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CompanyAddressInput#fields-countryCode)

  INPUT OBJECT

  The input fields to create or update the address of a company location.

* [Contextual​Pricing​Context.country](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/ContextualPricingContext#fields-country)

  INPUT OBJECT

  The input fields for the context data that determines the pricing of a variant. Refer to [Product](https://shopify.dev/docs/api/admin-graphql/latest/queries/product?example=Get+the+price+range+for+a+product+for+buyers+from+Canada)for more information on how to use this input object.

* [Contextual​Publication​Context.country](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/ContextualPublicationContext#fields-country)

  INPUT OBJECT

  The context data that determines the publication status of a product.

* [Countries​In​Shipping​Zones.countryCodes](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CountriesInShippingZones#field-CountriesInShippingZones.fields.countryCodes)

  OBJECT

  The list of all the countries from the combined shipping zones for the shop.

* [Country​Harmonized​System​Code.countryCode](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CountryHarmonizedSystemCode#field-CountryHarmonizedSystemCode.fields.countryCode)

  OBJECT

  The country-specific harmonized system code and ISO country code for an inventory item.

* [Country​Harmonized​System​Code​Input.countryCode](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CountryHarmonizedSystemCodeInput#fields-countryCode)

  INPUT OBJECT

  The input fields required to specify a harmonized system code.

* [Customer​Credit​Card​Billing​Address.countryCode](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CustomerCreditCardBillingAddress#field-CustomerCreditCardBillingAddress.fields.countryCode)

  OBJECT

  The billing address of a credit card payment instrument.

* [Customer​Payment​Instrument​Billing​Address.countryCode](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CustomerPaymentInstrumentBillingAddress#field-CustomerPaymentInstrumentBillingAddress.fields.countryCode)

  OBJECT

  The billing address of a payment instrument.

* [Delivery​Carrier​Service.availableServicesForCountries(countryCodes)](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/DeliveryCarrierService#field-DeliveryCarrierService.fields.availableServicesForCountries.arguments.countryCodes)

  ARGUMENT

  A carrier service (also known as a carrier calculated service or shipping service) provides real-time shipping rates to Shopify. Some common carrier services include Canada Post, FedEx, UPS, and USPS. The term **carrier** is often used interchangeably with the terms **shipping company** and **rate provider**.

  Using the CarrierService resource, you can add a carrier service to a shop and then provide a list of applicable shipping rates at checkout. You can even use the cart data to adjust shipping rates and offer shipping discounts based on what is in the customer's cart.

  ## Requirements for accessing the CarrierService resource

  To access the CarrierService resource, add the `write_shipping` permission to your app's requested scopes. For more information, see [API access scopes](https://shopify.dev/docs/admin-api/access-scopes).

  Your app's request to create a carrier service will fail unless the store installing your carrier service meets one of the following requirements:

  * It's on the Advanced Shopify plan or higher.
  * It's on the Shopify plan with yearly billing, or the carrier service feature has been added to the store for a monthly fee. For more information, contact [Shopify Support](https://help.shopify.com/questions).
  * It's a development store.

  ***

  **Note:** If a store changes its Shopify plan, then the store\&#39;s association with a carrier service is deactivated if the store no long meets one of the requirements above.

  ***

  ## Providing shipping rates to Shopify

  When adding a carrier service to a store, you need to provide a POST endpoint rooted in the `callbackUrl` property where Shopify can retrieve applicable shipping rates. The callback URL should be a public endpoint that expects these requests from Shopify.

  ### Example shipping rate request sent to a carrier service

  ```json
  {
  "rate": {
  "origin": {
  "country": "CA",
  "postal_code": "K2P1L4",
  "province": "ON",
  "city": "Ottawa",
  "name": null,
  "address1": "150 Elgin St.",
  "address2": "",
  "address3": null,
  "phone": null,
  "fax": null,
  "email": null,
  "address_type": null,
  "company_name": "Jamie D's Emporium"
  },
  "destination": {
  "country": "CA",
  "postal_code": "K1M1M4",
  "province": "ON",
  "city": "Ottawa",
  "name": "Bob Norman",
  "address1": "24 Sussex Dr.",
  "address2": "",
  "address3": null,
  "phone": null,
  "fax": null,
  "email": null,
  "address_type": null,
  "company_name": null
  },
  "items": [{
  "name": "Short Sleeve T-Shirt",
  "sku": "",
  "quantity": 1,
  "grams": 1000,
  "price": 1999,
  "vendor": "Jamie D's Emporium",
  "requires_shipping": true,
  "taxable": true,
  "fulfillment_service": "manual",
  "properties": null,
  "product_id": 48447225880,
  "variant_id": 258644705304
  }],
  "currency": "USD",
  "locale": "en",
  "order_totals": {
  "subtotal_price": "1999",
  "total_price": "2199",
  "discount_amount": "150"
  },
  "customer": {
  "id": 207119551,
  "tags": ["VIP", "wholesale"]
  }
  }
  }
  ```

  ### Example response

  ```json
  {
  "rates": [
  {
  "service_name": "canadapost-overnight",
  "service_code": "ON",
  "total_price": "1295",
  "description": "This is the fastest option by far",
  "currency": "CAD",
  "min_delivery_date": "2013-04-12 14:48:45 -0400",
  "max_delivery_date": "2013-04-12 14:48:45 -0400"
  },
  {
  "service_name": "fedex-2dayground",
  "service_code": "2D",
  "total_price": "2934",
  "currency": "USD",
  "min_delivery_date": "2013-04-12 14:48:45 -0400",
  "max_delivery_date": "2013-04-12 14:48:45 -0400"
  },
  {
  "service_name": "fedex-priorityovernight",
  "service_code": "1D",
  "total_price": "3587",
  "currency": "USD",
  "min_delivery_date": "2013-04-12 14:48:45 -0400",
  "max_delivery_date": "2013-04-12 14:48:45 -0400",
  "metafields": [
  {
  "key": "tracking_url",
  "value": "abc123",
  "namespace": "carrier_service_metadata",
  "type": "single_line_text_field"
  }
  ]
  }
  ]
  }
  ```

  The `address3`, `fax`, `address_type`, and `company_name` fields are returned by specific [ActiveShipping](https://github.com/Shopify/active_shipping) providers. For API-created carrier services, you should use only the following shipping address fields:

  * `address1`
  * `address2`
  * `city`
  * `zip`
  * `province`
  * `country`

  Other values remain as `null` and are not sent to the callback URL.

  ### Response fields

  When Shopify requests shipping rates using your callback URL, the response object `rates` must be a JSON array of objects with the following fields. Required fields must be included in the response for the carrier service integration to work properly.

  \| Field | Required | Description

  \| | ----------------------- | -------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | | `service_name` | Yes | The name of the rate, which customers see at checkout. For example: `Expedited Mail`. | | `description` | Yes | A description of the rate, which customers see at checkout. For example: `Includes tracking and insurance`. | | `service_code` | Yes | A unique code associated with the rate that must be consistent across requests. For example: `expedited_mail`. | | `currency` | Yes | The currency of the shipping rate.

  \| | `total_price` | Yes | The total price expressed in subunits. If the currency doesn't use subunits, then the value must be multiplied by 100. For example: `"total_price": 500` for 5.00 CAD, `"total_price": 100000` for 1000 JPY. | | `phone_required` | No | Whether the customer must provide a phone number at checkout. | | `min_delivery_date` | No | The earliest delivery date for the displayed rate. | | `max_delivery_date` | No | The latest delivery date for the displayed rate to still be valid. | | `metafields` | No | An array of metafield objects to attach custom metadata to the shipping rate. |

  ### Special conditions

  * To indicate that this carrier service cannot handle this shipping request, return an empty array and any successful (20x) HTTP code.
  * To force backup rates instead, return a 40x or 50x HTTP code with any content. A good choice is the regular 404 Not Found code.
  * Redirects (30x codes) will only be followed for the same domain as the original callback URL. Attempting to redirect to a different domain will trigger backup rates.
  * There is no retry mechanism. The response must be successful on the first try, within the time budget listed below. Timeouts or errors will trigger backup rates.
  * The `service_code` must be stable and consistent across requests for the same shipping option. It should not contain dynamic values like session IDs, timestamps, or request-specific identifiers. Use metafields for passing dynamic or session-specific data.

  ## Response Timeouts

  The read timeout for rate requests are dynamic, based on the number of requests per minute (RPM). These limits are applied to each shop-app pair. The timeout values are as follows.

  | RPM Range | Timeout |
  | - | - |
  | Under 1500 | 10s |
  | 1500 to 3000 | 5s |
  | Over 3000 | 3s |

  ***

  **Note:** These values are upper limits and should not be interpretted as a goal to develop towards. Shopify is constantly evaluating the performance of the platform and working towards improving resilience as well as app capabilities. As such, these numbers may be adjusted outside of our normal versioning timelines.

  ***

  ## Server-side caching of requests

  Shopify provides server-side caching to reduce the number of requests it makes. Any shipping rate request that identically matches the following fields will be retrieved from Shopify's cache of the initial response:

  * variant IDs
  * default shipping box weight and dimensions
  * variant quantities
  * carrier service ID
  * origin address
  * destination address
  * item weights and signatures

  If any of these fields differ, or if the cache has expired since the original request, then new shipping rates are requested. The cache expires 15 minutes after rates are successfully returned. If an error occurs, then the cache expires after 30 seconds.

* [Delivery​Country​Code​Or​Rest​Of​World.countryCode](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/DeliveryCountryCodeOrRestOfWorld#field-DeliveryCountryCodeOrRestOfWorld.fields.countryCode)

  OBJECT

  The country code and whether the country is a part of the 'Rest Of World' shipping zone.

* [Delivery​Country​Codes​Or​Rest​Of​World.countryCodes](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/DeliveryCountryCodesOrRestOfWorld#field-DeliveryCountryCodesOrRestOfWorld.fields.countryCodes)

  OBJECT

  The list of country codes and information whether the countries are a part of the 'Rest Of World' shipping zone.

* [Delivery​Country​Input.code](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/DeliveryCountryInput#fields-code)

  INPUT OBJECT

  The input fields to specify a country.

* [Discount​Countries.countries](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/DiscountCountries#field-DiscountCountries.fields.countries)

  OBJECT

  Defines the geographic scope where a shipping discount can be applied based on customer shipping destinations. This configuration determines which countries are eligible for the promotional offer.

  For example, a "Free Shipping to EU" promotion would specify European Union countries, while a domestic-only sale might target just the store's home country.

  The object includes both specific country selections and an option to include all remaining countries not explicitly listed, providing flexible geographic targeting for international merchants.

* [Discount​Countries​Input.add](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/DiscountCountriesInput#fields-add)

  INPUT OBJECT

  The input fields for a list of countries to add or remove from the free shipping discount.

* [Discount​Countries​Input.remove](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/DiscountCountriesInput#fields-remove)

  INPUT OBJECT

  The input fields for a list of countries to add or remove from the free shipping discount.

* [Draft​Order.localizationExtensions(countryCodes)](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/DraftOrder#field-DraftOrder.fields.localizationExtensions.arguments.countryCodes)

  ARGUMENT

  An order that a merchant creates on behalf of a customer. Draft orders are useful for merchants that need to do the following tasks:

  * Create new orders for sales made by phone, in person, by chat, or elsewhere. When a merchant accepts payment for a draft order, an order is created.
  * Send invoices to customers to pay with a secure checkout link.
  * Use custom items to represent additional costs or products that aren't displayed in a shop's inventory.
  * Re-create orders manually from active sales channels.
  * Sell products at discount or wholesale rates.
  * Take pre-orders.

  For draft orders in multiple currencies `presentment_money` is the source of truth for what a customer is going to be charged and `shop_money` is an estimate of what the merchant might receive in their shop currency.

  **Caution:** Only use this data if it's required for your app's functionality. Shopify will restrict [access to scopes](https://shopify.dev/api/usage/access-scopes) for apps that don't have a legitimate use for the associated data.

  Draft orders created on or after April 1, 2025 will be automatically purged after one year of inactivity.

* [Draft​Order.localizedFields(countryCodes)](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/DraftOrder#field-DraftOrder.fields.localizedFields.arguments.countryCodes)

  ARGUMENT

  An order that a merchant creates on behalf of a customer. Draft orders are useful for merchants that need to do the following tasks:

  * Create new orders for sales made by phone, in person, by chat, or elsewhere. When a merchant accepts payment for a draft order, an order is created.
  * Send invoices to customers to pay with a secure checkout link.
  * Use custom items to represent additional costs or products that aren't displayed in a shop's inventory.
  * Re-create orders manually from active sales channels.
  * Sell products at discount or wholesale rates.
  * Take pre-orders.

  For draft orders in multiple currencies `presentment_money` is the source of truth for what a customer is going to be charged and `shop_money` is an estimate of what the merchant might receive in their shop currency.

  **Caution:** Only use this data if it's required for your app's functionality. Shopify will restrict [access to scopes](https://shopify.dev/api/usage/access-scopes) for apps that don't have a legitimate use for the associated data.

  Draft orders created on or after April 1, 2025 will be automatically purged after one year of inactivity.

* [Draft​Order​Available​Delivery​Options​Input.marketRegionCountryCode](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/DraftOrderAvailableDeliveryOptionsInput#fields-marketRegionCountryCode)

  INPUT OBJECT

  The input fields used to determine available delivery options for a draft order.

* [Draft​Order​Input.marketRegionCountryCode](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/DraftOrderInput#fields-marketRegionCountryCode)

  INPUT OBJECT

  The input fields used to create or update a draft order.

* [Duty.countryCodeOfOrigin](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/Duty#field-Duty.fields.countryCodeOfOrigin)

  OBJECT

  The duty details for a line item.

* [Fulfillment​Order​Assigned​Location.countryCode](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/FulfillmentOrderAssignedLocation#field-FulfillmentOrderAssignedLocation.fields.countryCode)

  OBJECT

  The fulfillment order's assigned location. This is the location where the fulfillment is expected to happen.

  The fulfillment order's assigned location might change in the following cases:

  * The fulfillment order has been entirely moved to a new location. For example, the [fulfillmentOrderMove](https://shopify.dev/api/admin-graphql/latest/mutations/fulfillmentOrderMove) mutation has been called, and you see the original fulfillment order in the [movedFulfillmentOrder](https://shopify.dev/api/admin-graphql/latest/mutations/fulfillmentOrderMove#field-fulfillmentordermovepayload-movedfulfillmentorder) field within the mutation's response.

  * Work on the fulfillment order has not yet begun, which means that the fulfillment order has the [OPEN](https://shopify.dev/api/admin-graphql/latest/enums/FulfillmentOrderStatus#value-open), [SCHEDULED](https://shopify.dev/api/admin-graphql/latest/enums/FulfillmentOrderStatus#value-scheduled), or [ON\_HOLD](https://shopify.dev/api/admin-graphql/latest/enums/FulfillmentOrderStatus#value-onhold) status, and the shop's location properties might be undergoing edits (for example, in the Shopify admin).

  If the [fulfillmentOrderMove](https://shopify.dev/api/admin-graphql/latest/mutations/fulfillmentOrderMove) mutation has moved the fulfillment order's line items to a new location, but hasn't moved the fulfillment order instance itself, then the original fulfillment order's assigned location doesn't change. This happens if the fulfillment order is being split during the move, or if all line items can be moved to an existing fulfillment order at a new location.

  Once the fulfillment order has been taken into work or canceled, which means that the fulfillment order has the [IN\_PROGRESS](https://shopify.dev/api/admin-graphql/latest/enums/FulfillmentOrderStatus#value-inprogress), [CLOSED](https://shopify.dev/api/admin-graphql/latest/enums/FulfillmentOrderStatus#value-closed), [CANCELLED](https://shopify.dev/api/admin-graphql/latest/enums/FulfillmentOrderStatus#value-cancelled), or [INCOMPLETE](https://shopify.dev/api/admin-graphql/latest/enums/FulfillmentOrderStatus#value-incomplete) status, `FulfillmentOrderAssignedLocation` acts as a snapshot of the shop's location content. Up-to-date shop's location data may be queried through [location](https://shopify.dev/api/admin-graphql/latest/objects/FulfillmentOrderAssignedLocation#field-fulfillmentorderassignedlocation-location) connection.

* [Fulfillment​Order​Destination.countryCode](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/FulfillmentOrderDestination#field-FulfillmentOrderDestination.fields.countryCode)

  OBJECT

  Represents the destination where the items should be sent upon fulfillment.

* [Full​Sync​Trace​Info.country](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/FullSyncTraceInfo#field-FullSyncTraceInfo.fields.country)

  OBJECT

  Trace information for a single country-language product feed sync triggered by [`channelFullSync`](https://shopify.dev/docs/api/admin-graphql/latest/mutations/channelFullSync).

* [Has​Localization​Extensions.localizationExtensions(countryCodes)](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/HasLocalizationExtensions#field-HasLocalizationExtensions.fields.localizationExtensions.arguments.countryCodes)

  ARGUMENT

  Localization extensions associated with the specified resource. For example, the tax id for government invoice.

* [Has​Localized​Fields.localizedFields(countryCodes)](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/HasLocalizedFields#field-HasLocalizedFields.fields.localizedFields.arguments.countryCodes)

  ARGUMENT

  Localized fields associated with the specified resource.

* [Inventory​Item.countryCodeOfOrigin](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/InventoryItem#field-InventoryItem.fields.countryCodeOfOrigin)

  OBJECT

  A [product variant's](https://shopify.dev/docs/api/admin-graphql/latest/objects/ProductVariant) inventory information across all locations. The inventory item connects the product variant to its [inventory levels](https://shopify.dev/docs/api/admin-graphql/latest/objects/InventoryLevel) at different locations, tracking stock keeping unit (SKU), whether quantities are tracked, shipping requirements, and customs information for the product.

  Learn more about [inventory object relationships](https://shopify.dev/docs/apps/build/orders-fulfillment/inventory-management-apps/manage-quantities-states#inventory-object-relationships).

* [Inventory​Item​Input.countryCodeOfOrigin](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/InventoryItemInput#fields-countryCodeOfOrigin)

  INPUT OBJECT

  The input fields for an inventory item.

* [Localization​Extension.countryCode](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/LocalizationExtension#field-LocalizationExtension.fields.countryCode)

  OBJECT

  Represents the value captured by a localization extension. Localization extensions are additional fields required by certain countries on international orders. For example, some countries require additional fields for customs information or tax identification numbers.

* [Localized​Field.countryCode](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/LocalizedField#field-LocalizedField.fields.countryCode)

  OBJECT

  Represents the value captured by a localized field. Localized fields are additional fields required by certain countries on international orders. For example, some countries require additional fields for customs information or tax identification numbers.

* [Location​Add​Address​Input.countryCode](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/LocationAddAddressInput#fields-countryCode)

  INPUT OBJECT

  The input fields to use to specify the address while adding a location.

* [Location​Edit​Address​Input.countryCode](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/LocationEditAddressInput#fields-countryCode)

  INPUT OBJECT

  The input fields to use to edit the address of a location.

* [Location​Suggested​Address.countryCode](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/LocationSuggestedAddress#field-LocationSuggestedAddress.fields.countryCode)

  OBJECT

  Represents a suggested address for a location.

* [Mailing​Address.countryCodeV2](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/MailingAddress#field-MailingAddress.fields.countryCodeV2)

  OBJECT

  A physical mailing address. For example, a [`Customer`](https://shopify.dev/docs/api/admin-graphql/latest/objects/Customer)'s default address and an [`Order`](https://shopify.dev/docs/api/admin-graphql/latest/objects/Order)'s billing address are both mailing addresses. Stores standard address components, customer name information, and company details.

  The address includes geographic coordinates ([`latitude`](https://shopify.dev/docs/api/admin-graphql/latest/objects/MailingAddress#field-MailingAddress.fields.latitude) and [`longitude`](https://shopify.dev/docs/api/admin-graphql/latest/objects/MailingAddress#field-MailingAddress.fields.longitude)). You can format addresses for display using the [`formatted`](https://shopify.dev/docs/api/admin-graphql/latest/objects/MailingAddress#field-MailingAddress.fields.formatted) field with options to include or exclude name and company information.

* [Mailing​Address​Input.countryCode](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/MailingAddressInput#fields-countryCode)

  INPUT OBJECT

  The input fields to create or update a mailing address.

* [Market​Conditions​Region​Input.countryCode](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/MarketConditionsRegionInput#fields-countryCode)

  INPUT OBJECT

  The input fields to specify a region condition.

* [Market​Region​Country.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/MarketRegionCountry#field-MarketRegionCountry.fields.code)

  OBJECT

  A country which comprises a market.

* [Market​Region​Create​Input.countryCode](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/MarketRegionCreateInput#fields-countryCode)

  INPUT OBJECT

  The input fields for creating a market region with exactly one required option.

* [Order.localizationExtensions(countryCodes)](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/Order#field-Order.fields.localizationExtensions.arguments.countryCodes)

  ARGUMENT

  The `Order` object represents a customer's request to purchase one or more products from a store. Use the `Order` object to handle the complete purchase lifecycle from checkout to fulfillment.

  Use the `Order` object when you need to:

  * Display order details on customer account pages or admin dashboards.
  * Create orders for phone sales, wholesale customers, or subscription services.
  * Update order information like shipping addresses, notes, or fulfillment status.
  * Process returns, exchanges, and partial refunds.
  * Generate invoices, receipts, and shipping labels.

  The `Order` object serves as the central hub connecting customer information, product details, payment processing, and fulfillment data within the GraphQL Admin API schema.

  ***

  **Note:** Only the last 60 days\&#39; worth of orders from a store are accessible from the \<code>Order\</code> object by default. If you want to access older records, then you need to \<a href="https://shopify.dev/docs/api/usage/access-scopes#orders-permissions">request access to all orders\</a>. If your app is granted access, then you can add the \<code>\<span class="PreventFireFoxApplyingGapToWBR">read\<wbr/>\_all\<wbr/>\_orders\</span>\</code>, \<code>\<span class="PreventFireFoxApplyingGapToWBR">read\<wbr/>\_orders\</span>\</code>, and \<code>\<span class="PreventFireFoxApplyingGapToWBR">write\<wbr/>\_orders\</span>\</code> scopes.

  ***

  ***

  **Caution:** Only use orders data if it\&#39;s required for your app\&#39;s functionality. Shopify will restrict \<a href="https://shopify.dev/docs/api/usage/access-scopes#requesting-specific-permissions">access to scopes\</a> for apps that don\&#39;t have a legitimate use for the associated data.

  ***

  Learn more about [building apps for orders and fulfillment](https://shopify.dev/docs/apps/build/orders-fulfillment).

* [Order.localizedFields(countryCodes)](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/Order#field-Order.fields.localizedFields.arguments.countryCodes)

  ARGUMENT

  The `Order` object represents a customer's request to purchase one or more products from a store. Use the `Order` object to handle the complete purchase lifecycle from checkout to fulfillment.

  Use the `Order` object when you need to:

  * Display order details on customer account pages or admin dashboards.
  * Create orders for phone sales, wholesale customers, or subscription services.
  * Update order information like shipping addresses, notes, or fulfillment status.
  * Process returns, exchanges, and partial refunds.
  * Generate invoices, receipts, and shipping labels.

  The `Order` object serves as the central hub connecting customer information, product details, payment processing, and fulfillment data within the GraphQL Admin API schema.

  ***

  **Note:** Only the last 60 days\&#39; worth of orders from a store are accessible from the \<code>Order\</code> object by default. If you want to access older records, then you need to \<a href="https://shopify.dev/docs/api/usage/access-scopes#orders-permissions">request access to all orders\</a>. If your app is granted access, then you can add the \<code>\<span class="PreventFireFoxApplyingGapToWBR">read\<wbr/>\_all\<wbr/>\_orders\</span>\</code>, \<code>\<span class="PreventFireFoxApplyingGapToWBR">read\<wbr/>\_orders\</span>\</code>, and \<code>\<span class="PreventFireFoxApplyingGapToWBR">write\<wbr/>\_orders\</span>\</code> scopes.

  ***

  ***

  **Caution:** Only use orders data if it\&#39;s required for your app\&#39;s functionality. Shopify will restrict \<a href="https://shopify.dev/docs/api/usage/access-scopes#requesting-specific-permissions">access to scopes\</a> for apps that don\&#39;t have a legitimate use for the associated data.

  ***

  Learn more about [building apps for orders and fulfillment](https://shopify.dev/docs/apps/build/orders-fulfillment).

* [Price​Rule​Shipping​Line​Entitlements.countryCodes](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/PriceRuleShippingLineEntitlements#field-PriceRuleShippingLineEntitlements.fields.countryCodes)

  OBJECT

  The shipping lines to which the price rule applies to.

* [Product​Feed.country](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/ProductFeed#field-ProductFeed.fields.country)

  OBJECT

  A product feed.

* [Product​Feed​Input.country](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/ProductFeedInput#fields-country)

  INPUT OBJECT

  The input fields required to create a product feed.

* [Shop.shipsToCountries](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/Shop#field-Shop.fields.shipsToCountries)

  OBJECT

  The central configuration and settings hub for a Shopify store. Access business information, operational preferences, feature availability, and store-wide settings that control how the shop operates.

  Includes core business details like the shop name, contact emails, billing address, and currency settings. The shop configuration determines customer account requirements, available sales channels, enabled features, payment settings, and policy documents. Also provides access to shop-level resources such as staff members, fulfillment services, navigation settings, and storefront access tokens.

* [Shop​Address.countryCodeV2](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/ShopAddress#field-ShopAddress.fields.countryCodeV2)

  OBJECT

  An address for a shop.

* [Shopify​Payments​Bank​Account.country](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/ShopifyPaymentsBankAccount#field-ShopifyPaymentsBankAccount.fields.country)

  OBJECT

  A bank account that can receive payouts.

* [Query​Root.marketByGeography(countryCode)](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/QueryRoot#field-QueryRoot.fields.marketByGeography.arguments.countryCode)

  ARGUMENT

  The schema's entry-point for queries. This acts as the public, top-level API from which all queries must start.

* [channel​Full​Sync.country](https://shopify.dev/docs/api/admin-graphql/2026-04/mutations/channelFullSync#arguments-country)

  ARGUMENT

* [market​By​Geography.countryCode](https://shopify.dev/docs/api/admin-graphql/2026-04/queries/marketByGeography#arguments-countryCode)

  ARGUMENT

### Deprecated fields

* [Calculated​Draft​Order.marketRegionCountryCode](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CalculatedDraftOrder#field-CalculatedDraftOrder.fields.marketRegionCountryCode)

  OBJECT

  Deprecated

* [Draft​Order.marketRegionCountryCode](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/DraftOrder#field-DraftOrder.fields.marketRegionCountryCode)

  OBJECT

  Deprecated

***

## Map

### Fields with this enum

* [Business​Entity​Address.countryCode](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/BusinessEntityAddress#field-BusinessEntityAddress.fields.countryCode)
* [Company​Address.countryCode](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CompanyAddress#field-CompanyAddress.fields.countryCode)
* [Countries​In​Shipping​Zones.countryCodes](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CountriesInShippingZones#field-CountriesInShippingZones.fields.countryCodes)
* [Country​Harmonized​System​Code.countryCode](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CountryHarmonizedSystemCode#field-CountryHarmonizedSystemCode.fields.countryCode)
* [Customer​Credit​Card​Billing​Address.countryCode](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CustomerCreditCardBillingAddress#field-CustomerCreditCardBillingAddress.fields.countryCode)
* [Customer​Payment​Instrument​Billing​Address.countryCode](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CustomerPaymentInstrumentBillingAddress#field-CustomerPaymentInstrumentBillingAddress.fields.countryCode)
* [Delivery​Country​Code​Or​Rest​Of​World.countryCode](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/DeliveryCountryCodeOrRestOfWorld#field-DeliveryCountryCodeOrRestOfWorld.fields.countryCode)
* [Delivery​Country​Codes​Or​Rest​Of​World.countryCodes](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/DeliveryCountryCodesOrRestOfWorld#field-DeliveryCountryCodesOrRestOfWorld.fields.countryCodes)
* [Discount​Countries.countries](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/DiscountCountries#field-DiscountCountries.fields.countries)
* [Duty.countryCodeOfOrigin](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/Duty#field-Duty.fields.countryCodeOfOrigin)
* [Fulfillment​Order​Assigned​Location.countryCode](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/FulfillmentOrderAssignedLocation#field-FulfillmentOrderAssignedLocation.fields.countryCode)
* [Fulfillment​Order​Destination.countryCode](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/FulfillmentOrderDestination#field-FulfillmentOrderDestination.fields.countryCode)
* [Full​Sync​Trace​Info.country](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/FullSyncTraceInfo#field-FullSyncTraceInfo.fields.country)
* [Inventory​Item.countryCodeOfOrigin](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/InventoryItem#field-InventoryItem.fields.countryCodeOfOrigin)
* [Localization​Extension.countryCode](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/LocalizationExtension#field-LocalizationExtension.fields.countryCode)
* [Localized​Field.countryCode](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/LocalizedField#field-LocalizedField.fields.countryCode)
* [Location​Suggested​Address.countryCode](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/LocationSuggestedAddress#field-LocationSuggestedAddress.fields.countryCode)
* [Mailing​Address.countryCodeV2](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/MailingAddress#field-MailingAddress.fields.countryCodeV2)
* [Market​Region​Country.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/MarketRegionCountry#field-MarketRegionCountry.fields.code)
* [Price​Rule​Shipping​Line​Entitlements.countryCodes](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/PriceRuleShippingLineEntitlements#field-PriceRuleShippingLineEntitlements.fields.countryCodes)
* [Product​Feed.country](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/ProductFeed#field-ProductFeed.fields.country)
* [Shop.shipsToCountries](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/Shop#field-Shop.fields.shipsToCountries)
* [Shop​Address.countryCodeV2](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/ShopAddress#field-ShopAddress.fields.countryCodeV2)
* [Shopify​Payments​Bank​Account.country](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/ShopifyPaymentsBankAccount#field-ShopifyPaymentsBankAccount.fields.country)

### Inputs with this enum

* [Backup​Region​Update​Input.countryCode](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/BackupRegionUpdateInput#fields-countryCode)
* [Buyer​Signal​Input.countryCode](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/BuyerSignalInput#fields-countryCode)
* [Company​Address​Input.countryCode](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CompanyAddressInput#fields-countryCode)
* [Contextual​Pricing​Context.country](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/ContextualPricingContext#fields-country)
* [Contextual​Publication​Context.country](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/ContextualPublicationContext#fields-country)
* [Country​Harmonized​System​Code​Input.countryCode](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CountryHarmonizedSystemCodeInput#fields-countryCode)
* [Delivery​Country​Input.code](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/DeliveryCountryInput#fields-code)
* [Discount​Countries​Input.add](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/DiscountCountriesInput#fields-add)
* [Discount​Countries​Input.remove](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/DiscountCountriesInput#fields-remove)
* [Draft​Order​Available​Delivery​Options​Input.marketRegionCountryCode](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/DraftOrderAvailableDeliveryOptionsInput#fields-marketRegionCountryCode)
* [Draft​Order​Input.marketRegionCountryCode](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/DraftOrderInput#fields-marketRegionCountryCode)
* [Inventory​Item​Input.countryCodeOfOrigin](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/InventoryItemInput#fields-countryCodeOfOrigin)
* [Location​Add​Address​Input.countryCode](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/LocationAddAddressInput#fields-countryCode)
* [Location​Edit​Address​Input.countryCode](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/LocationEditAddressInput#fields-countryCode)
* [Mailing​Address​Input.countryCode](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/MailingAddressInput#fields-countryCode)
* [Market​Conditions​Region​Input.countryCode](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/MarketConditionsRegionInput#fields-countryCode)
* [Market​Region​Create​Input.countryCode](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/MarketRegionCreateInput#fields-countryCode)
* [Product​Feed​Input.country](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/ProductFeedInput#fields-country)

### Arguments with this enum

* [Delivery​Carrier​Service.availableServicesForCountries(countryCodes)](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/DeliveryCarrierService#field-DeliveryCarrierService.fields.availableServicesForCountries.arguments.countryCodes)
* [Draft​Order.localizationExtensions(countryCodes)](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/DraftOrder#field-DraftOrder.fields.localizationExtensions.arguments.countryCodes)
* [Draft​Order.localizedFields(countryCodes)](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/DraftOrder#field-DraftOrder.fields.localizedFields.arguments.countryCodes)
* [Has​Localization​Extensions.localizationExtensions(countryCodes)](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/HasLocalizationExtensions#field-HasLocalizationExtensions.fields.localizationExtensions.arguments.countryCodes)
* [Has​Localized​Fields.localizedFields(countryCodes)](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/HasLocalizedFields#field-HasLocalizedFields.fields.localizedFields.arguments.countryCodes)
* [Order.localizationExtensions(countryCodes)](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/Order#field-Order.fields.localizationExtensions.arguments.countryCodes)
* [Order.localizedFields(countryCodes)](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/Order#field-Order.fields.localizedFields.arguments.countryCodes)
* [Query​Root.marketByGeography(countryCode)](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/QueryRoot#field-QueryRoot.fields.marketByGeography.arguments.countryCode)
* [channel​Full​Sync.country](https://shopify.dev/docs/api/admin-graphql/2026-04/mutations/channelFullSync#arguments-country)
* [market​By​Geography.countryCode](https://shopify.dev/docs/api/admin-graphql/2026-04/queries/marketByGeography#arguments-countryCode)

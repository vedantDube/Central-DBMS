---
title: >-
  CheckoutAndAccountsConfigurationBrandingMerchandiseThumbnailBadgeBackground -
  GraphQL Admin
description: The merchandise thumbnail badge background.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutAndAccountsConfigurationBrandingMerchandiseThumbnailBadgeBackground
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutAndAccountsConfigurationBrandingMerchandiseThumbnailBadgeBackground.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Checkout​And​Accounts​Configuration​Branding​Merchandise​Thumbnail​Badge​Background

enum

The merchandise thumbnail badge background.

## Valid values

* ACCENT

  The Accent background.

* BASE

  The Base background.

***

## Fields

* [Checkout​And​Accounts​Configuration​Branding​Merchandise​Thumbnail​Badge.background](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingMerchandiseThumbnailBadge#field-CheckoutAndAccountsConfigurationBrandingMerchandiseThumbnailBadge.fields.background)

  OBJECT

  The merchandise thumbnail badges customizations.

* [Checkout​And​Accounts​Configuration​Branding​Merchandise​Thumbnail​Badge​Input.background](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingMerchandiseThumbnailBadgeInput#fields-background)

  INPUT OBJECT

  The input fields for customizing the merchandise thumbnail badges.

***

## Map

### Fields with this enum

* [Checkout​And​Accounts​Configuration​Branding​Merchandise​Thumbnail​Badge.background](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingMerchandiseThumbnailBadge#field-CheckoutAndAccountsConfigurationBrandingMerchandiseThumbnailBadge.fields.background)

### Inputs with this enum

* [Checkout​And​Accounts​Configuration​Branding​Merchandise​Thumbnail​Badge​Input.background](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingMerchandiseThumbnailBadgeInput#fields-background)

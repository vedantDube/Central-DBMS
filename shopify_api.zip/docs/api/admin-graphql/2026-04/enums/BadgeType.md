---
title: BadgeType - GraphQL Admin
description: The possible types for a badge.
api_version: 2026-04
source_url:
  html: 'https://shopify.dev/docs/api/admin-graphql/2026-04/enums/BadgeType'
  md: 'https://shopify.dev/docs/api/admin-graphql/2026-04/enums/BadgeType.md'
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Badge​Type

enum

The possible types for a badge.

## Valid values

* ATTENTION

  This badge has type `attention`.

* CRITICAL

  This badge has type `critical`.

* DEFAULT

  This badge has type `default`.

* INFO

  This badge has type `info`.

* SUCCESS

  This badge has type `success`.

* WARNING

  This badge has type `warning`.

***

## Fields

* [Marketing​Activity.statusBadgeTypeV2](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/MarketingActivity#field-MarketingActivity.fields.statusBadgeTypeV2)

  OBJECT

  The marketing activity resource represents marketing that a merchant created through an app.

***

## Map

### Fields with this enum

* [Marketing​Activity.statusBadgeTypeV2](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/MarketingActivity#field-MarketingActivity.fields.statusBadgeTypeV2)

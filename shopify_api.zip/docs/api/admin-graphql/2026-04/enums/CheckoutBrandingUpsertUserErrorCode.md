---
title: CheckoutBrandingUpsertUserErrorCode - GraphQL Admin
description: >-
  Possible error codes that can be returned by
  `CheckoutBrandingUpsertUserError`.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutBrandingUpsertUserErrorCode
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutBrandingUpsertUserErrorCode.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Checkout​Branding​Upsert​User​Error​Code

enum

Possible error codes that can be returned by `CheckoutBrandingUpsertUserError`.

## Valid values

* INTERNAL\_​ERROR

  Unexpected internal error happened.

***

## Fields

* [Checkout​Branding​Upsert​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutBrandingUpsertUserError#field-CheckoutBrandingUpsertUserError.fields.code)

  OBJECT

  An error that occurs during the execution of `CheckoutBrandingUpsert`.

***

## Map

### Fields with this enum

* [Checkout​Branding​Upsert​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutBrandingUpsertUserError#field-CheckoutBrandingUpsertUserError.fields.code)

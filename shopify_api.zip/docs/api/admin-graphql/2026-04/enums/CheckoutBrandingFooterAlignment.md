---
title: CheckoutBrandingFooterAlignment - GraphQL Admin
description: Possible values for the footer alignment.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutBrandingFooterAlignment
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutBrandingFooterAlignment.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Checkout​Branding​Footer​Alignment

enum

Possible values for the footer alignment.

## Valid values

* CENTER

  The checkout footer alignment Center value.

* END

  The checkout footer alignment End value.

* START

  The checkout footer alignment Start value.

***

## Fields

* [Checkout​Branding​Footer.alignment](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutBrandingFooter#field-CheckoutBrandingFooter.fields.alignment)

  OBJECT

  A container for the footer section customizations.

* [Checkout​Branding​Footer​Input.alignment](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutBrandingFooterInput#fields-alignment)

  INPUT OBJECT

  The input fields when mutating the checkout footer settings.

***

## Map

### Fields with this enum

* [Checkout​Branding​Footer.alignment](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutBrandingFooter#field-CheckoutBrandingFooter.fields.alignment)

### Inputs with this enum

* [Checkout​Branding​Footer​Input.alignment](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutBrandingFooterInput#fields-alignment)

---
title: GiftCardSendNotificationToRecipientUserErrorCode - GraphQL Admin
description: >-
  Possible error codes that can be returned by
  `GiftCardSendNotificationToRecipientUserError`.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/GiftCardSendNotificationToRecipientUserErrorCode
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/GiftCardSendNotificationToRecipientUserErrorCode.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Gift​Card​Send​Notification​To​Recipient​User​Error​Code

enum

Possible error codes that can be returned by `GiftCardSendNotificationToRecipientUserError`.

## Valid values

* GIFT\_​CARD\_​NOT\_​FOUND

  The gift card could not be found.

* INVALID

  The input value is invalid.

* RECIPIENT\_​NOT\_​FOUND

  The recipient could not be found.

***

## Fields

* [Gift​Card​Send​Notification​To​Recipient​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/GiftCardSendNotificationToRecipientUserError#field-GiftCardSendNotificationToRecipientUserError.fields.code)

  OBJECT

  An error that occurs during the execution of `GiftCardSendNotificationToRecipient`.

***

## Map

### Fields with this enum

* [Gift​Card​Send​Notification​To​Recipient​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/GiftCardSendNotificationToRecipientUserError#field-GiftCardSendNotificationToRecipientUserError.fields.code)

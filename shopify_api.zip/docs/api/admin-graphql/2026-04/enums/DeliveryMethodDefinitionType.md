---
title: DeliveryMethodDefinitionType - GraphQL Admin
description: The different types of method definitions to filter by.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/DeliveryMethodDefinitionType
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/DeliveryMethodDefinitionType.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Delivery​Method​Definition​Type

enum

The different types of method definitions to filter by.

## Valid values

* MERCHANT

  A static merchant-defined rate.

* PARTICIPANT

  A dynamic participant rate.

***

## Fields

* [Delivery​Location​Group​Zone.methodDefinitions(type)](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/DeliveryLocationGroupZone#field-DeliveryLocationGroupZone.fields.methodDefinitions.arguments.type)

  ARGUMENT

  Links a location group with a zone and the associated method definitions.

***

## Map

### Arguments with this enum

* [Delivery​Location​Group​Zone.methodDefinitions(type)](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/DeliveryLocationGroupZone#field-DeliveryLocationGroupZone.fields.methodDefinitions.arguments.type)

---
title: InventoryTransferRemoveItemsUserErrorCode - GraphQL Admin
description: >-
  Possible error codes that can be returned by
  `InventoryTransferRemoveItemsUserError`.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/InventoryTransferRemoveItemsUserErrorCode
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/InventoryTransferRemoveItemsUserErrorCode.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Inventory​Transfer​Remove​Items​User​Error​Code

enum

Possible error codes that can be returned by `InventoryTransferRemoveItemsUserError`.

## Valid values

* ALL\_​QUANTITY\_​SHIPPED

  The item cannot be removed because all of its quantity is fully allocated to one or more shipments (including draft shipments where the item has been picked). The error name refers to the underlying allocation check; it triggers regardless of whether the shipments have actually shipped.

* CANT\_​REMOVE\_​ALL\_​ITEMS\_​FROM\_​READY\_​TO\_​SHIP\_​TRANSFER

  A `READY_TO_SHIP` transfer must have at least one line item; you cannot remove every line item from one. To empty a `READY_TO_SHIP` transfer, cancel it instead.

* INVALID\_​TRANSFER\_​STATUS

  Current transfer status does not support this operation.

* ITEM\_​NOT\_​FOUND

  The item was not found.

* ITEM\_​PRESENT\_​ON\_​DRAFT\_​SHIPMENT\_​WITH\_​ZERO\_​QUANTITY

  The line item cannot be removed because it appears on a draft shipment with quantity `0`.

* LOCATION\_​NOT\_​FOUND

  The location selected can't be found.

* TRANSFER\_​NOT\_​FOUND

  The transfer was not found.

***

## Fields

* [Inventory​Transfer​Remove​Items​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/InventoryTransferRemoveItemsUserError#field-InventoryTransferRemoveItemsUserError.fields.code)

  OBJECT

  An error that occurs during the execution of `InventoryTransferRemoveItems`.

***

## Map

### Fields with this enum

* [Inventory​Transfer​Remove​Items​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/InventoryTransferRemoveItemsUserError#field-InventoryTransferRemoveItemsUserError.fields.code)

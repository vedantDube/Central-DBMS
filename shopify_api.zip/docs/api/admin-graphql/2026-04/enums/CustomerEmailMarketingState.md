---
title: CustomerEmailMarketingState - GraphQL Admin
description: The possible email marketing states for a customer.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CustomerEmailMarketingState
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CustomerEmailMarketingState.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Customer​Email​Marketing​State

enum

The possible email marketing states for a customer.

## Valid values

* INVALID

  This value is internally-set and read-only.

* NOT\_​SUBSCRIBED

  Default state for customers who have never subscribed to email marketing. This value cannot be set via the mutation; use UNSUBSCRIBED instead to indicate a customer has opted out.

* PENDING

  The customer is in the process of subscribing to email marketing.

* REDACTED

  The customer's personal data is erased. This value is internally-set and read-only.

* SUBSCRIBED

  The customer is subscribed to email marketing.

* UNSUBSCRIBED

  The customer isn't currently subscribed to email marketing but was previously subscribed.

***

## Fields

* [Customer​Email​Marketing​Consent​Input.marketingState](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CustomerEmailMarketingConsentInput#fields-marketingState)

  INPUT OBJECT

  Information that describes when a customer consented to receiving marketing material by email.

* [Customer​Email​Marketing​Consent​State.marketingState](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CustomerEmailMarketingConsentState#field-CustomerEmailMarketingConsentState.fields.marketingState)

  OBJECT

  The record of when a customer consented to receive marketing material by email.

***

## Map

### Fields with this enum

* [Customer​Email​Marketing​Consent​State.marketingState](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CustomerEmailMarketingConsentState#field-CustomerEmailMarketingConsentState.fields.marketingState)

### Inputs with this enum

* [Customer​Email​Marketing​Consent​Input.marketingState](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CustomerEmailMarketingConsentInput#fields-marketingState)

---
title: CheckoutBrandingHeaderPosition - GraphQL Admin
description: The possible header positions.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutBrandingHeaderPosition
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutBrandingHeaderPosition.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Checkout​Branding​Header​Position

enum

The possible header positions.

## Valid values

* INLINE

  Inline position.

* INLINE\_​SECONDARY

  Secondary inline position.

* START

  Start position.

***

## Fields

* [Checkout​Branding​Header.position](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutBrandingHeader#field-CheckoutBrandingHeader.fields.position)

  OBJECT

  The header customizations.

* [Checkout​Branding​Header​Input.position](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutBrandingHeaderInput#fields-position)

  INPUT OBJECT

  The input fields used to update the header customizations.

***

## Map

### Fields with this enum

* [Checkout​Branding​Header.position](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutBrandingHeader#field-CheckoutBrandingHeader.fields.position)

### Inputs with this enum

* [Checkout​Branding​Header​Input.position](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutBrandingHeaderInput#fields-position)

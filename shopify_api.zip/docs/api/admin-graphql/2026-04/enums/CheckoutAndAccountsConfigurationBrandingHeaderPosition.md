---
title: CheckoutAndAccountsConfigurationBrandingHeaderPosition - GraphQL Admin
description: The possible header positions.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutAndAccountsConfigurationBrandingHeaderPosition
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutAndAccountsConfigurationBrandingHeaderPosition.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Checkout​And​Accounts​Configuration​Branding​Header​Position

enum

The possible header positions.

## Valid values

* INLINE

  Inline position.

* INLINE\_​SECONDARY

  Secondary inline position.

* START

  Start position.

***

## Fields

* [Checkout​And​Accounts​Configuration​Branding​Checkout​Header.position](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingCheckoutHeader#field-CheckoutAndAccountsConfigurationBrandingCheckoutHeader.fields.position)

  OBJECT

  The checkout header customizations.

* [Checkout​And​Accounts​Configuration​Branding​Checkout​Header​Input.position](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingCheckoutHeaderInput#fields-position)

  INPUT OBJECT

  The input fields for customizing the checkout header.

***

## Map

### Fields with this enum

* [Checkout​And​Accounts​Configuration​Branding​Checkout​Header.position](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutAndAccountsConfigurationBrandingCheckoutHeader#field-CheckoutAndAccountsConfigurationBrandingCheckoutHeader.fields.position)

### Inputs with this enum

* [Checkout​And​Accounts​Configuration​Branding​Checkout​Header​Input.position](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutAndAccountsConfigurationBrandingCheckoutHeaderInput#fields-position)

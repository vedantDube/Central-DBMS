---
title: AppRevenueAttributionRecordSortKeys - GraphQL Admin
description: The set of valid sort keys for the AppRevenueAttributionRecord query.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/AppRevenueAttributionRecordSortKeys
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/AppRevenueAttributionRecordSortKeys.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# App​Revenue​Attribution​Record​Sort​Keys

enum

The set of valid sort keys for the AppRevenueAttributionRecord query.

## Valid values

* CREATED\_​AT

  Sort by the `created_at` value.

* ID

  Sort by the `id` value.

***

## Fields

* [App​Installation.revenueAttributionRecords(sortKey)](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/AppInstallation#field-AppInstallation.fields.revenueAttributionRecords.arguments.sortKey)

  ARGUMENT

  An app installed on a shop. Each installation tracks the permissions granted to the app through [`AccessScope`](https://shopify.dev/docs/api/admin-graphql/latest/objects/AccessScope) objects, along with billing subscriptions and [`Metafield`](https://shopify.dev/docs/api/admin-graphql/latest/objects/Metafield) objects.

  The installation provides metafields that only the owning [`App`](https://shopify.dev/docs/api/admin-graphql/latest/objects/App) can access. These metafields store app-specific configuration that merchants and other apps can't modify. The installation also provides URLs for launching and uninstalling the app, along with any active [`AppSubscription`](https://shopify.dev/docs/api/admin-graphql/latest/objects/AppSubscription) objects or [`AppPurchaseOneTime`](https://shopify.dev/docs/api/admin-graphql/latest/objects/AppPurchaseOneTime) purchases.

***

## Map

### Arguments with this enum

* [App​Installation.revenueAttributionRecords(sortKey)](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/AppInstallation#field-AppInstallation.fields.revenueAttributionRecords.arguments.sortKey)

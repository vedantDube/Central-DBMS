---
title: CheckoutBrandingLabelPosition - GraphQL Admin
description: Possible values for the label position.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutBrandingLabelPosition
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutBrandingLabelPosition.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Checkout​Branding​Label​Position

enum

Possible values for the label position.

## Valid values

* INSIDE

  The Inside label position.

* OUTSIDE

  The Outside label position.

***

## Fields

* [Checkout​Branding​Control.labelPosition](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutBrandingControl#field-CheckoutBrandingControl.fields.labelPosition)

  OBJECT

  The form controls customizations.

* [Checkout​Branding​Control​Input.labelPosition](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutBrandingControlInput#fields-labelPosition)

  INPUT OBJECT

  The input fields used to update the form controls customizations.

***

## Map

### Fields with this enum

* [Checkout​Branding​Control.labelPosition](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutBrandingControl#field-CheckoutBrandingControl.fields.labelPosition)

### Inputs with this enum

* [Checkout​Branding​Control​Input.labelPosition](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutBrandingControlInput#fields-labelPosition)

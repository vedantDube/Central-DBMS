---
title: InventoryShipmentSetBarcodeUserErrorCode - GraphQL Admin
description: >-
  Possible error codes that can be returned by
  `InventoryShipmentSetBarcodeUserError`.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/InventoryShipmentSetBarcodeUserErrorCode
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/InventoryShipmentSetBarcodeUserErrorCode.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Inventory​Shipment​Set​Barcode​User​Error​Code

enum

Possible error codes that can be returned by `InventoryShipmentSetBarcodeUserError`.

## Valid values

* BARCODE\_​DUPLICATE

  This barcode is already assigned to another shipment.

* BARCODE\_​TOO\_​LONG

  Barcode must be 255 characters or less.

* SHIPMENT\_​NOT\_​FOUND

  The shipment was not found.

***

## Fields

* [Inventory​Shipment​Set​Barcode​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/InventoryShipmentSetBarcodeUserError#field-InventoryShipmentSetBarcodeUserError.fields.code)

  OBJECT

  An error that occurs during the execution of `InventoryShipmentSetBarcode`.

***

## Map

### Fields with this enum

* [Inventory​Shipment​Set​Barcode​User​Error.code](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/InventoryShipmentSetBarcodeUserError#field-InventoryShipmentSetBarcodeUserError.fields.code)

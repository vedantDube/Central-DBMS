---
title: CashTrackingSessionTransactionsSortKeys - GraphQL Admin
description: The set of valid sort keys for the CashTrackingSessionTransactions query.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CashTrackingSessionTransactionsSortKeys
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CashTrackingSessionTransactionsSortKeys.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Cash​Tracking​Session​Transactions​Sort​Keys

enum

The set of valid sort keys for the CashTrackingSessionTransactions query.

## Valid values

* ID

  Sort by the `id` value.

* PROCESSED\_​AT

  Sort by the `processed_at` value.

***

## Fields

* [Cash​Tracking​Session.cashTransactions(sortKey)](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CashTrackingSession#field-CashTrackingSession.fields.cashTransactions.arguments.sortKey)

  ARGUMENT

  Tracks the balance in a cash drawer for a point of sale device over the course of a shift.

***

## Map

### Arguments with this enum

* [Cash​Tracking​Session.cashTransactions(sortKey)](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CashTrackingSession#field-CashTrackingSession.fields.cashTransactions.arguments.sortKey)

---
title: CompanyAddressType - GraphQL Admin
description: The valid values for the address type of a company.
api_version: 2026-04
source_url:
  html: 'https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CompanyAddressType'
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CompanyAddressType.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Company​Address​Type

enum

The valid values for the address type of a company.

## Valid values

* BILLING

  The address is a billing address.

* SHIPPING

  The address is a shipping address.

***

## Fields

* [company​Location​Assign​Address.addressTypes](https://shopify.dev/docs/api/admin-graphql/2026-04/mutations/companyLocationAssignAddress#arguments-addressTypes)

  ARGUMENT

***

## Map

### Arguments with this enum

* [company​Location​Assign​Address.addressTypes](https://shopify.dev/docs/api/admin-graphql/2026-04/mutations/companyLocationAssignAddress#arguments-addressTypes)

---
title: AdjustmentsSortKeys - GraphQL Admin
description: The set of valid sort keys for the Adjustments query.
api_version: 2026-04
source_url:
  html: 'https://shopify.dev/docs/api/admin-graphql/2026-04/enums/AdjustmentsSortKeys'
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/AdjustmentsSortKeys.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Adjustments​Sort​Keys

enum

The set of valid sort keys for the Adjustments query.

## Valid values

* ID

  Sort by the `id` value.

* TIME

  Sort by the `time` value.

***

## Fields

* [Cash​Tracking​Session.adjustments(sortKey)](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CashTrackingSession#field-CashTrackingSession.fields.adjustments.arguments.sortKey)

  ARGUMENT

  Tracks the balance in a cash drawer for a point of sale device over the course of a shift.

***

## Map

### Arguments with this enum

* [Cash​Tracking​Session.adjustments(sortKey)](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CashTrackingSession#field-CashTrackingSession.fields.adjustments.arguments.sortKey)

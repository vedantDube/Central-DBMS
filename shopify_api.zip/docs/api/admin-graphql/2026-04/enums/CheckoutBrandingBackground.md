---
title: CheckoutBrandingBackground - GraphQL Admin
description: The container background style.
api_version: 2026-04
source_url:
  html: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutBrandingBackground
  md: >-
    https://shopify.dev/docs/api/admin-graphql/2026-04/enums/CheckoutBrandingBackground.md
api_name: admin
api_type: graphql
type: enum
metadata:
  domain: admin
---

# Checkout​Branding​Background

enum

The container background style.

## Valid values

* BASE

  The Base background style.

* SUBDUED

  The Subdued background style.

* TRANSPARENT

  The Transparent background style.

***

## Fields

* [Checkout​Branding​Main​Section.background](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutBrandingMainSection#field-CheckoutBrandingMainSection.fields.background)

  OBJECT

  The main sections customizations.

* [Checkout​Branding​Main​Section​Input.background](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutBrandingMainSectionInput#fields-background)

  INPUT OBJECT

  The input fields used to update the main sections customizations.

* [Checkout​Branding​Order​Summary​Section.background](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutBrandingOrderSummarySection#field-CheckoutBrandingOrderSummarySection.fields.background)

  OBJECT

  The order summary sections customizations.

* [Checkout​Branding​Order​Summary​Section​Input.background](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutBrandingOrderSummarySectionInput#fields-background)

  INPUT OBJECT

  The input fields used to update the order summary sections customizations.

***

## Map

### Fields with this enum

* [Checkout​Branding​Main​Section.background](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutBrandingMainSection#field-CheckoutBrandingMainSection.fields.background)
* [Checkout​Branding​Order​Summary​Section.background](https://shopify.dev/docs/api/admin-graphql/2026-04/objects/CheckoutBrandingOrderSummarySection#field-CheckoutBrandingOrderSummarySection.fields.background)

### Inputs with this enum

* [Checkout​Branding​Main​Section​Input.background](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutBrandingMainSectionInput#fields-background)
* [Checkout​Branding​Order​Summary​Section​Input.background](https://shopify.dev/docs/api/admin-graphql/2026-04/input-objects/CheckoutBrandingOrderSummarySectionInput#fields-background)
